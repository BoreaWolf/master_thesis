
lib : contains plenty of general code : to solve knapsacks, hash tables, clocks, CVRP seperation packing, etc


vrp\code : contains a general code for solving vrp problems
vrp\code\cvrp : contains the specific implementation of ALNS for solving CVRP problems
vrp\code\cvrp\mainCVRP.cpp : main for heuristically solving a CVRP
vrp\code\cvrp\main_ex_vrp.cpp : main to solve exactly a CVRP
vrp\code\cvrp\ExactCVRP.h .cpp : instantiate the model with CPLEX and all the callbacks
vrp\code\cvrp\ExactCvrpGraph.h .cpp : object with nodes and arcs for the symmetrical cvrp
vrp\code\cvrp\ExactCvrpSep.h .cpp : class for separating subtours and capacity inequalities using the CVRPSEP package
vrp\code\cvrp\ExactCvrpCallBacks.h .cpp : file holding the callback objects (calls ExactCvrpSep)

To compile the heuristic, just type "make cvrp"
Then to execute, you need to type "./exec_cvrp ../instances/cvrp/your_instance.txt"

to compile the exact method, you first need to set the cplex paths correctly
then, just type "make cvrpex"
To exectute, you need to type "./exec_ex ../instances/cvrp/your_instance.txt"
