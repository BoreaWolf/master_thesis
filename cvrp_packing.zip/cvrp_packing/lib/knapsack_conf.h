

/*
	Solve an extended knapsack problem using the MT1 algorithm of 
	Martello and Toth 

	In this extension, some subsets of items can not be 
	be inside the knapsack. 
	
	To check the conflicting constraints, 
	each object has an unique id (because the set of items come from a master problem)
	
	We associate to each id a prime number. Let Pi be the ith prime number. 

	Each conflicting set is represented as the product of prime number
	associated with the id of the item in the set

	by Jean-Francois Cote
	December 2011
*/

#ifndef KNAPSACK_CONF_H
#define KNAPSACK_CONF_H

#ifdef __cplusplus
	extern "C" {
#endif


typedef struct
{
	int id; 	// id of the item from 0 to n-1
	int uid; 	//id of the item from the master problem
	int w;		//weight
	int p;		//profit
	int x;		//1 if in the set, 0 otherwise
} knapsack_item_conf_t;

int knapsack_conflicts_solve(int W, int n, knapsack_item_conf_t * items, int conflict_count, unsigned long long * conflicting);



#ifdef __cplusplus
	}
#endif


#endif