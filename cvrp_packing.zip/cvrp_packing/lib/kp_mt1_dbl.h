/*
 * Copyright Jean-Francois Cote 2013
 *
 * The code may be used for academic, non-commercial purposes only.
 *
 * Please contact me at cotejean@iro.umontreal.ca for questions
 *
 * If you have improvements, please contact me!
*/


/*
	Solve the knapsack using the MT1 algorithm of 
	Martello and Toth 

	New Version for profits that are integer

	by Jean-Francois Cote
	May 2013
*/



#ifndef KNAPSACK_MT1_DBL_H
#define KNAPSACK_MT1_DBL_H

//comment/uncomment to have the output
//#ifndef KNAPSACK_MT1_DBL_OUTPUT
//#define KNAPSACK_MT1_DBL_OUTPUT
//#endif

#ifdef __cplusplus
	extern "C" {
#endif


// W : capacity of the knapsack
// n : number of items
// w[0..n-1] : weights of items 
// p[0..n-1] : profits of the items
// x[0..n-1] : 0-1 vector if the item is in the knapsack or not
// ub_sol[0..n-1] : 0-1 vector as an upper bound solution
// return the Optimal knapsack value
double kp_mt1_dbl_solve(int W, int n, int * w, double * p, int * x, double ub);




#ifdef __cplusplus
	}
#endif


#endif