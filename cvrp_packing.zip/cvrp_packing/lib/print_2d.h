/*
	Print in the latex format a file that represents a
	two dimensional packing
	Create by Manuel Iori 23/02/2012

*/

#ifndef PRINT_2D_H
#define PRINT_2D_H

#include <stdbool.h>

#ifdef __cplusplus
	extern "C" {
#endif

int Print_2D_PhaseI(int n, int W, int H, int *w, int *h, int *x, bool print_labels, bool print_caption, bool print_colors, char* caption, char* output_file_name);


int Print_2D_PhaseII(int n, int W, int H, int *w, int *h, int *x, int *y, bool print_labels,
				 bool print_caption, char* caption, char* output_file_name);

#ifdef __cplusplus
	}
#endif

#endif
