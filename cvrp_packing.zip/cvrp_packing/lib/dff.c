
#include "dff.h"



//dual feasible function by Fekete and Schepers 1997,1998, 2000
// f_fs : [0,W] -> [0, W * alpha]
int dff_fs(int w, int W, int alpha)
{
	if( (((alpha + 1) * w) % W) == 0 )
		return w*alpha;
	else
	{
		int f1 = (alpha + 1) * w / W;
		return f1 * W;
	}
}

  
//dual feasible function by Martello, Monaci and Vigo 2003
int dff_mmv(int w, int W, int alpha)
{
	if(w > W - alpha)
		return W;
	else if(alpha <= w && w <= W - alpha)
		return w;
	else
		return 0;	
}


//dual feasible function by Carlier, Clautieux and Moukrim 2007
int dff_ccm(int w, int W, int alpha)
{
	double w1 = w;
	double half = W/2.0;
	//int half = W/2;
	if(w1 > half)
	{
		int f1 = W / alpha;
		int f2 = (W-w)/alpha;	
		return 2 * (f1-f2);	
	}
	else if (w1 == half)
	{
		int f1 = W / alpha;
		return f1;
	}
	else
	{
		int f1 = w / alpha;
		return 2*f1;	
	}
}

