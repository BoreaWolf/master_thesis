


#include <strings.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>
#include "subset.h"
#include "util.h"
#include "mathfunc.h"
#include "cover.h"
#include "combo.h"
#include "knapsack.h"
#include "kp_mt1_dbl.h"
#include "knapsack_conf.h"

void test_knapsack_conf();
void test_util_search();
void test_knapsack();
void test_kp_mt1_dbl();
void test_cover();
void test_generalized_lifted_cover();
void test_combo();

int main(int arg, char ** argv)
{
	//test_combo();
	test_kp_mt1_dbl();
	//test_knapsack();
	//test_generalized_lifted_cover();
	//test_util_search();
	//test_cover();
	//test_knapsack_conf();
	return 1;
	/*subset_t s;
	
	subset_init(&s, 6, 10);
	s.w[0] = 1;
	s.w[1] = 1;
	s.w[2] = 1;
	
	s.w[3] = 2;
	s.w[4] = 2;
	s.w[5] = 2;
	
	subset_get_positions(&s);
	subset_free(&s);*/
	
	int n = 10;
	int i;
	int * w = (int*)calloc(n,sizeof(int));
	int * p = (int*)calloc(n,sizeof(int));
	int * c = (int*)calloc(n,sizeof(int));
	int * a = (int*)calloc(n,sizeof(int));
	int * x = (int*)calloc(n,sizeof(int));
	
	w[0] = 31;c[0] = 0;a[0] = 0;
	w[1] = 10;c[1] = 0;a[1] = 0;
	w[2] = 20;c[2] = 1;a[2] = 0;
	w[3] = 19;c[3] = 1;a[3] = 0;
	w[4] = 4;c[4] = 1;a[4] = 0;
	w[5] = 3;c[5] = 1;a[5] = 0;
	w[6] = 6;c[6] = 2;a[6] = 2;
	
	p[0] = 70;
	p[1] = 20;
	p[2] = 39;
	p[3] = 37;
	p[4] = 7;
	p[5] = 5;
	p[6] = 10;
	
	//int z = combo_solve(p,w,x,19,3);
	//int z = util_solve_max_item_knapsack(w, 4, 20);
	//int z = subset_max_sum_pos_multiple_choice(6,w,15,c,3);
	//int z = subset_max_sum_pos_multiple_choice_space_constrained(7,w,17,c,3,a);
	int z = knapsack_solve(50,7,w,p,x);
	printf("z:%d\n", z);
	printf("x:");
	for(i=0;i<5;i++)
		printf("%d ",x[i]);
	printf("\n");
	
}

void test_combo()
{
	int p[6];
	int w[6];
	
	p[0] = p[1] = p[2] = p[3] = p[4] = p[5] = 1000;
	w[0] = 4; w[1] = 23; w[2] = 8;w[3] = 6;w[4] = 5;w[5] = 20;
	
	combo_solve_get_z(p,w,26,6);
}

void test_knapsack_conf()
{
	int i;
	int n = 10;
	int c = 10;
	unsigned long long * conf = (unsigned long long*)malloc(sizeof(unsigned long long) * c);
	knapsack_item_conf_t * items = (knapsack_item_conf_t*)malloc(sizeof(knapsack_item_conf_t) * n);
	items[0].uid = 0;items[0].w = 31;items[0].p = 70;
	items[1].uid = 1;items[1].w = 10;items[1].p = 20;
	items[2].uid = 2;items[2].w = 20;items[2].p = 39;
	items[3].uid = 3;items[3].w = 19;items[3].p = 37;
	items[4].uid = 4;items[4].w = 4;items[4].p = 7;
	items[5].uid = 5;items[5].w = 3;items[5].p = 5;
	items[6].uid = 6;items[6].w = 6;items[6].p = 10;
	
	conf[0] = 6;
	conf[1] = 14;
	conf[2] = 66;
	conf[3] = 858;
	conf[4] = 1326;
	
	int z = knapsack_conflicts_solve(50,7,items,5, conf);
	for(i=0;i<7;i++)
		printf("%d ",items[i].x);
	printf("\n");
}

void test_util_search()
{
	int i;
	int n = 100000;
	int * x = (int*)malloc(sizeof(int) * n);
	for(i=0;i<n;i++)
		x[i] = 2*i; 
	
	int pass = 0;
	int should_pass = 0;
	int nbtests = 50000;
	for(i=0;i<nbtests;i++)
	{
		int r = mat_func_get_rand_int(0, 2*n);	
		if(r % 2 == 0) should_pass++;
		if(util_search(n,x,r) != -1)
			pass++;
			
		//printf("Search for:%d found:%d\n", r, util_search(n,x,r));
	}
	printf("Pass:%d should pass:%d\n", pass, should_pass);
}

void test_knapsack()
{
	int i;
	int nbtests = 1000;
	int n = 10000;
	int W = 10000;
	int * w1 = (int*)calloc(n,sizeof(int));
	int * p1 = (int*)calloc(n,sizeof(int));
	int * w2 = (int*)calloc(n,sizeof(int));
	int * p2 = (int*)calloc(n,sizeof(int));
	int * x1 = (int*)calloc(n,sizeof(int));
	int * x2 = (int*)calloc(n,sizeof(int));

	double time_combo = 0;
	double time_knap = 0;

	while(nbtests-- > 0)
	{
		//printf("\n\n");
		for(i=0;i<n;i++)
		{
			w1[i] = w2[i] = mat_func_get_rand_int(0, W/4);
			p1[i] = p2[i] = mat_func_get_rand_int(1, 10);
		}
		
		clock_t start = clock();
		int z1 = combo_solve(p1,w1,x1,W,n);
		time_combo += (clock()-start)/(double)CLOCKS_PER_SEC;
		
		start = clock();
		int z2 = knapsack_solve(W,n,w2,p2,x2);
		time_knap += (clock()-start)/(double)CLOCKS_PER_SEC;
		
		if(z1 != z2)
		{
			printf("Erreur combo:%d knap:%d\n",z1,z2);
			
			int sump1 = 0, sumw1=0,sump2=0,sumw2=0;
			for(i=0;i<n;i++)if(x1[i]>0){sump1 += p1[i];sumw1+=w1[i];}
			printf("combo sump1:%d sumw1:%d:", sump1,sumw1);
			for(i=0;i<n;i++)if(x1[i]>0) printf("%d ", i);
			
			for(i=0;i<n;i++)if(x2[i]>0){sump2 += p2[i];sumw2+=w2[i];}
			printf("\nknap sump2:%d sumw2:%d:", sump2,sumw2);
			for(i=0;i<n;i++)if(x2[i]>0) printf("%d ", i);
			printf("\n");
			
			printf("p:");
			for(i=0;i<n;i++) printf("%d ", p1[i]);
			printf("\nw:");
			for(i=0;i<n;i++) printf("%d ", w1[i]);
			printf("\np:");
			for(i=0;i<n;i++) printf("%d ", p2[i]);
			printf("\nw:");
			for(i=0;i<n;i++) printf("%d ", w2[i]);
			printf("\n");
			exit(1);
		}
	}
	
	printf("TimeCombo:%lf TimeKnap:%lf\n", time_combo, time_knap);
}

void test_cover()
{
	int n = 6;
	int w = 22;
	int i;
	cover_ptr c = cover_init(w,n);
	
	c->items[0].id= 0;
	c->items[0].w = 13;
	c->items[0].v = 0;
	
	c->items[1].id= 1;
	c->items[1].w = 7;
	c->items[1].v = 0.4;
	
	c->items[2].id= 2;
	c->items[2].w = 6;
	c->items[2].v = 0.5;
	
	c->items[3].id= 3;
	c->items[3].w = 5;
	c->items[3].v = 0.5;
	
	c->items[4].id= 4;
	c->items[4].w = 3;
	c->items[4].v = 0.7;
	
	c->items[5].id= 4;
	c->items[5].w = 10;
	c->items[5].v = 1.0;
	
	cover_heur_solve(c);
	
	printf("Result:%d nbmaxitems:%d\n",c->has_a_cover, c->max_nb_items);
	for(i=0;i<n;i++)
		printf("i:%d w:%d v:%.2lf x:%d\n", c->items[i].id,c->items[i].w,c->items[i].v,c->items[i].x);
}


void test_generalized_lifted_cover()
{
	int W = 5;
	int n = 4;
	int c = 3;
	int i;
	int * w = (int*)calloc(n,sizeof(int));
	double * v = (double*)calloc(n,sizeof(double));
	int * C = (int*)calloc(n,sizeof(int));
	int  * coefs = (int*)calloc(n,sizeof(int));
	
	w[0] = 1;w[1] = 2;w[2] = 2;w[3] = 3;
	v[0] = .75; v[1] = .75; v[2] = 0; v[3] = 1;
	C[0] = 0; C[1] = 1; C[2] = 3;
//int combo_generalized_lifted_cover_inequality(int n, int * w, double * v, int nb_cover, int * cover, int * coefs, int W);
	combo_generalized_lifted_cover_inequality(n,w,v,c,C,coefs,W);
}


void test_kp_mt1_dbl()
{
	int i;
	int nbtests = 1000;
	int n = 10000;
	int W = 10000;
	int * w1 = (int*)calloc(n,sizeof(int));
	double * p1 = (double*)calloc(n,sizeof(double));
	int * x1 = (int*)calloc(n,sizeof(int));

	n=32;
	W=3000;
w1[0] = 365;
w1[1] = 378;
w1[2] = 410;
w1[3] = 425;
w1[4] = 425;
w1[5] = 439;
w1[6] = 464;
w1[7] = 520;
w1[8] = 520;
w1[9] = 540;
w1[10] = 549;
w1[11] = 549;
w1[12] = 553;
w1[13] = 555;
w1[14] = 555;
w1[15] = 555;
w1[16] = 567;
w1[17] = 572;
w1[18] = 572;
w1[19] = 572;
w1[20] = 572;
w1[21] = 572;
w1[22] = 572;
w1[23] = 572;
w1[24] = 572;
w1[25] = 572;
w1[26] = 610;
w1[27] = 660;
w1[28] = 690;
w1[29] = 949;
w1[30] = 949;
w1[31] = 970;
p1[0] = 257.527258;
p1[1] = 270.071777;
p1[2] = 341.487832;
p1[3] = 356.274090;
p1[4] = 356.274090;
p1[5] = 368.716918;
p1[6] = 459.285679;
p1[7] = 488.184112;
p1[8] = 488.184112;
p1[9] = 538.176937;
p1[10] = 547.110423;
p1[11] = 547.055647;
p1[12] = 550.721457;
p1[13] = 553.351122;
p1[14] = 552.808946;
p1[15] = 553.359468;
p1[16] = 565.153867;
p1[17] = 569.973003;
p1[18] = 570.084516;
p1[19] = 569.875096;
p1[20] = 570.004603;
p1[21] = 569.998685;
p1[22] = 569.890771;
p1[23] = 570.023427;
p1[24] = 569.919602;
p1[25] = 569.982765;
p1[26] = 570.090678;
p1[27] = 569.921677;
p1[28] = 569.902852;
p1[29] = 876.053736;
p1[30] = 876.053736;
p1[31] = 899.197938;
x1[0] = 0;
x1[1] = 0;
x1[2] = 0;
x1[3] = 0;
x1[4] = 0;
x1[5] = 0;
x1[6] = 0;
x1[7] = 0;
x1[8] = 0;
x1[9] = 0;
x1[10] = 0;
x1[11] = 0;
x1[12] = 0;
x1[13] = 1;
x1[14] = 0;
x1[15] = 1;
x1[16] = 1;
x1[17] = 0;
x1[18] = 1;
x1[19] = 0;
x1[20] = 0;
x1[21] = 0;
x1[22] = 0;
x1[23] = 0;
x1[24] = 0;
x1[25] = 0;
x1[26] = 1;
x1[27] = 0;
x1[28] = 0;
x1[29] = 0;
x1[30] = 0;
x1[31] = 0;
	
	double init = 553.351122 + 553.359468 + 565.153867 + 570.084516 + 570.090678;
	printf("init:%lf\n",init);
	//double kp_mt1_dbl(int W, int n, int * w, double * p, int * x);
	double v = kp_mt1_dbl_solve(W,n,w1,p1,x1,2849.884576);
	printf("test_kp_mt1_dbl v:%lf\n",v);
	

	for(i=0;i<50;i++)
		if(x1[i] == 1)
			printf("%d ", i);
	printf("\n");
}














