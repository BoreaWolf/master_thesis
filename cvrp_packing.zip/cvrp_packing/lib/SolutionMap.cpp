

#include "SolutionMap.h"
#include "primes.h"
#include <map>
#include <algorithm>
using namespace std;


SolutionMap::SolutionMap()
{
	
}

SolutionMap::~SolutionMap()
{
	Clear();
}


void SolutionMap::Clear()
{
	multimap<unsigned long long, solution_map_item_ptr>::iterator it;
	for (it = solutions.begin() ; it != solutions.end(); it++ )
	{
		solution_map_item_ptr p = (*it).second;
		delete p;
	}
	solutions.clear();
}

void SolutionMap::Add(int status, int nb, int * ids, int * xs)
{
	std::vector<unsigned long long> items(nb);
	for(int i=0;i<nb;i++)
	{
		items[i] = ids[i];
		items[i] <<= sizeof(int)*8;
		items[i] += xs[i];
	}
	std::sort(items.begin(), items.end());
	
	solution_map_item_ptr it = new solution_map_item_t(nb);
	it->key = 1;
	it->status = status;
	for(int i=0;i<nb;i++)
	{
		int x1 = items[i] >> sizeof(int)*8;
		int x2 = (items[i] << sizeof(int)*8) >> sizeof(int)*8;
		//printf("x1:%d x2:%d\n",x1,x2);
		it->ids[i] = x1;
		it->xs[i] = x2;
		it->key *= prime_get_ith(ids[i]) * xs[i];
	}
	//printf("Add key:%llu\n", it->key);
	solutions.insert( pair<unsigned long long, solution_map_item_ptr>(it->key,it) );
}


solution_map_item_ptr SolutionMap::Get(int nb, int * ids, int * xs)
{
	multimap<unsigned long long, solution_map_item_ptr>::iterator it;
	unsigned long long key = 1;
	std::vector<unsigned long long> items(nb);
	for(int i=0;i<nb;i++)
	{
		items[i] = ids[i];
		items[i] <<= sizeof(int)*8;
		items[i] += xs[i];
		key *= prime_get_ith(ids[i]) * xs[i];
	}
	std::sort(items.begin(), items.end());
	//printf("Check key:%llu\n", key);
	
	for(it = solutions.find(key);it != solutions.end();it++)
	{
		solution_map_item_ptr p = (*it).second;
		if(p->nb == nb)
		{
			bool equals = true;
			for(int i=0;i<nb;i++)
			{
				int x1 = items[i] >> sizeof(int)*8;
				int x2 = (items[i] << sizeof(int)*8) >> sizeof(int)*8;
				if(x1 != p->ids[i] || x2 != p->xs[i])
				{
					equals = false;
					break;	
				}
			}
			if(equals) 
			{
				//printf("Return true\n");
				return p;
			}
		}
	}
	return NULL;
}











