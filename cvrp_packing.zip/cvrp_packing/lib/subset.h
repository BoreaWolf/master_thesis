/*
	Code to solve the subset sum to get all possible subsets
	by Jean-Francote Cote and Paul Khuong
	
	The code was made to solve relatively small subset sums in term
	of number of objects. It was also made to be used inside another algorithme
	which need to solve the problem for small value of n and W
	
	This code was made to take advantage of 64 bits. It will only work
	on a 64 bits machine. 
	
	First call subset_init to initialize the structure. 
	
	n is an uppper bound on the number of objects
	W is an upper bound on the capacity
	w[i] is the weight of an object

	then you can change the value of n, W or w[i] and call subset_sum_pos 
	to get the positions
	pos[p] contains 0 if p is not a possible subset sum of the objects 1 otherwise
	
	bits0 and bits1 are temporary arrays to store the positions
	
	Call subset_free to free the structure
	
	for questions, comments or to report an error, write to
	cotejean at iro.umontrea.ca
*/


#ifndef SUBSET_H
#define SUBSET_H

#ifdef __cplusplus
	extern "C" {
#endif

#include <stdint.h>

typedef struct
{
	unsigned int n;
	unsigned int W;
	unsigned short int * w;
	
	char * pos;
	uint32_t * bits0;
	uint32_t * bits1;
	
	//unsigned short int * w_temp;
	//unsigned short int * ident;
	//unsigned int * pos_list;
	//unsigned int pos_count;
} subset_t;
typedef subset_t * subset_ptr;


void subset_init(subset_ptr s, unsigned int n,unsigned int W);
void subset_free(subset_ptr s);



void subset_sum_pos(subset_ptr s);


void subset_sum_pos_simple(int n, int * w,int W, char * pos);


//some positions in pos are already filled
//pos is put to zero at the end
int subset_max_sum_pos_hot_start(int n, int * w,int W, char * pos);

//solve the subset sum given that only one item of each class can be in the sum
//also, each class can have at least 0 item selected and at most 1 
// n: number of elements
// w: array of weights
// W: capacity
// class: array of class, the minimal value is 0 and the maximal is class_count-1
// class_count : number of different classes in the class array
// return the maximal quantity
int subset_max_sum_pos_multiple_choice(int n, int * w,int W, int * clss, int class_count);


//solve the subset sum given that only one item of each class can be in the sum
//also, each class can have at least 0 item selected and at most 1 
// n: number of elements
// w: array of weights
// W: capacity
// class: array of class, the minimal value is 0 and the maximal is class_count-1
// class_count : number of different classes in the class array
// free_space : each item requires an amount of fixed free space to be in the bag to use it 
// return the maximal quantity
int subset_max_sum_pos_multiple_choice_space_constrained(int n, int * w,int W, int * clss, int class_count, int * free_space);


//reduce the array w to contains items that are unique
//the array ident will containt the number of copies of items i
//void subset_identicals(subset_ptr s);

//generate all the position fitting in the capacity
//void subset_get_positions(subset_ptr s);


#ifdef __cplusplus
	}
#endif


#endif

