


/*
	Wrapper of a IHashTable implementation for thread safe operations


	Coded by Jean-Francois Cote on 18 june 2014
*/

#ifndef HASH_TABLE_THREAD_SAFE
#define HASH_TABLE_THREAD_SAFE



#include <vector>
#include <map>
#include "primes.h"
#include <stdint.h>
#include "IHashTable.h"
#include <omp.h>

template <class T>
class HashTableThreadSafe : public IHashTable<T>
{
	public:
		
		HashTableThreadSafe(IHashTable<T> * table):_table(table)
		{
			omp_init_lock(&_lock);
		}
		~HashTableThreadSafe()
		{
			omp_destroy_lock(&_lock);
		}
		
		void Assign(std::vector<int> & list, T data)
		{
			omp_set_lock(&_lock);
			_table->Assign(list, data);
			omp_unset_lock(&_lock);
		}
		
		T GetData(std::vector<int> & list)
		{
			omp_set_lock(&_lock);
			T t = _table->GetData(list);
			omp_unset_lock(&_lock);
			return t;
		}
		
		//if data is modifed, it is not thread safe
		bool GetData(std::vector<int> & list, T ** data)
		{
			omp_set_lock(&_lock);
			bool t = _table->GetData(list,data);
			omp_unset_lock(&_lock);
			return t;
		}
		
		void Remove(std::vector<int> & list)
		{
			omp_set_lock(&_lock);
			_table->Remove(list);
			omp_unset_lock(&_lock);
		}
		
	private:
		IHashTable<T> * _table;
		omp_lock_t _lock;
};



#endif


