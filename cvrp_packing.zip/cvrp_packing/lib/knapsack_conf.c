

#include "knapsack_conf.h"
#include <stdio.h> 
#include <stdlib.h> 
#include "primes.h"
#include "util.h"

typedef struct
{
	unsigned long long nbnodes;	//number of visited nodes
	int n;			//number of items
	int W;			//capacity
	knapsack_item_conf_t * items;
	int ub;		//best upper bound
	int lb;			//best lower bound
	int cur_item;	//item to consider
	int cur_sum_w;	//current sum of weight
	int cur_sum_p;	//current sum of profit
	unsigned long long cur_prod; //current product of prime numbers
	int conf_count;
	unsigned long long * conflicts;
	int * sol; 		//best solution
} knapsack_conf_t;


//for sorting
int knapsack_item_conf_cmp(const void *a, const void *b)
{
	knapsack_item_conf_t * a1 = (knapsack_item_conf_t *)a;
	knapsack_item_conf_t * b1 = (knapsack_item_conf_t *)b;
	double a2 = a1->p / (double)a1->w;
	double b2 = b1->p / (double)b1->w;
	return  a2>b2?-1:1;
}
int knapsack_item_conf_cmp_id(const void *a, const void *b)
{
	knapsack_item_conf_t * a1 = (knapsack_item_conf_t *)a;
	knapsack_item_conf_t * b1 = (knapsack_item_conf_t *)b;
	return  a1->id-b1->id;
}

//return best found upper bound
int knapsack_bb(knapsack_conf_t * sa)
{
	sa->nbnodes++;
	int i;
	int item = sa->cur_item;
	
	int search_re = util_search_ull(sa->conf_count,sa->conflicts, sa->cur_prod);
	//printf("node:%llu item:%d lb:%d sump:%d cur_prod:%llu search:%d items:", 
	//			sa->nbnodes,sa->cur_item, sa->lb,sa->cur_sum_p,sa->cur_prod,search_re);
	//for(i=0;i<sa->cur_item;i++)
	//	printf("%d ", sa->items[i].x);
	//printf("\n");
	
	if(search_re == -1 && sa->cur_sum_p > sa->lb)
	{
		//printf("Found new solution sump:%d prime_prod:%llu\n",sa->cur_sum_p, sa->cur_prod);
		//for(i=0;i<item;i++)
		//	if(sa->items[i].x >= 1)
		//		printf("%d ", sa->items[i].uid);
		//printf("\n");
		//for(i=0;i<sa->conf_count;i++)
		//	printf("%llu ", sa->conflicts[i]);
		//printf("\n");
		
		sa->lb = sa->cur_sum_p;
		for(i=0;i<item;i++)
			sa->sol[sa->items[i].id] = sa->items[i].x;
		for(i=item;i<sa->n;i++)
			sa->sol[sa->items[i].id] = 0;
		
		if(sa->ub < sa->cur_sum_p)
			sa->ub = sa->cur_sum_p;
	}
	if(sa->cur_item >= sa->n) return sa->cur_sum_p;
	
	int lb1 = 0;
	int lb2 = 0;
	int sum_w = sa->cur_sum_w;
	double sum_p = sa->cur_sum_p;
	
	//calculate an upper bound from the current item
	for(i=item;i<sa->n;i++)
		if(sum_w + sa->items[i].w <= sa->W)
		{
			sum_p += sa->items[i].p;
			sum_w += sa->items[i].w;
		}
		else
			break;
	//take the last fractional part	
	if(i < sa->n)	
		sum_p += (int)(((sa->W - sum_w) / (double)sa->items[i].w) * sa->items[i].p);
	
	//printf("sum_p:%lf lb:%d\n", sum_p, sa->lb);
	if(sum_p <= sa->lb)
	{
	//	printf("\treturn\n");
		return 0;
	}		
	else
	{
		if(sa->items[item].w + sa->cur_sum_w <= sa->W)
		{
			int prime = prime_get_ith(sa->items[item].uid);
			sa->items[item].x = 1;
			sa->cur_sum_w += sa->items[item].w;
			sa->cur_sum_p += sa->items[item].p;
			sa->cur_prod *= prime;
			sa->cur_item = item+1;
			
			lb1 = knapsack_bb(sa);
			
			sa->cur_prod /= prime;
			sa->cur_sum_w -= sa->items[item].w;
			sa->cur_sum_p -= sa->items[item].p;
		}
			
		sa->items[item].x = 0;
		sa->cur_item = item+1;
		
		lb2 = knapsack_bb(sa);
	}
	return lb1<lb2?lb1:lb2;
}

int knapsack_conflicts_solve(int W, int n, knapsack_item_conf_t * items, int conflict_count, unsigned long long * conflicts)
{
	//printf("knapsack_conflicts_solve n:%d W:%d\n", n,W);	
	int i;
	knapsack_conf_t sa;
	sa.nbnodes = 0;
	sa.n = n;
	sa.W = W;
	sa.conflicts = conflicts;
	sa.conf_count = conflict_count;
	sa.items = items;
	sa.sol =(int*)calloc(n,sizeof(int)); 
	sa.cur_prod = 1;
	
	for(i=0;i<n;i++)
	{
		sa.items[i].id = i;
		sa.items[i].x = 0;
	}
	qsort(sa.items, n, sizeof(knapsack_item_conf_t), knapsack_item_conf_cmp);
	util_sort_ull(conflicts,conflict_count);
	//for(i=0;i<n;i++)
	//	printf("item:%d w:%d p:%d\n", sa.items[i].uid, sa.items[i].w,sa.items[i].p);
	//printf("primes:");
	//for(i=0;i<conflict_count;i++)
	//	printf("%llu ", conflicts[i]);
	//printf("\n");
	sa.lb = 0;
	int sumw = 0;
	for(i=0;i<n;i++)
		if(sumw + sa.items[i].w <= W)
		{
			sa.sol[i] = 0;
			sa.lb += sa.items[i].p;
			sumw += sa.items[i].w;
		}
		else
			break;
	//printf("sumw:%d sump:%d\n", sumw, sa.lb);
	
	sa.ub = sa.lb;
	if(i < n) 
		sa.ub += (int)(((W - sumw) / (double)sa.items[i].w) * sa.items[i].p);
	
	sa.lb = 0;
	//printf("ub:%d lb:%d\n", sa.ub,sa.lb);
	
	if(sa.ub == ((double)sa.lb))// if all objects fit in the knapsack
		goto END;
	
	sa.cur_sum_w = 0;
	sa.cur_sum_p = 0;
	sa.cur_item = 0;
	
	knapsack_bb(&sa);
	
	//printf("nbnodes:%llu ub:%d lb:%d\n",sa.nbnodes, sa.ub,sa.lb);
END:
	//if(sa.ub == ((double)sa.lb))
	{
		//printf("sol:");
		for(i=0;i<n;i++)
		{
		//	if(sa.sol[sa.items[i].id] >= 1)
		//		printf("%d ", sa.items[i].uid);
			sa.items[i].x = sa.sol[ sa.items[i].id ];
		}
		//printf("\n");
	}
	qsort(items, n, sizeof(knapsack_item_conf_t), knapsack_item_conf_cmp_id);
	
	free(sa.sol);
	return sa.lb;
}




