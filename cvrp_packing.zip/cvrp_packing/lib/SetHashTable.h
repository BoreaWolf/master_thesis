


#ifndef SET_HASH_TABLE
#define SET_HASH_TABLE

//#define SET_HASH_TABLE_TEST

#include <vector>
#include <map>
#include "primes.h"
#include <stdint.h>
#include "IHashTable.h"


//structure
template <class T>
class SetHashTableData
{
	public:
	unsigned long long key1;
	T data;
	#ifdef SET_HASH_TABLE_TEST
	std::vector<int> path;
	#endif
};

template <class T>
class SetHashTableCase
{
	public:
	std::vector< SetHashTableData<T> > datas;
};

template <class T>
class SetHashTable : public IHashTable<T>
{
	public:
		
		SetHashTable() : _len(0), _cases(0){}
		SetHashTable(size_t len) : _len(len), _cases(len){}
	
		~SetHashTable()
		{
			#ifdef SET_HASH_TABLE_TEST
			CheckCollision();
			#endif
			for(size_t i=0;i<_cases.size();i++)
				if(_cases[i] != NULL)
					delete _cases[i];
		}
	
		void Assign(std::vector<int> & path, T data)
		{
			if(path.size() == 0) return;
			
			unsigned long long key1 = GetSetId(path);
			size_t pos = (size_t)(key1 % (unsigned long long)_len);
			
			if(_cases[pos] == NULL)
			{
				_cases[pos] = new SetHashTableCase<T>();
				SetHashTableData<T> dt;
				dt.key1 = key1;
				dt.data = data;
				#ifdef SET_HASH_TABLE_TEST
					dt.path = path;
				#endif
				_cases[pos]->datas.push_back(dt);
				
			}
			else
			{
				//find in the case if there is a DataBlock for this path
				bool found = false;
				for(size_t i=0;i<_cases[pos]->datas.size();i++)
					if(_cases[pos]->datas[i].key1 == key1)
					{
						_cases[pos]->datas[i].data = data;					
						#ifdef SET_HASH_TABLE_TEST
							//check if they have both the same path, otherwise output an warning
							TestSets(key1, _cases[pos]->datas[i].path,path);
						#endif
						found=true;
						break;	
					}
				if(!found)
				{
					SetHashTableData<T> dt;
					dt.key1 = key1;
					dt.data = data;	
					#ifdef SET_HASH_TABLE_TEST
					dt.path = path;
					#endif
					_cases[pos]->datas.push_back(dt);
				}
			}
		}
		
		T GetData(std::vector<int> & set)
		{
			if(set.size() == 0) return T();
			
			unsigned long long key1 = GetSetId(set);
			size_t pos = (size_t)(key1 % (unsigned long long)_len);
			if(_cases[pos] == NULL) 
				return T();
			for(size_t i=0;i<_cases[pos]->datas.size();i++)
				if(_cases[pos]->datas[i].key1 == key1)
				{
					#ifdef SET_HASH_TABLE_TEST
						//check if they have both the same path, otherwise output an warning
						TestSets(key1, _cases[pos]->datas[i].path,set);
					#endif
					return _cases[pos]->datas[i].data;
				}
			return T();
		}
		
		bool GetData(std::vector<int> & list, T ** data)
		{
			if(list.size() == 0) return false;
			
			unsigned long long key1 = GetSetId(list);
			size_t pos = (size_t)(key1 % (unsigned long long)_len);
			if(_cases[pos] == NULL) return false;
			
			for(size_t i=0;i<_cases[pos]->datas.size();i++)
				if(_cases[pos]->datas[i].key1 == key1)
				{
					*data = &_cases[pos]->datas[i].data;
					return true;
				}
			return false;	
		}
		
		void Remove(std::vector<int> & set)
		{
			if(set.size() == 0) return;
			
			unsigned long long key1 = GetSetId(set);
			size_t pos = (size_t)(key1 % (unsigned long long)_len);
			if(_cases[pos] == NULL) return;
			
			for(size_t i=0;i<_cases[pos]->datas.size();i++)
				if(_cases[pos]->datas[i].key1 == key1)
				{
					_cases[pos]->datas.erase( _cases[pos]->datas.begin() + i );
					break;
				}
		}
		
		unsigned long long GetSetId(std::vector<int> & set)
		{
			unsigned long long key = 1;
			for(size_t i=0;i<set.size();i++)
				key *= prime_get_ith(set[i]);
			return key;
		}
		
	
		//check if they have both the same path, otherwise output an warning
		void TestSets(unsigned long long key1,std::vector<int> & path1, std::vector<int> & path2)
		{
			if(path1.size() != path2.size())
			{
				printf("Warning different paths have the same keys key1:%llu\n",key1);
				printf("path1:"); 
				for(size_t j=0;j<path1.size();j++)
					printf("%d ", path1[j]);
				printf("\npath2:");
				for(size_t j=0;j<path2.size();j++)
					printf("%d ", path2[j]);
				printf("\n");
				exit(1);
			}
			else	
				for(size_t j=0;j<path1.size();j++)
					if(path1[j] != path2[j])
					{
						printf("Warning different paths have the same keys key1:%llu\n",key1);
						printf("path1:"); 
						for(size_t j=0;j<path1.size();j++)
							printf("%d ", path1[j]);
						printf("\npath2:");
						for(size_t j=0;j<path2.size();j++)
							printf("%d ", path2[j]);
						printf("\n");
						break;
						exit(1);
					}
		}
	
		void CheckCollision()
		{
			int nbelements = 0;
			int nbnonnull = 0;
			int max_nb_diff = 0;
			for(size_t i=0;i<_cases.size();i++)
				if(_cases[i] != NULL)
				{
					nbnonnull++;
					nbelements += (int)_cases[i]->datas.size();
					
					int nbdiff = 0;
					std::map<unsigned long long, int> keys;
					for(size_t j=0;j<_cases[i]->datas.size();j++)
					{
						int v = keys[ _cases[i]->datas[j].key1 ];
						if(v != 0) nbdiff++;
						keys[ _cases[i]->datas[j].key1 ] = 1;	
					}
					max_nb_diff = std::max(nbdiff, max_nb_diff);
				}
			
			
			printf("CheckCollision\n");
			printf("nbelements:%d\n", nbelements);
			printf("nbnonnull:%d\n", nbnonnull);
			printf("maxdiff:%d\n", max_nb_diff);
			
		}
		
	private:
	size_t _len;
	std::vector< SetHashTableCase<T>* > _cases;
	
};



#endif


