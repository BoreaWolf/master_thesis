/*
 * Copyright Jean-Francois Cote 2012
 *
 * The code may be used for academic, non-commercial purposes only.
 *
 * Please contact me at cotejean@iro.umontreal.ca for questions
 *
 * If you have improvements, please contact me!
*/




#ifndef SOLUTIONMAPH
#define SOLUTIONMAPH

#include <map>
#include <vector>


struct solution_map_item_t
{
	unsigned long long key;
	int nb;
	int status;
	std::vector<int> ids;
	std::vector<int> xs;
	solution_map_item_t(int n) : key(0),nb(n),status(0),ids(nb), xs(nb){}
} ;

typedef solution_map_item_t* solution_map_item_ptr;

class SolutionMap
{
	public:
	SolutionMap();
	~SolutionMap();
	
	void Clear();
	void Add(int status, int nb, int * ids, int * x);
	solution_map_item_ptr Get(int nb, int * ids, int * x);
	
	private:
	std::multimap<unsigned long long, solution_map_item_ptr> solutions;
};




#endif