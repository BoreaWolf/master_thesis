
/* ======================================================================
	         SUBSUM.c David Pisinger 1994,1995, revised 1999
   ====================================================================== */

/* This C-code solves the subset sum problem. It was presented as
 * subroutine in 
 *
 *   D. Pisinger
 *   An exact algorithm for large multiple knapsack problems
 *   to appear European Journal of Operational Research
 *
 * where it was used to tighten the capacity constraints and to 
 * derive lower bounds by splitting a solution to the surrogate 
 * relaxed problem.
 * Further details on the project can also be found in
 *
 *   D. Pisinger
 *   Algorithms for Knapsack Problems
 *   Report 95/1, DIKU, University of Copenhagen
 *   Universitetsparken 1
 *   DK-2100 Copenhagen
 *
 * The algorithm may be used for academic, non-commercial purposes
 * only.
 * -------------------------------------------------------------------
 * The present code is a callable routine which solves a Subset-sum
 * Problem:
 *
 *           maximize   \sum_{j=1}^{n} w_{j} x_{j}
 *           subject to \sum_{j=1}^{n} w_{j} x_{j} \leq c
 *                      x_{j} \in \{0,1\}, j = 1,\ldots,n
 *
 * The decomp algorithm is called as
 *
 *          z = decomp(n, w, x, c)
 *
 * where w[], x[] are arrays of integers. The optimal objective
 * value is returned in z, and x[] gives the solution vector.
 * If you need a different interface for your algorithm, decomp
 * may easily be adapted to your own datastructures since all tables
 * are copied to the internal representation.
 *
 * Different types should be defined as follows:
 *
 *    itype     should be sufficiently large to hold the weights
 *    stype     should be sufficient to hold sum of weights
 *    ptype     should hold the product of an stype and itype
 *
 * The code has been tested on a hp9000/735, and conforms with the
 * ANSI-C standard.
 *
 * Errors and questions are refered to:
 *
 *   David Pisinger, associate professor
 *   DIKU, University of Copenhagen,
 *   Universitetsparken 1,
 *   DK-2100 Copenhagen.
 *   e-mail: pisinger@diku.dk
 *   fax: +45 35 32 14 01
 */


int decomp(int n, int *w, int *x, int c);





