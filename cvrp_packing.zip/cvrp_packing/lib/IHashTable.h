


#ifndef IHASH_TABLE
#define IHASH_TABLE


#include <vector>
#include <map>
#include "primes.h"
#include <stdint.h>

/*
	Interface for defining an hash table where the elements are
	sets of integers

*/



template <class T>
class IHashTable
{
	public:
		
		IHashTable(){}
	
		virtual ~IHashTable(){}
		
		virtual void Assign(std::vector<int> & list, T data) = 0;
		virtual T GetData(std::vector<int> & list) = 0; //if not found, it returns T()
		
		//the modification of data is not thread safe
		virtual bool GetData(std::vector<int> & list, T ** data) = 0; //if not found, it returns false, otherwise the data is filled 
		virtual void Remove(std::vector<int> & list) = 0;
};



#endif


