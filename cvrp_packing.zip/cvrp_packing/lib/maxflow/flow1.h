

/*--------------------------------- Include files -----------*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

/**************************************************************

    Routines for computing a Max-Flow (Min-Cut) in a directed
    network by using the Pre-flow algorithm of Golberg (1989).

    The capacity of the edges (DOUBLE) is defined by in the
    following line:                                          */

#define DOUBLE  double

/*
    INPUT for goldberg():

	 int    vertices;
	 int    edges;
	 int    source;
	 int    sink;
	 int    fr [0...edges-1];
	 int    to [0...edges-1];
	 DOUBLE cap[0...edges-1];
	 DOUBLE *minmax;            =upper bound on the max-flow
	 int    *ncut;              =maximum number of different min-cuts

	 ( indexes for vertices in {1,...,vertices} )

    OUTPUT for golberg():

	 DOUBLE *minmax;               
	 DOUBLE flow[0...edges-1];    
	 int    *ncut;              =number of different nested min-cuts
	 short int cut [0...(*ncut)*vertices -1];

***************************************************************/

/*--------------------------------- Parameters --------------*/

#define ZERO        0.0001     /* for testing float's for equality */
#define ZERO_CHECK  0.01        /* for checking the flow - cut      */


/*--------------------------------- Data Structure ----------*/

typedef struct VERTEX{
	struct EDGE ** edgelist;  /* Pointer to the list of pointers to
				     the adjacent edges.
				     (No matter that to or from edges) */
	struct EDGE ** current;   /* Pointer to the current edge       */
	DOUBLE excess;            /* Excess in the pre-flow            */
	int    degree;            /* Number of adjacent edges (both direction)*/
	int    index;             /* Name of the vertex                */
	int    label;             /* Distance label                    */
}vertex;

typedef struct EDGE{
	struct VERTEX *from;
	struct VERTEX *to;
	DOUBLE flow;              /* Flow value */
	DOUBLE cap;               /* Capacity */
}edge;

typedef struct NETWORK{
	int    vertnum;
	int    edgenum;
	vertex *verts;           /* Vertex array[1..vertnum] */
	edge   *edges;           /* Edge array[1..edgenum] */
	vertex *source;          /* Pointer to the source */
	vertex *sink;            /* Pointer to the sink */
	DOUBLE maxflow;          /* the value of the maximum flow */
}network;

typedef struct QUEUE_NODE{
	void * data;
}queue_node;

typedef struct QUEUE{
	struct QUEUE_NODE * first;
	struct QUEUE_NODE * last;
	struct QUEUE_NODE * start;
	struct QUEUE_NODE * end;
}queue;

#define IS_EMPTY_QUEUE(q) ((q)->first == (q)->last)


/*---------------------------------- Global data ---------*/

static int    Vertnum, Edgenum;
static vertex * Source, * Sink;
static int    * Labarr;
static queue  * Q;
static queue  * Qv;
static char   Gap;
static int    It,Inf,Big,Maxlev;
static DOUBLE Flow_bound,Upper_flow;


/*--------------------------------- Macro definitions ---------*/

#define OUT_EDGE(V, E) ((E)->from == V)
#define RESCAP(V, E)   ((OUT_EDGE(V, E)) ? ((E)->cap - (E)->flow) : (E)->flow)
#define OTHER(V, E)    (OUT_EDGE(V, E) ? (E)->to : (E)->from)
#define LAST_EDGE(V)   (&((V)->edgelist[(V)->degree -1]))
#define MIN2(A,B)      (((A)<(B))?(A):(B))

/*--------------------------------- Function Prototypes ------*/

void    goldberg(int, int, int, int, int*, int*, DOUBLE*, DOUBLE*, DOUBLE*, int*, short int *);
static  network *load_net(int,int,int,int,int *,int *,DOUBLE *);
static  void    free_net(network *);
static  void    print_DIMACS_std (char *, network *);
static  int     maxflow_start(network *);
static  DOUBLE  search_cut(network *, vertex *, queue *, int);
static  void    maxflow(network *);
static  void    pushrelabel(vertex *);
static  void    discharge(vertex *);
static  void    push(vertex *, edge *);
static  void    relabel(vertex *);
static  int     big_relabel(network *, int);
static  int     search(vertex *, queue *, int);
static  int     check_maxflow(network *,DOUBLE *);
static  queue   * new_queue(int);
static  void    init_queue(queue *);
static  void    free_queue(queue *);
static  void    enqueue(queue *, void *);
static  void    * dequeue(queue *);
//static  void    print_queue(queue *);
static  int     bad_cut(void);
static  void    compute_cuts(network *,int *,short int *);
static  void    loop_in_flow(network *);

/*---------------------------------- Function Definitions ------*/

void      goldberg(vertices,edges,source,sink,fr,to,cap,minmax,flow,ncut,cut)
int       vertices,edges;
int       source,sink;
int       *fr,*to;
DOUBLE    *cap,*minmax,*flow;
int       *ncut;
short int *cut;
{
	network  *n;
	Upper_flow = *minmax;
	n = load_net(vertices,edges,source,sink,fr,to,cap);
	if( maxflow_start(n) )
	{
/*
	    printf(" WARNING: not feasible flow solution ");
	    print_DIMACS_std("flow.dat",n);
*/
	}

/* printf("\n ... maxflow value: %f \n",n->maxflow); */

	if( n->maxflow<Upper_flow-ZERO ){
/* */           
	    if( check_maxflow(n,flow) ){
			printf(" ERROR: wrong maxflow value!!! ");
			print_DIMACS_std("flow.dat",n);
			*minmax=1000000.0;
//			fprintf(ft,"ERROR IN MAXFLOW!\n");
//			fprintf(fo,"ERROR IN MAXFLOW!\n");
			printf("ERROR IN MAXFLOW!\n");
			return;
			//exit(1);
	    }
/* */
	}
	compute_cuts(n,ncut,cut);
	*minmax = n->maxflow;
	free_net(n);
}

/*==================================================================*/

static  network * load_net(vertices,edges,source,sink,fr,to,cap)
int     vertices,edges;
int     source,sink;
int     *fr,*to;
DOUBLE  *cap;
{
	int     k;
	network * n;
	edge    * ed , * ne, * e;
	vertex  * nv, *v, *s;

	Q = Qv = NULL;
	Labarr = (int *)calloc((unsigned int)vertices+2, sizeof(int));

	n = (network *)malloc(sizeof(network));
	n->vertnum = vertices;
	n->edgenum = edges;
	n->verts   = (vertex *)calloc(n->vertnum + 2, sizeof(vertex));
	n->source  = &((n->verts)[source]);
	n->sink    = &((n->verts)[sink]);
	n->edges   = (edge *)calloc(n->edgenum + 2, sizeof(edge));
	n->maxflow = 0;

	ed = n->edges + 1;
	for(k=0;k<edges;k++){
			ed->from = &((n->verts)[ fr[k] ]);
			ed->to   = &((n->verts)[ to[k] ]);
			ed->cap  = cap[k];
			ed->flow = 0;
			((n->verts)[ fr[k] ]).degree++;
			((n->verts)[ to[k] ]).degree++;
			ed++;
	}

	n->source->degree++;

	/*------ Now build the adjacency lists for each vertex ----*/
	nv = n->verts;
	for( k = 1; k <= n->vertnum; k++){
					   /* Edgelist allocation */
		v = &(nv[k]);
		if(v->degree)
		    v->edgelist = (edge **)calloc(v->degree, sizeof(edge *));
		else
		    v->edgelist = NULL;
		v->current = v->edgelist;
	}
	ne = n->edges;
	for( k = 1; k <= n->edgenum; k++){
					   /* Fill in the edgelists */
		e = &(ne[k]);
		*(e->from->current) = e;
		*(e->to->current) = e;
		(e->from->current)++;
		(e->to->current)++;
	}

/* Artificial source + edge */
/* (This makes the n->verts and n->edges arrays one longer) */

	n->vertnum++;
	n->edgenum++;

	e = &(n->edges[n->edgenum]);
	v = &(n->verts[n->vertnum]);
	v->degree      = 1;
	v->edgelist    = (edge **)calloc(1, sizeof(edge *));
	*(v->edgelist) = e;
	s = n->source;
	*(s->current) = e;
	e->from = v;
	e->to   = s;
	e->cap  = 1; /* and will be setted after to an upper flow bound */
	e->flow = 0;
	n->source = v;

	nv = n->verts;
	for( k = 1 ; k <= n->vertnum; k++){
		v = &(nv[k]);
		v->current = v->edgelist;
		v->index   = k;
	}
	return n;
}

/*===============================================================*/

static void free_net(network *n)
{
	int  i;
	edge **ptr;

	i = n->vertnum;
	while(i){
	     ptr = (n->verts[i--]).edgelist;
	     if( ptr ) free(ptr);
	}

	free(n->edges);
	free(n->verts);
	free(n);
	free(Labarr);
}

/*==================================================================*/

static void print_DIMACS_std (char *name, network *n)

{
	int  i, vnum, e_num;
	edge * e;
	FILE * Output;

	vnum  = n->vertnum - 1;
	e_num = n->edgenum - 1;

	Output = fopen(name,"w");
	if (Output == NULL) {
	     printf("ERROR: it is not possible to open %s\n",name);
	     exit(1);
	}
	printf(" Writing network to file %s ...\n",name);

	fprintf(Output, "c --------------------------------------------\n");
	fprintf(Output, "c Parameters of the network:\n");
	fprintf(Output, "p max %d %d\n", vnum, e_num);
	fprintf(Output, "n %d s\n",(n->source->edgelist[0])->to->index);
	fprintf(Output, "n %d t\n", n->sink->index);
	for (i = 1; i <= e_num; i++){
		e = &n->edges[i];
		fprintf(Output, "a %d %d %f\n"
			   , e->from->index, e->to->index, (float)e->cap);
	}
	fprintf(Output, "c --------------------------------------------\n");
	fprintf(Output, "c The maximum flow value:\n");
	fprintf(Output, "c %f\n", (float)n->maxflow);
	fprintf(Output, "c --------------------------------------------\n");
	fprintf(Output, "c Flow values of the edges:\n");
	fprintf(Output, "c         FROM       TO                FLOW\n");
	fprintf(Output, "c --------------------------------------------\n");

	for (i = 1; i <= e_num; i++){
		e = &n->edges[i];
		fprintf(Output, "f %8d %8d %f\n"
			   , e->from->index, e->to->index, (float)e->flow);
	}
	fclose( Output );
}

/*===============================================================*/


static int maxflow_start(network *n)

		      /* After the allocations, with
			 a prepared network * n, and
			 a given preflow, it will
			 start the maxflow algorithm */
{

	/*---- Fill up the global variables ----*/

	Source  = n->source;
	Sink    = n->sink;
	Vertnum = n->vertnum;
	Edgenum = n->edgenum;
	Inf     = 3 * Vertnum;

	/*---- Default values of the frequencies ----*/

	Source->edgelist[0]->flow = Upper_flow;
	Source->edgelist[0]->cap = Upper_flow;
	Source->edgelist[0]->to->excess = Upper_flow;
	Source->excess = -Upper_flow;

	Q = new_queue(2*Vertnum);
	Flow_bound = Upper_flow;
	search_cut(n, Sink, Q, 0);
	(*(Source->edgelist))->cap = Flow_bound;

	if (big_relabel(n, 1) && Sink->excess<ZERO && Sink->excess> -ZERO){
	    free_queue(Q);
	    return 1;              /* No feasible solution */
	}

	(*(Source->edgelist))->cap = Flow_bound;   /* J.J.Salazar */
	(*(Source->edgelist))->flow = Flow_bound;
	(*(Source->edgelist))->to->excess = Flow_bound;
	Source->excess = -Flow_bound;

	Qv = new_queue(2*Vertnum);
	enqueue(Qv, (*(Source->edgelist))->to);

	maxflow(n);
	free_queue(Qv);
	free_queue(Q);
	return 0;
}


/*==================================================================*/

static DOUBLE search_cut(network *n, vertex *source, queue *q, int start_level)
{
	int    i, level;
	DOUBLE cutcap = 0;
	vertex * v, * w;
	edge   * e, **ve;

	for( i = 1; i <= Vertnum;  i++)
		n->verts[i].label = Inf;

	level = start_level;
	init_queue(q);
	enqueue(q, source);
	enqueue(q, NULL);

	while (1){
		v = (vertex *)dequeue(q);
		if (v == NULL){
			if (IS_EMPTY_QUEUE(q) || bad_cut() )
			  break;

			level++;
			if (cutcap < Flow_bound-ZERO)
			  Flow_bound = cutcap;
			cutcap = 0;
			enqueue(q, NULL);
		}else{
			v->label = level;
			ve = v->edgelist;
			for (i = 0; i < v->degree; i++){
				e = ve[i];

				if (v == e->to){
					if ((w = e->from)->label == Inf || w->label == -1)
					  {
						  cutcap += (e->cap);
						  if (w->label == Inf){
							  w->label = -1;
							  enqueue(q, w);
						  }
					  }
				}
			}
		}
	}
	return( cutcap );
}


/*==================================================================*/

static void maxflow(network *n)

	 /* Finds the max-flow in the initialized
		network n using the GOLD alg.  */
{
	vertex *v;
	int    sf, rf, last;
	int    big = 1, stall = 0, was_change = 0;
	DOUBLE old_fl;

	It    = Big = 0;
	last  = 0;
	sf    = Vertnum / 2;
	rf    = Edgenum;
	Gap   = 1;

	while (!IS_EMPTY_QUEUE(Qv)){
		It++;

		v = (vertex *)dequeue(Qv);

		if (v == NULL){
		      printf("Null dequeued\n");
		      exit(1);
		}

		old_fl = Sink->excess;

		discharge(v);

		if (v->excess > ZERO && v->label != Inf)
			enqueue(Qv, v);

		/* -------------------------------------
		   Big_relabel heuristics
		   -------------------------------------*/

		if (Sink->excess>old_fl-ZERO && Sink->excess<old_fl+ZERO )
			stall++;
		else{
			old_fl = Sink->excess;
			was_change = 1;
			stall = 0;
		}

		if ((was_change && sf && stall >= sf)
			|| (rf && rf <= It - last)
			|| (Gap && Big)){

			stall = 0;
			was_change = 0;
			last = It;
			Big = 0;

			if (big_relabel(n, big)){
				big = 0;
			}
		}
	}

	n->maxflow = Sink->excess;
}

/*==================================================================*/

static void pushrelabel(vertex *v)
{
	int    vl;
	edge   *e;
	vertex * w;

	e = *v->current;
	w = OTHER(v, e);

	if (v->label == w->label + 1 && RESCAP(v, e) > ZERO){
		if (w->excess > -ZERO && w->excess<ZERO && w != Source && w != Sink)
		  enqueue(Qv, w);
		push(v, e);
	}
	else if (v->current == LAST_EDGE(v)){
		v->current = v->edgelist;

		if (Gap && v->label < Vertnum){
			(Labarr[(vl = v->label)])--;
			relabel(v);

			if (v->label < Vertnum){
				(Labarr[v->label])++;
				if (v->label > Labarr[0])
				  Labarr[0] = v->label;
			}else{
				if (vl == Labarr[0] && Labarr[vl] == 0)
				  (Labarr[0])--;
			}
			
			if (Labarr[vl] == 0 && vl < Labarr[0])
			  Big = 1;
			else
			  Big = 0;

		}else
		  relabel(v);
	}else
	  v->current++;
}

/*==================================================================*/

static void discharge(vertex *v)
{
	int d;

	d = v->label;
	while (v->label == d && v->excess > ZERO)
	       pushrelabel(v);
}

/*==================================================================*/

static void push(vertex *v, edge *e)
{
	DOUBLE c;

	c = RESCAP(v, e);
	c = MIN2(c, v->excess);

	v->excess -= c;

	if (OUT_EDGE(v, e)){
		e->flow += c;
		e->to->excess += c;
	}else{
		e->flow -= c;
		e->from->excess += c;
	}
}

/*==================================================================*/

static void relabel(vertex *v)
{
	int i, l;
	edge * e, ** ep;
	vertex * w;

	for (v->label = Inf, i = 0, ep = v->edgelist ; i < v->degree; i++){
		e = ep[i];
		w = OTHER(v, e);

		if ((l = w->label) < v->label && RESCAP(v, e) > ZERO)
		  v->label = l;
	}
	v->label += 1;
}


/*===============================================================*/

static  int     big_relabel(n, big)
network *n;
int     big;
			/* Bfs from the sink, searching for the
						   min_cut if exists already. Returns
						   true if mincut is found.
						   Finally search from the source on the left
						   partition of the cut (not necessarely min).
						   Relabels all the vertices.
						   Does an init_heap, and init_tree.
						   Calling freqency is heuristic.*/
{
	int i;
	int min_cut;

	if (Gap)  Labarr[0] = Maxlev = 0;

	for (i = 1; i <= Vertnum; i++){
		n->verts[i].label = Inf;
		if (Gap)  Labarr[i] = 0;
	}

	if (big)
	  min_cut = search(Sink, Q, 0);
	else
	  min_cut = 0;

	if (Gap)  Labarr[0] = Maxlev;

	if (Source->label < Vertnum)
	  Source->label = Vertnum;
	else
	  search(Source, Q, Vertnum);

	return (min_cut);
}

/*==================================================================*/

static int    search(source, q, start_label)
vertex *source;
queue  *q;
int    start_label;
{
	int    i, level;
	int    mincut;
	vertex * v, * w;
	edge   * e, **ve;

	level = start_label;
	mincut = 1;

	init_queue(q);
	enqueue(q, source);
	enqueue(q, NULL);

	while (1){
		v = (vertex *)dequeue(q);
		if (v == NULL){
			if (IS_EMPTY_QUEUE(q))
			  break;

			level++;
			enqueue(q, NULL);
		}else{
			v->label = level;

			if (Gap && level < Vertnum) (Labarr[level])++;

			ve = v->edgelist;
			for (i = 0; i < v->degree; i++){
				e = ve[i];

				if (v == e->from){
					if (((w = e->to)->label == Inf)
						&& (e->flow > ZERO))
					  {
						  if (mincut && w->excess > ZERO)
							mincut = 0;

						  w->label = -1;
						  enqueue(q, w);
					  }
				}else{
					if (((w = e->from)->label == Inf)
						&& (e->cap > e->flow + ZERO))
					  {
						  if (mincut && w->excess > ZERO)
							mincut = 0;

						  w->label = -1;
						  enqueue(q, w);
					  }
				}
			}
		}
	}
	Maxlev = level;

	return (mincut);
}

/*=================================================================*/

static  int     check_maxflow(n,flow)
network *n;
DOUBLE  *flow;
{
	int     i,j,level;
	edge    *e;
	vertex  *v,*w;
	DOUBLE  cut1cap,cut2cap;

	if(n->maxflow > Upper_flow -ZERO ) return(0);

	loop_in_flow(n);

/* A breadth first search from the source through the residual graph */

	for (i = 1; i <= Vertnum; i++)
	  n->verts[i].label = Inf;

	level = 1;

	Q = new_queue( 2*Vertnum );
	init_queue(Q);
	enqueue(Q, Source);
	enqueue(Q, NULL);

	e = Source->edgelist[0];
	e->cap = e->flow + 1;       /* J.J.Salazar */

	while (1){
		v = (vertex *)dequeue(Q);
		if (v == NULL){
			if (IS_EMPTY_QUEUE(Q) || bad_cut() )
			  break;
			level++;
			enqueue(Q, NULL);
		}else{
			v->label = level;
			for (i = 0; i < v->degree; i++){
				e = v->edgelist[i];
				w = OTHER(v, e);
				if( w->label == Inf
					&& RESCAP(v, e) > ZERO)
				  {
					  w->label = -1;
					  enqueue(Q, w);
				  }
			}
		}
	} /* end of search */
	free_queue(Q);

	for (i = 1, cut1cap = 0; i <= Vertnum; i ++){
						 /* counting the minimum
											cut value */
		v = &(n->verts[i]);
		if (v->label < Inf){
			for (j = 0; j < v->degree; j++){
				e = v->edgelist[j];
				if (e->flow > e->cap +ZERO){
				  printf("ERROR: Capacity bound is hurt!");
				  exit(1);
				}
				if (OUT_EDGE(v, e) && OTHER(v, e)->label == Inf)
				  cut1cap += e->cap;
			}
		}
	}

/* saving the minimum-cut , minimal containing the sink */

/******
	if(cut1){
	    cut1--;
	    for(i=1;i<Vertnum;i++){
		if(n->verts[i].label<Inf)
		    cut1[i]=1;
		else
		    cut1[i]=0;
	    }
	}
*******/
/* A breadth first search from the sink through the residual graph */

	for (i = 1; i <= Vertnum; i++)
	  n->verts[i].label = Inf;

	level = 1;

	Q = new_queue( 2*Vertnum );
	init_queue(Q);
	enqueue(Q, Sink);
	enqueue(Q, NULL);

	e = Source->edgelist[0];
	e->cap = e->flow + 1;       /* J.J.Salazar */

	while (1){
		v = (vertex *)dequeue(Q);
		if (v == NULL){
			if (IS_EMPTY_QUEUE(Q) || bad_cut() )
			  break;
			level++;
			enqueue(Q, NULL);
		}else{
			v->label = level;
			for (i = 0; i < v->degree; i++){
				e = v->edgelist[i];
				w = OTHER(v, e);
				if( w->label == Inf
					&& RESCAP(w, e) > ZERO)
				  {
					  w->label = -1;
					  enqueue(Q, w);
				  }
			}
		}
	} /* end of search */
	free_queue(Q);

	for (i = 1, cut2cap = 0; i <= Vertnum; i ++){
						 /* counting the minimum
											cut value */
		v = &(n->verts[i]);
		if (v->label < Inf){
			for (j = 0; j < v->degree; j++){
				e = v->edgelist[j];
				w = OTHER(v, e);
				if (e->flow > e->cap +ZERO){
				  printf("ERROR: Capacity bound is hurt!");
				  exit(1);
				}
				if (OUT_EDGE(w, e) && w->label == Inf)
				  cut2cap += e->cap;
			}
		}
	}

/* saving the minimum-cut , minimal containing the sink */

/*******
	if(cut2){
	    cut2--;
	    for(i=1;i<Vertnum;i++){
		if(n->verts[i].label<Inf)
		    cut2[i]=0;
		else
		    cut2[i]=1;
	    }
	}
*******/

/* saving the flow */

	if(flow){
	    flow--;
	    for(i=1;i<Edgenum;i++)
		flow[i] = n->edges[i].flow;
	}

	if (n->maxflow < cut1cap-ZERO_CHECK ||
	    n->maxflow > cut1cap+ZERO_CHECK ||
	    cut1cap - cut2cap >  ZERO_CHECK ||
	    cut2cap - cut1cap >  ZERO_CHECK ){
	     printf(" maxflow=%f  cut1cap=%f  cut2cap=%f\n",
		    (float)n->maxflow,(float)cut1cap,(float)cut2cap);
	     return 1;
	}
	return 0;
}

static void loop_in_flow(n)
network *n;
{
    int    i,j,nlist;
    struct VERTEX *u,*v;
    edge   **list;

    list = (edge **)malloc( Edgenum * sizeof(edge *) );
    for(nlist=0,i=1;i<Edgenum;i++)
	if( n->edges[i].flow > ZERO )
	    list[ nlist++ ] = n->edges +i;
    i = nlist;
    while(i--){
	u = list[i]->from;
	v = list[i]->to;
	j = i;
	while(j--)
	    if( list[j]->to == u && list[j]->from == v ){
/*
		printf("WARNING: twice (%d,%d) in flow at %lf y %lf\n",
		     u->index,v->index,list[i]->flow,list[j]->flow);
*/
		if( list[i]->flow > list[j]->flow ){
		    list[i]->flow -= list[j]->flow;
		    list[j]->flow  = 0;
		} else {
		    list[j]->flow -= list[i]->flow;
		    list[i]->flow  = 0;
		}
	    }
    }
    free( list );
}

static void compute_cuts(n,ncut,cut)
network     *n;
int         *ncut;
short int   *cut;
{
    int       i,nstack,maxncut;
    edge      *e;
    vertex    *v,*w,*seed,**stack;
    short int *ptr;

    maxncut = *ncut;
    *ncut = 0;
    if( maxncut<1 || n->maxflow > Upper_flow-ZERO ) return;

    stack = (vertex **)malloc( Vertnum * sizeof( vertex * ) );
    if( stack==NULL ){
	printf("ERROR: not enough memory in computing cuts\n");
	return;
    }

    for( i=1 ; i<Vertnum ; i++ ) n->verts[i].label = 1;

    stack[ 0 ] = Sink;
    Sink->label = 2;
    nstack = 1;
    while( nstack ){
	v = stack[ --nstack ];
	for( i=0 ; i<v->degree ; i++ ){
	    e = v->edgelist[i];
	    w = OTHER( v , e );
	    if( w->label == 1 && RESCAP(w,e)>ZERO ){
		stack[ nstack++ ] = w;
		w->label = 2;
	    }
	}
    }

    cut--;
    for( i=1 ; i<Vertnum ; i++ ){          /* first cut === last cut */
	if( n->verts[i].label == 2 ) cut[i]=0;
	else                         cut[i]=1;
    }
    (*ncut)++;
    if( *ncut == maxncut ) {
      /* printf("exit without freeing\n"); */
      free( stack );
      return;
    }
    cut += (Vertnum-1);

    seed = Source;
    for(i=1;i<Vertnum;i++) cut[i]=0;

    while(1){

	stack[ nstack++ ] = seed;
	seed->label = 0;
	
	while( nstack ){
	    v = stack[ --nstack ];
	    for( i=0 ; i<v->degree ; i++ ){
		e = v->edgelist[i];
		w = OTHER( v , e );
		if( w->label == 1 ){
		    if( RESCAP(v,e)>ZERO ){
			stack[ nstack++ ] = w;
			w->label = 0;
			cut[ w->index ] = 1;
		    } else {
			seed = w;
		    }
		}
	    }
	}

	(*ncut) ++;

	if( seed->label != 1 ){
	    for( i=1 ; i<Vertnum ; i++ )
		if( n->verts[i].label == 1 ) break;
	    if( i==Vertnum ) {
		(*ncut)--;                 /* last cut === first cut */
		break;
	    }
	    seed = n->verts + i;
	}
	
	if( *ncut == maxncut ) break;
	ptr = cut;
	cut += (Vertnum-1);
	for(i=1;i<Vertnum;i++) cut[i]=ptr[i];
	cut[ seed->index ] = 1;
    }
    free( stack );
}

    

/*=================================================================*/

static queue * new_queue(int size)
{
	queue * q;

	q = (queue *)malloc(sizeof(queue));
	q->first = q->last = q->start
	  = (queue_node *)calloc(size+1, sizeof(queue_node));
			  /*  J.J.Salazar  +1  */
	q->end = &q->start[size];

	return q;
}


static void init_queue(queue *q)
{
	q->first = q->last = q->start;
}

static void free_queue(queue *q)
{
	free(q->start);
	free(q);
}

static void enqueue(queue *q, void *item)
{
	q->last->data = item;

	if (q->last == q->end)
	  q->last = q->start;
	else
	  q->last++;
}

static void * dequeue(queue *q)
{
	void * data;

	data = q->first->data;

	if (q->first == q->end)
	  q->first = q->start;
	else
	  q->first++;

	return(data);
}

/*
static void print_queue(queue *q)
{
    printf(" first=%u  last=%u  start=%u  end=%d\n",q->first,q->last,q->start,q->end);
}
*/
static int bad_cut()
{
     int l1,l2;

     l1 = OTHER( Source , Source->edgelist[0] )->label;
     l2 = Sink->label;

     if( l1 < Inf && l1 > -1 && l2 < Inf && l2 > -1 )
	  return(1);
     return(0);
}
