

/**************************************************************

    Routines for computing a Max-Flow (Min-Cut) in a directed
    network by using the Pre-flow algorithm of Golberg (1989).

    The capacity of the edges (itypeflow) is defined by in the
    following line:                                          
*/

#ifndef MAXFLOW_H
#define MAXFLOW_H

#ifdef __cplusplus
	extern "C" {
#endif


/*** headers included ***/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

#define itypeflow double

/*
    INPUT for goldberg():

	 int    vertices;
	 int    edges;
	 int    source;
	 int    sink;
	 int    fr [0...edges-1];
	 int    to [0...edges-1];
	 itypeflow cap[0...edges-1];
	 itypeflow *minmax;            =upper bound on the max-flow
	 int    *ncut;              =maximum number of different min-cuts

	 ( indexes for vertices in {1,...,vertices} )

    OUTPUT for golberg():

	 itypeflow *minmax;               
	 itypeflow flow[0...edges-1];    
	 int    *ncut;              =number of different nested min-cuts
	 short int cut [0...(*ncut)*vertices -1];

***************************************************************/

/*--------------------------------- Parameters --------------*/

#define ZERO        0.0001        /* for testing float's for equality */
#define ZERO_CHECK  0.01        /* for checking the flow - cut      */

/*--------------------------------- Include files -----------*/


/*--------------------------------- Data Structure ----------*/

typedef struct VERTEX{
	struct EDGE ** edgelist;  /* Pointer to the list of pointers to
				     			 the adjacent edges.
				     			(No matter that to or from edges) */
	struct EDGE ** current;   /* Pointer to the current edge       */
	itypeflow excess;            /* Excess in the pre-flow            */
	int    degree;            /* Number of adjacent edges (both direction)*/
	int    index;             /* Name of the vertex                */
	int    label;             /* Distance label                    */
}vertex;

typedef struct EDGE{
	struct VERTEX *from;
	struct VERTEX *to;
	itypeflow flow;              /* Flow value */
	itypeflow cap;               /* Capacity */
}edge;

typedef struct NETWORK{
	int    vertnum;
	int    edgenum;
	vertex *verts;           /* Vertex array[1..vertnum] */
	edge   *edges;           /* Edge array[1..edgenum] */
	vertex *source;          /* Pointer to the source */
	vertex *sink;            /* Pointer to the sink */
	itypeflow maxflow;          /* the value of the maximum flow */
}network;

typedef struct QUEUE_NODE{
	void * data;
}queue_node;

typedef struct QUEUE{
	struct QUEUE_NODE * first;
	struct QUEUE_NODE * last;
	struct QUEUE_NODE * start;
	struct QUEUE_NODE * end;
}queue;

#define IS_EMPTY_queue(g,q) ((q)->first == (q)->last)

typedef struct GLOBAL
{
	int    Vertnum, Edgenum;
	vertex * Source, * Sink;
	int    * Labarr;
	queue  * Q;
	queue  * Qv;
	char   Gap;
	int    It,Inf,Big,Maxlev;
	itypeflow Flow_bound,Upper_flow;
} global_t;
/*---------------------------------- Global data ---------*/




/*--------------------------------- Macro definitions ---------*/

#define OUT_EDGE(V, E) ((E)->from == V)
#define RESCAP(V, E)   ((OUT_EDGE(V, E)) ? ((E)->cap - (E)->flow) : (E)->flow)
#define OTHER(V, E)    (OUT_EDGE(V, E) ? (E)->to : (E)->from)
#define LAST_EDGE(V)   (&((V)->edgelist[(V)->degree -1]))
#define MIN2(A,B)      (((A)<(B))?(A):(B))

/*--------------------------------- Function Prototypes ------*/

void    goldberg(int, int, int, int, int*, int*, itypeflow*, itypeflow*, itypeflow*, int*, short int *);

network *load_net(global_t*,int,int,int,int,int *,int *,itypeflow *);
void    free_net(global_t*,network *);
void    print_DIMACS_std(global_t*,char *, network *);
int     maxflow_start(global_t*,network *);
itypeflow  search_cut(global_t*,network *, vertex *, queue *, int);
void    maxflow(global_t*,network *);
void    pushrelabel(global_t*,vertex *);
void    discharge(global_t*,vertex *);
void    push(global_t*,vertex *, edge *);
void    relabel(global_t*,vertex *);
int     big_relabel(global_t*,network *, int);
int     search(global_t*,vertex *, queue *, int);
int     check_maxflow(global_t*,network *,itypeflow *);
queue   * new_queue(global_t*,int);
void    init_queue(global_t*,queue *);
void    free_queue(global_t*,queue *);
void    enqueue(global_t*,queue *, void *);
void    * dequeue(global_t*,queue *);
//void    print_queue(g,queue *);
int     bad_cut(global_t*);
void    compute_cuts(global_t*,network *,int *,short int *);
void    loop_in_flow(global_t*,network *);

/*---------------------------------- Function Definitions ------*/

void goldberg(int vertices,int edges,int source,int sink,int *fr,int *to,itypeflow *cap,itypeflow *minmax,itypeflow *flow,int *ncut,short int *cut)
{	
	//int i;
	//if(ncut != NULL)
	//for(i=0;i<edges;i++)
	//	printf("from:%d to:%d cap:%d\n", fr[i],to[i],(int)cap[i]);
	
	global_t g;
	g.Gap = 0;
	g.Upper_flow = *minmax;
	network* n = load_net(&g,vertices,edges,source,sink,fr,to,cap);
		
	if(maxflow_start(&g,n))
	{
	//    printf(" WARNING: not feasible flow solution ");
	//    print_DIMACS_std(g,"flow.dat",n);
	}

	/*if(n->maxflow < Upper_flow - ZERO && check_maxflow(g,n,flow))
	{      
		printf(" ERROR: wrong maxflow value!!! ");
		print_DIMACS_std(g,(char*)"flow.dat",n);
		*minmax=1000000.0;
		printf("ERROR IN MAXFLOW!\n");
		return;
	}*/
	if(ncut != NULL && cut != NULL)
		compute_cuts(&g,n,ncut,cut);
	*minmax = n->maxflow;
	free_net(&g,n);
}

/*==================================================================*/

network * load_net(global_t*g,int vertices,int edges,int source, int sink,int *fr,int *to,itypeflow *cap)
{
	int     k;
	network * n;
	edge    * ed , * ne, * e;
	vertex  * nv, *v, *s;

	g->Q = g->Qv = NULL;
	g->Labarr = (int *)calloc((unsigned int)vertices+2, sizeof(int));

	n = (network *)malloc(sizeof(network));
	n->vertnum = vertices;
	n->edgenum = edges;
	n->verts   = (vertex *)calloc(n->vertnum + 2, sizeof(vertex));
	n->source  = &((n->verts)[source]);
	n->sink    = &((n->verts)[sink]);
	n->edges   = (edge *)calloc(n->edgenum + 2, sizeof(edge));
	n->maxflow = 0;

	ed = n->edges + 1;
	for(k=0;k<edges;k++)
	{
		ed->from = &((n->verts)[ fr[k] ]);
		ed->to   = &((n->verts)[ to[k] ]);
		ed->cap  = cap[k];
		ed->flow = 0;
		
		int frk = fr[k];
		int tok = to[k];
		n->verts[ fr[k] ].degree++;
		n->verts[ to[k] ].degree++;
		ed++;
	}

	n->source->degree++;

	/*------ Now build the adjacency lists for each vertex ----*/
	nv = n->verts;
	for( k = 1; k <= n->vertnum; k++) /* Edgelist allocation */
	{
		v = &(nv[k]);
		if(v->degree)
		    v->edgelist = (edge **)calloc(v->degree, sizeof(edge *));
		else
		    v->edgelist = NULL;
		v->current = v->edgelist;
	}
	ne = n->edges;
	for( k = 1; k <= n->edgenum; k++)/* Fill in the edgelists */
	{
		
		e = &(ne[k]);
		*(e->from->current) = e;
		*(e->to->current) = e;
		(e->from->current)++;
		(e->to->current)++;
	}

/* Artificial source + edge */
/* (This makes the n->verts and n->edges arrays one longer) */

	n->vertnum++;
	n->edgenum++;

	e = &(n->edges[n->edgenum]);
	v = &(n->verts[n->vertnum]);
	v->degree      = 1;
	v->edgelist    = (edge **)calloc(1, sizeof(edge *));
	*(v->edgelist) = e;
	s = n->source;
	*(s->current) = e;
	e->from = v;
	e->to   = s;
	e->cap  = 1; /* and will be setted after to an upper flow bound */
	e->flow = 0;
	n->source = v;

	nv = n->verts;
	for( k = 1 ; k <= n->vertnum; k++)
	{
		v = &(nv[k]);
		v->current = v->edgelist;
		v->index   = k;
	}
	return n;
}

/*===============================================================*/

void free_net(global_t*g,network *n)
{
	int  i;
	edge **ptr;

	i = n->vertnum;
	while(i){
	     ptr = (n->verts[i--]).edgelist;
	     if( ptr ) free(ptr);
	}

	free(n->edges);
	free(n->verts);
	free(n);
	free(g->Labarr);
}

/*==================================================================*/

void print_DIMACS_std (global_t*g,char *name, network *n)

{
	int  i, vnum, e_num;
	edge * e;
	FILE * Output;

	vnum  = n->vertnum - 1;
	e_num = n->edgenum - 1;

	Output = fopen(name,"w");
	if (Output == NULL) {
	     printf("ERROR: it is not possible to open %s\n",name);
	     exit(1);
	}
	printf(" Writing network to file %s ...\n",name);

	fprintf(Output, "c --------------------------------------------\n");
	fprintf(Output, "c Parameters of the network:\n");
	fprintf(Output, "p max %d %d\n", vnum, e_num);
	fprintf(Output, "n %d s\n",(n->source->edgelist[0])->to->index);
	fprintf(Output, "n %d t\n", n->sink->index);
	for (i = 1; i <= e_num; i++){
		e = &n->edges[i];
		fprintf(Output, "a %d %d %f\n"
			   , e->from->index, e->to->index, (float)e->cap);
	}
	fprintf(Output, "c --------------------------------------------\n");
	fprintf(Output, "c The maximum flow value:\n");
	fprintf(Output, "c %f\n", (float)n->maxflow);
	fprintf(Output, "c --------------------------------------------\n");
	fprintf(Output, "c Flow values of the edges:\n");
	fprintf(Output, "c         FROM       TO                FLOW\n");
	fprintf(Output, "c --------------------------------------------\n");

	for (i = 1; i <= e_num; i++){
		e = &n->edges[i];
		fprintf(Output, "f %8d %8d %f\n"
			   , e->from->index, e->to->index, (float)e->flow);
	}
	fclose( Output );
}

/*===============================================================*/
/* After the allocations, with
			 a prepared network * n, and
			 a given preflow, it will
			 start the maxflow algorithm 
*/

int maxflow_start(global_t*g,network *n)		      
{

	/*---- Fill up the global variables ----*/

	g->Source  = n->source;
	g->Sink    = n->sink;
	g->Vertnum = n->vertnum;
	g->Edgenum = n->edgenum;
	g->Inf     = 3 * g->Vertnum;

	/*---- Default values of the frequencies ----*/

	g->Source->edgelist[0]->flow = g->Upper_flow;
	g->Source->edgelist[0]->cap = g->Upper_flow;
	g->Source->edgelist[0]->to->excess = g->Upper_flow;
	g->Source->excess = -g->Upper_flow;

	g->Q = new_queue(g,2*g->Vertnum);
	g->Flow_bound = g->Upper_flow;
	search_cut(g,n, g->Sink, g->Q, 0);
	(*(g->Source->edgelist))->cap = g->Flow_bound;

	if (big_relabel(g,n, 1) && g->Sink->excess<ZERO && g->Sink->excess> -ZERO){
	    free_queue(g,g->Q);
	    return 1;              /* No feasible solution */
	}

	(*(g->Source->edgelist))->cap = g->Flow_bound;   /* J.J.Salazar */
	(*(g->Source->edgelist))->flow = g->Flow_bound;
	(*(g->Source->edgelist))->to->excess = g->Flow_bound;
	g->Source->excess = -g->Flow_bound;

	g->Qv = new_queue(g,2*g->Vertnum);
	enqueue(g,g->Qv, (*(g->Source->edgelist))->to);

	maxflow(g,n);
	free_queue(g,g->Qv);
	free_queue(g,g->Q);
	return 0;
}


/*==================================================================*/

itypeflow search_cut(global_t*g,network *n, vertex *source, queue *q, int start_level)
{
	int    i, level;
	itypeflow cutcap = 0;
	vertex * v, * w;
	edge   * e, **ve;

	for( i = 1; i <= g->Vertnum;  i++)
		n->verts[i].label = g->Inf;

	level = start_level;
	init_queue(g,q);
	enqueue(g,q, source);
	enqueue(g,q, NULL);

	while (1){
		v = (vertex *)dequeue(g,q);
		if (v == NULL){
			if (IS_EMPTY_queue(g,q) || bad_cut(g) )
			  break;

			level++;
			if (cutcap < g->Flow_bound-ZERO)
			  g->Flow_bound = cutcap;
			cutcap = 0;
			enqueue(g,q, NULL);
		}else{
			v->label = level;
			ve = v->edgelist;
			for (i = 0; i < v->degree; i++){
				e = ve[i];

				if (v == e->to){
					if ((w = e->from)->label == g->Inf || w->label == -1)
					  {
						  cutcap += (e->cap);
						  if (w->label == g->Inf){
							  w->label = -1;
							  enqueue(g,q, w);
						  }
					  }
				}
			}
		}
	}
	return( cutcap );
}


/*==================================================================*/
/* Finds the max-flow in the initialized
		network n using the GOLD alg.  */
void maxflow(global_t*g,network *n)	 
{
	vertex *v;
	int    sf, rf, last;
	int    big = 1, stall = 0, was_change = 0;
	itypeflow old_fl;

	g->It    = g->Big = 0;
	last  = 0;
	sf    = g->Vertnum / 2;
	rf    = g->Edgenum;
	g->Gap   = 1;

	while (!IS_EMPTY_queue(g,g->Qv)){
		g->It++;

		v = (vertex *)dequeue(g,g->Qv);

		if (v == NULL){
		      printf("Null dequeued\n");
		      exit(1);
		}

		old_fl = g->Sink->excess;

		discharge(g,v);

		if (v->excess > ZERO && v->label != g->Inf)
			enqueue(g,g->Qv, v);

		/* -------------------------------------
		   Big_relabel heuristics
		   -------------------------------------*/

		if (g->Sink->excess>old_fl-ZERO && g->Sink->excess<old_fl+ZERO )
			stall++;
		else{
			old_fl = g->Sink->excess;
			was_change = 1;
			stall = 0;
		}

		if ((was_change && sf && stall >= sf)
			|| (rf && rf <= g->It - last)
			|| (g->Gap && g->Big)){

			stall = 0;
			was_change = 0;
			last = g->It;
			g->Big = 0;

			if (big_relabel(g,n, big)){
				big = 0;
			}
		}
	}

	n->maxflow = g->Sink->excess;
}

/*==================================================================*/

void pushrelabel(global_t*g,vertex *v)
{
	int    vl;
	edge   *e;
	vertex * w;

	e = *v->current;
	w = OTHER(v, e);

	if (v->label == w->label + 1 && RESCAP(v, e) > ZERO){
		if (w->excess > -ZERO && w->excess<ZERO && w != g->Source && w != g->Sink)
		  enqueue(g,g->Qv, w);
		push(g,v, e);
	}
	else if (v->current == LAST_EDGE(v)){
		v->current = v->edgelist;

		if (g->Gap && v->label < g->Vertnum){
			(g->Labarr[(vl = v->label)])--;
			relabel(g,v);

			if (v->label < g->Vertnum){
				(g->Labarr[v->label])++;
				if (v->label > g->Labarr[0])
				  g->Labarr[0] = v->label;
			}else{
				if (vl == g->Labarr[0] && g->Labarr[vl] == 0)
				  (g->Labarr[0])--;
			}
			
			if (g->Labarr[vl] == 0 && vl < g->Labarr[0])
			  g->Big = 1;
			else
			  g->Big = 0;

		}else
		  relabel(g,v);
	}else
	  v->current++;
}

/*==================================================================*/

void discharge(global_t*g,vertex *v)
{
	int d;

	d = v->label;
	while (v->label == d && v->excess > ZERO)
	       pushrelabel(g,v);
}

/*==================================================================*/

void push(global_t*g,vertex *v, edge *e)
{
	itypeflow c;

	c = RESCAP(v, e);
	c = MIN2(c, v->excess);

	v->excess -= c;

	if (OUT_EDGE(v, e)){
		e->flow += c;
		e->to->excess += c;
	}else{
		e->flow -= c;
		e->from->excess += c;
	}
}

/*==================================================================*/

void relabel(global_t*g,vertex *v)
{
	int i, l;
	edge * e, ** ep;
	vertex * w;

	for (v->label = g->Inf, i = 0, ep = v->edgelist ; i < v->degree; i++){
		e = ep[i];
		w = OTHER(v, e);

		if ((l = w->label) < v->label && RESCAP(v, e) > ZERO)
		  v->label = l;
	}
	v->label += 1;
}


/*===============================================================*/
/* Bfs from the sink, searching for the
   min_cut if exists already. Returns
   true if mincut is found.
   Finally search from the source on the left
   partition of the cut (not necessarely min).
   Relabels all the vertices.
   Does an init_heap, and init_tree.
   Calling freqency is heuristic.
*/
int big_relabel(global_t*g,network *n,int big)
{
	int i;
	int min_cut;

	if (g->Gap)  g->Labarr[0] = g->Maxlev = 0;

	for (i = 1; i <= g->Vertnum; i++){
		n->verts[i].label = g->Inf;
		if (g->Gap)  g->Labarr[i] = 0;
	}

	if (big)
	  min_cut = search(g,g->Sink, g->Q, 0);
	else
	  min_cut = 0;

	if (g->Gap)  g->Labarr[0] = g->Maxlev;

	if (g->Source->label < g->Vertnum)
	  g->Source->label = g->Vertnum;
	else
	  search(g,g->Source, g->Q, g->Vertnum);

	return (min_cut);
}

/*==================================================================*/

int search(global_t*g,vertex *source,queue *q,int start_label)
{
	int    i, level;
	int    mincut;
	vertex * v, * w;
	edge   * e, **ve;

	level = start_label;
	mincut = 1;

	init_queue(g,q);
	enqueue(g,q, source);
	enqueue(g,q, NULL);

	while (1){
		v = (vertex *)dequeue(g,q);
		if (v == NULL){
			if (IS_EMPTY_queue(g,q))
			  break;

			level++;
			enqueue(g,q, NULL);
		}else{
			v->label = level;

			if (g->Gap && level < g->Vertnum) (g->Labarr[level])++;

			ve = v->edgelist;
			for (i = 0; i < v->degree; i++){
				e = ve[i];

				if (v == e->from){
					if (((w = e->to)->label == g->Inf)
						&& (e->flow > ZERO))
					  {
						  if (mincut && w->excess > ZERO)
							mincut = 0;

						  w->label = -1;
						  enqueue(g,q, w);
					  }
				}else{
					if (((w = e->from)->label == g->Inf)
						&& (e->cap > e->flow + ZERO))
					  {
						  if (mincut && w->excess > ZERO)
							mincut = 0;

						  w->label = -1;
						  enqueue(g,q, w);
					  }
				}
			}
		}
	}
	g->Maxlev = level;

	return (mincut);
}

/*=================================================================*/

int check_maxflow(global_t*g,network *n,itypeflow *flow)
{
	int     i,j,level;
	edge    *e;
	vertex  *v,*w;
	itypeflow  cut1cap,cut2cap;

	if(n->maxflow > g->Upper_flow -ZERO ) return(0);

	loop_in_flow(g,n);

/* A breadth first search from the source through the residual graph */

	for (i = 1; i <= g->Vertnum; i++)
	  n->verts[i].label = g->Inf;

	level = 1;

	g->Q = new_queue(g, 2*g->Vertnum );
	init_queue(g,g->Q);
	enqueue(g,g->Q, g->Source);
	enqueue(g,g->Q, NULL);

	e = g->Source->edgelist[0];
	e->cap = e->flow + 1;       /* J.J.Salazar */

	while (1){
		v = (vertex *)dequeue(g,g->Q);
		if (v == NULL){
			if (IS_EMPTY_queue(g,g->Q) || bad_cut(g) )
			  break;
			level++;
			enqueue(g,g->Q, NULL);
		}else{
			v->label = level;
			for (i = 0; i < v->degree; i++){
				e = v->edgelist[i];
				w = OTHER(v, e);
				if( w->label == g->Inf
					&& RESCAP(v, e) > ZERO)
				  {
					  w->label = -1;
					  enqueue(g,g->Q, w);
				  }
			}
		}
	} /* end of search */
	free_queue(g,g->Q);

	for (i = 1, cut1cap = 0; i <= g->Vertnum; i ++){
						 /* counting the minimum
											cut value */
		v = &(n->verts[i]);
		if (v->label < g->Inf){
			for (j = 0; j < v->degree; j++){
				e = v->edgelist[j];
				if (e->flow > e->cap +ZERO){
				  printf("ERROR: Capacity bound is hurt!");
				  exit(1);
				}
				if (OUT_EDGE(v, e) && OTHER(v, e)->label == g->Inf)
				  cut1cap += e->cap;
			}
		}
	}

/* saving the minimum-cut , minimal containing the sink */

/******
	if(cut1){
	    cut1--;
	    for(i=1;i<Vertnum;i++){
		if(n->verts[i].label<Inf)
		    cut1[i]=1;
		else
		    cut1[i]=0;
	    }
	}
*******/
/* A breadth first search from the sink through the residual graph */

	for (i = 1; i <= g->Vertnum; i++)
	  n->verts[i].label = g->Inf;

	level = 1;

	g->Q = new_queue(g, 2*g->Vertnum );
	init_queue(g,g->Q);
	enqueue(g,g->Q, g->Sink);
	enqueue(g,g->Q, NULL);

	e = g->Source->edgelist[0];
	e->cap = e->flow + 1;       /* J.J.Salazar */

	while (1){
		v = (vertex *)dequeue(g,g->Q);
		if (v == NULL){
			if (IS_EMPTY_queue(g,g->Q) || bad_cut(g) )
			  break;
			level++;
			enqueue(g,g->Q, NULL);
		}else{
			v->label = level;
			for (i = 0; i < v->degree; i++){
				e = v->edgelist[i];
				w = OTHER(v, e);
				if( w->label == g->Inf
					&& RESCAP(w, e) > ZERO)
				  {
					  w->label = -1;
					  enqueue(g,g->Q, w);
				  }
			}
		}
	} /* end of search */
	free_queue(g,g->Q);

	for (i = 1, cut2cap = 0; i <= g->Vertnum; i ++){
						 /* counting the minimum
											cut value */
		v = &(n->verts[i]);
		if (v->label < g->Inf){
			for (j = 0; j < v->degree; j++){
				e = v->edgelist[j];
				w = OTHER(v, e);
				if (e->flow > e->cap +ZERO){
				  printf("ERROR: Capacity bound is hurt!");
				  exit(1);
				}
				if (OUT_EDGE(w, e) && w->label == g->Inf)
				  cut2cap += e->cap;
			}
		}
	}

/* saving the minimum-cut , minimal containing the sink */

/*******
	if(cut2){
	    cut2--;
	    for(i=1;i<Vertnum;i++){
		if(n->verts[i].label<Inf)
		    cut2[i]=0;
		else
		    cut2[i]=1;
	    }
	}
*******/

/* saving the flow */

	if(flow){
	    flow--;
	    for(i=1;i<g->Edgenum;i++)
			flow[i] = n->edges[i].flow;
	}

	if (n->maxflow < cut1cap-ZERO_CHECK ||
	    n->maxflow > cut1cap+ZERO_CHECK ||
	    cut1cap - cut2cap >  ZERO_CHECK ||
	    cut2cap - cut1cap >  ZERO_CHECK ){
	     printf(" maxflow=%f  cut1cap=%f  cut2cap=%f\n",
		    (float)n->maxflow,(float)cut1cap,(float)cut2cap);
	     return 1;
	}
	return 0;
}

void loop_in_flow(global_t*g,network *n)
{
    int    i,j,nlist;
    struct VERTEX *u,*v;
    edge   **list;

    list = (edge **)malloc( g->Edgenum * sizeof(edge *) );
    for(nlist=0,i=1;i<g->Edgenum;i++)
	if( n->edges[i].flow > ZERO )
	    list[ nlist++ ] = n->edges +i;
    i = nlist;
    while(i--){
	u = list[i]->from;
	v = list[i]->to;
	j = i;
	while(j--)
	    if( list[j]->to == u && list[j]->from == v ){
/*
		printf("WARNING: twice (%d,%d) in flow at %lf y %lf\n",
		     u->index,v->index,list[i]->flow,list[j]->flow);
*/
		if( list[i]->flow > list[j]->flow ){
		    list[i]->flow -= list[j]->flow;
		    list[j]->flow  = 0;
		} else {
		    list[j]->flow -= list[i]->flow;
		    list[i]->flow  = 0;
		}
	    }
    }
    free( list );
}

void compute_cuts(global_t*g,network *n,int *ncut,short int *cut)
{
    int       i,nstack,maxncut;
    edge      *e;
    vertex    *v,*w,*seed,**stack;
    short int *ptr;

    maxncut = *ncut;
    *ncut = 0;
    if( maxncut<1 || n->maxflow > g->Upper_flow-ZERO ) return;

    stack = (vertex **)malloc( g->Vertnum * sizeof( vertex * ) );
    if( stack==NULL ){
	printf("ERROR: not enough memory in computing cuts\n");
	return;
    }

    for( i=1 ; i<g->Vertnum ; i++ ) n->verts[i].label = 1;

    stack[ 0 ] = g->Sink;
    g->Sink->label = 2;
    nstack = 1;
    while( nstack ){
	v = stack[ --nstack ];
	for( i=0 ; i<v->degree ; i++ ){
	    e = v->edgelist[i];
	    w = OTHER( v , e );
	    if( w->label == 1 && RESCAP(w,e)>ZERO ){
		stack[ nstack++ ] = w;
		w->label = 2;
	    }
	}
    }

    cut--;
    for( i=1 ; i<g->Vertnum ; i++ ){          /* first cut === last cut */
	if( n->verts[i].label == 2 ) cut[i]=0;
	else                         cut[i]=1;
    }
    (*ncut)++;
    if( *ncut == maxncut ) {
      /* printf("exit without freeing\n"); */
      free( stack );
      return;
    }
    cut += (g->Vertnum-1);

    seed = g->Source;
    for(i=1;i<g->Vertnum;i++) cut[i]=0;

    while(1){

	stack[ nstack++ ] = seed;
	seed->label = 0;
	
	while( nstack ){
	    v = stack[ --nstack ];
	    for( i=0 ; i<v->degree ; i++ ){
		e = v->edgelist[i];
		w = OTHER( v , e );
		if( w->label == 1 ){
		    if( RESCAP(v,e)>ZERO ){
			stack[ nstack++ ] = w;
			w->label = 0;
			cut[ w->index ] = 1;
		    } else {
			seed = w;
		    }
		}
	    }
	}

	(*ncut) ++;

	if( seed->label != 1 ){
	    for( i=1 ; i<g->Vertnum ; i++ )
		if( n->verts[i].label == 1 ) break;
	    if( i==g->Vertnum ) {
		(*ncut)--;                 /* last cut === first cut */
		break;
	    }
	    seed = n->verts + i;
	}
	
	if( *ncut == maxncut ) break;
	ptr = cut;
	cut += (g->Vertnum-1);
	for(i=1;i<g->Vertnum;i++) cut[i]=ptr[i];
	cut[ seed->index ] = 1;
    }
    free( stack );
}

    

/*=================================================================*/

queue * new_queue(global_t*g,int size)
{
	queue * q;

	q = (queue *)malloc(sizeof(queue));
	q->first = q->last = q->start
	  = (queue_node *)calloc(size+1, sizeof(queue_node));
			  /*  J.J.Salazar  +1  */
	q->end = &q->start[size];

	return q;
}


void init_queue(global_t*g,queue *q)
{
	q->first = q->last = q->start;
}

void free_queue(global_t*g,queue *q)
{
	free(q->start);
	free(q);
}

void enqueue(global_t*g,queue *q, void *item)
{
	q->last->data = item;

	if (q->last == q->end)
	  q->last = q->start;
	else
	  q->last++;
}

void * dequeue(global_t*g,queue *q)
{
	void * data;

	data = q->first->data;

	if (q->first == q->end)
	  q->first = q->start;
	else
	  q->first++;

	return(data);
}

/*
static void print_queue(g,queue *q)
{
    printf(" first=%u  last=%u  start=%u  end=%d\n",q->first,q->last,q->start,q->end);
}
*/
int bad_cut(global_t*g)
{
     int l1,l2;

     l1 = OTHER( g->Source , g->Source->edgelist[0] )->label;
     l2 = g->Sink->label;

     if( l1 < g->Inf && l1 > -1 && l2 < g->Inf && l2 > -1 )
	  return(1);
     return(0);
}

#ifdef __cplusplus
	}
#endif

#endif
