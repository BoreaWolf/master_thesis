
#include <stdio.h>
#include "MXF.h"
/*
	4 levels network
	In theory, the Maximum flow should be 744.

			-> 8
	-> 2 	-> 9
 1  -> 3 	-> 10
	-> 4	-> ...		-> 7
	-> 5 	-> ...		
	-> 6 	-> ...
			-> 25
*/



int main()
{
	
	int node_count = 20 - 2 + 7; 
	int arc_count = 6 * (20 - 2) + 5;
	MaxFlowPtr p;
	MXF_InitMem(&p,node_count,arc_count);
	MXF_ClearNodeList(p);
	MXF_ClearArcList(p);
	MXF_SetNodeListSize(p,node_count);
	
	MXF_AddArc(p,1,2,102);
	MXF_AddArc(p,1,3,96);
	MXF_AddArc(p,1,4,26);
	MXF_AddArc(p,1,5,44);
	MXF_AddArc(p,1,6,480);
	
	MXF_AddArc(p,2,8,30);
	MXF_AddArc(p,2,9,36);
	MXF_AddArc(p,2,10,34);
	MXF_AddArc(p,2,11,21);
	MXF_AddArc(p,2,12,77);
	MXF_AddArc(p,2,13,57);
	MXF_AddArc(p,2,14,14);
	MXF_AddArc(p,2,15,16);
	MXF_AddArc(p,2,16,64);
	MXF_AddArc(p,2,17,24);
	MXF_AddArc(p,2,18,20);
	MXF_AddArc(p,2,19,60);
	MXF_AddArc(p,2,20,60);
	MXF_AddArc(p,2,21,30);
	MXF_AddArc(p,2,22,60);
	MXF_AddArc(p,2,23,77);
	MXF_AddArc(p,2,24,22);
	MXF_AddArc(p,2,25,40);
	
	MXF_AddArc(p,3,8,30);
	MXF_AddArc(p,3,9,36);
	MXF_AddArc(p,3,10,34);
	MXF_AddArc(p,3,11,21);
	MXF_AddArc(p,3,12,77);
	MXF_AddArc(p,3,13,57);
	MXF_AddArc(p,3,14,14);
	MXF_AddArc(p,3,15,16);
	MXF_AddArc(p,3,16,64);
	MXF_AddArc(p,3,17,24);
	MXF_AddArc(p,3,18,20);
	MXF_AddArc(p,3,19,60);
	MXF_AddArc(p,3,20,60);
	MXF_AddArc(p,3,21,30);
	MXF_AddArc(p,3,22,60);
	MXF_AddArc(p,3,23,77);
	MXF_AddArc(p,3,24,22);
	MXF_AddArc(p,3,25,40);
	
	MXF_AddArc(p,4,8,30);
	MXF_AddArc(p,4,9,36);
	MXF_AddArc(p,4,10,34);
	MXF_AddArc(p,4,11,21);
	MXF_AddArc(p,4,12,77);
	MXF_AddArc(p,4,13,57);
	MXF_AddArc(p,4,14,14);
	MXF_AddArc(p,4,15,16);
	MXF_AddArc(p,4,16,64);
	MXF_AddArc(p,4,17,24);
	MXF_AddArc(p,4,18,20);
	MXF_AddArc(p,4,19,60);
	MXF_AddArc(p,4,20,60);
	MXF_AddArc(p,4,21,30);
	MXF_AddArc(p,4,22,60);
	MXF_AddArc(p,4,23,77);
	MXF_AddArc(p,4,24,22);
	MXF_AddArc(p,4,25,40);
	
	MXF_AddArc(p,5,8,30);
	MXF_AddArc(p,5,9,36);
	MXF_AddArc(p,5,10,34);
	MXF_AddArc(p,5,11,21);
	MXF_AddArc(p,5,12,77);
	MXF_AddArc(p,5,13,57);
	MXF_AddArc(p,5,14,14);
	MXF_AddArc(p,5,15,16);
	MXF_AddArc(p,5,16,64);
	MXF_AddArc(p,5,17,24);
	MXF_AddArc(p,5,18,20);
	MXF_AddArc(p,5,19,60);
	MXF_AddArc(p,5,20,60);
	MXF_AddArc(p,5,21,30);
	MXF_AddArc(p,5,22,60);
	MXF_AddArc(p,5,23,77);
	MXF_AddArc(p,5,24,22);
	MXF_AddArc(p,5,25,40);
	
	MXF_AddArc(p,6,8,30);
	MXF_AddArc(p,6,9,36);
	MXF_AddArc(p,6,10,34);
	MXF_AddArc(p,6,11,21);
	MXF_AddArc(p,6,12,77);
	MXF_AddArc(p,6,13,57);
	MXF_AddArc(p,6,14,14);
	MXF_AddArc(p,6,15,16);
	MXF_AddArc(p,6,16,64);
	MXF_AddArc(p,6,17,24);
	MXF_AddArc(p,6,18,20);
	MXF_AddArc(p,6,19,60);
	MXF_AddArc(p,6,20,60);
	MXF_AddArc(p,6,21,30);
	MXF_AddArc(p,6,22,60);
	MXF_AddArc(p,6,23,77);
	MXF_AddArc(p,6,24,22);
	MXF_AddArc(p,6,25,40);
	
	MXF_AddArc(p,8,7,30);
	MXF_AddArc(p,9,7,36);
	MXF_AddArc(p,10,7,34);
	MXF_AddArc(p,11,7,21);
	MXF_AddArc(p,12,7,77);
	MXF_AddArc(p,13,7,57);
	MXF_AddArc(p,14,7,14);
	MXF_AddArc(p,15,7,16);
	MXF_AddArc(p,16,7,64);
	MXF_AddArc(p,17,7,24);
	MXF_AddArc(p,18,7,20);
	MXF_AddArc(p,19,7,60);
	MXF_AddArc(p,20,7,60);
	MXF_AddArc(p,21,7,30);
	MXF_AddArc(p,22,7,60);
	MXF_AddArc(p,23,7,77);
	MXF_AddArc(p,24,7,22);
	MXF_AddArc(p,25,7,40);
	
	int * NodeList = new int[node_count+1];
  	int CutValue;
	int NodeListSize;
	

	MXF_SolveMaxFlow(p,0,1,7,&CutValue,0,&NodeListSize, NodeList);
	printf("CutValue:%d should be:744\n",CutValue);
	
	MXF_WriteNodeList(p);
  	MXF_WriteArcList(p);
	
	MXF_FreeMem(p);
	delete [] NodeList;
	
	
	return 1;
}
