
#include "cover.h"
#include <stdio.h> 
#include <stdlib.h> 
#include "util.h"


int cover_item_cmp_sort(const void *a, const void *b)
{
	cover_item_ptr a1 = (cover_item_ptr)a;
	cover_item_ptr b1 = (cover_item_ptr)b;
	if(a1->sort<b1->sort)
		return 1;
	else if (a1->sort>b1->sort)
		return -1;
	else
		return 0;
	//return  a1->sort<b1->sort?1:0;
}

int cover_item_cmp_id(const void *a, const void *b)
{
	cover_item_ptr a1 = (cover_item_ptr)a;
	cover_item_ptr b1 = (cover_item_ptr)b;
	return  a1->id<b1->id?0:1;
}

cover_ptr cover_init(int w, int nb)
{
	cover_ptr c = (cover_ptr)malloc(sizeof(cover_t));
	c->items = (cover_item_t*)malloc(sizeof(cover_item_t) * nb);
	c->nb = nb;
	c->w = w;
	c->max_nb_items = 0;
	return c;
}

void cover_free(cover_ptr c)
{
	free(c->items);
	free(c);	
}


//check if an extend cover is violated, return 1 if yes, 0 otherwise
int cover_check_violate_extended_cover(cover_ptr c)
{
	int i, a = 0,sumw = 0;
	for(i=0;i<c->nb;i++)
		if(c->items[i].x == 1)
		{
			a = a<c->items[i].w?c->items[i].w:a;
			sumw += c->items[i].w;
		}
	if(sumw <= c->w) return 0;
	
	double sumv = 0;
	int cnt = 0;
	for(i=0;i<c->nb;i++)
		if(c->items[i].x == 1 || c->items[i].w >= a)
		{
			sumv += c->items[i].v;
			sumw += c->items[i].x == 1?c->items[i].w:0;
			cnt += c->items[i].x;
		}
	if(sumw > c->w && sumv > cnt-1)
		return 1;
	else
		return 0;
}

int cover_check_violate_extended_cover_and_set(cover_ptr c)
{
	int i, a = 0;
	for(i=0;i<c->nb;i++)
		if(c->items[i].x == 1)
			a = a<c->items[i].w?c->items[i].w:a;
	
	c->max_nb_items = 0;
	double sumv = 0;
	int sumw = 0,cnt = 0;
	for(i=0;i<c->nb;i++)
		if(c->items[i].x == 1 || c->items[i].w >= a)
		{
			sumv += c->items[i].v;
			sumw += c->items[i].x == 1?c->items[i].w:0;
			cnt += c->items[i].x;
		}
	if(sumw > c->w && sumv - 0.1 > cnt-1)
	{
		c->max_nb_items = cnt-1;
		for(i=0;i<c->nb;i++)
			if(c->items[i].x == 1 || c->items[i].w >= a)
				c->items[i].x = 1;
		return 1;
	}
	else
		return 0;
}

void cover_heur_solve(cover_ptr c)
{
	#ifdef COVER_OUTPUT
	printf("cover_heur_solve nb:%d w:%d\n", c->nb, c->w);
	#endif
	int i,j;
	c->max_nb_items = 0;
	for(i=0;i<c->nb;i++)
	{
		c->items[i].x = 0;
		c->items[i].sort = (1-c->items[i].v)/((double)c->items[i].w);
	}
	qsort(c->items, c->nb, sizeof(cover_item_t), cover_item_cmp_sort);
	
	#ifdef COVER_OUTPUT
	for(i=0;i<c->nb;i++)
		printf("id:%d w:%d v:%lf sort:%.20lf\n",c->items[i].id, c->items[i].w,c->items[i].v,c->items[i].sort);
	#endif
	
	int a = c->w;
	double sumv = 0;
	int sumw = 0;
	int cnt = 0;
	for(i=0;i<c->nb;)
	{
		for(;i<c->nb;i++)
		{
			if(c->items[i].w < a)
			{
				c->items[i].x = 1;
				sumv += c->items[i].v;
				sumw += c->items[i].w;
				cnt++;
				if(cover_check_violate_extended_cover(c) == 1) //we got a cover !!!
				{
					i++;
					//printf("Found cover c:%d sumv:%.2lf sumw:%d\n", cnt, sumv,sumw);
					break;	
				}
			}
		}
		
		
		int maxb = 0;
		int maxa = 0;
		int maxa_index = -1;
		for(j=0;j<i;j++)
			if(c->items[j].x == 1 && maxa < c->items[j].w)
			{
				maxb = a;
				maxa = c->items[j].w;
				maxa_index = j;
			}
		
		int cnt1 = 0;
		int sumw1 = 0;
		double sumv1 = 0;
		for(j=0;j<c->nb;j++)
			if(c->items[j].x == 1 || maxa <= c->items[j].w)
			{
				cnt1 += c->items[j].x;
				sumw1 += c->items[j].w;
				sumv1 += c->items[j].v;
			}
			
		if(sumw1 > c->w && sumv1 > cnt1-1)
		{
			#ifdef COVER_OUTPUT
			printf("Found cover i:%d c:%d sumv:%.2lf sumv1:%.2lf sumw:%d sumw1:%d\n", i,cnt1, sumv,sumv1,sumw,sumw1);
			for(j=0;j<c->nb;j++)
				printf("id:%d w:%d v:%.3lf x:%d\n",c->items[j].id, c->items[j].w,c->items[j].v,c->items[j].x);
			#endif
			break;
		}
		 
		c->items[maxa_index].x = 0;
		sumw -= maxa;
		sumv -= c->items[maxa_index].v;
		cnt--;
		a = maxb;
	}
	c->has_a_cover = cover_check_violate_extended_cover_and_set(c);
	qsort(c->items, c->nb, sizeof(cover_item_t), cover_item_cmp_id);
}













