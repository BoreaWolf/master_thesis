
#include "mathfunc.h"
#include <math.h>
#include <stdlib.h>

double MAX_DBL(double x, double y)
{
	if(x < y)
		return y;
	else
		return x;
}
int MAX_INT(int x, int y) {return (x>y)?x:y;}
int MIN_INT(int x, int y) {return (x<y)?x:y;}
int CEIL_DIV(int x, int y){return (int)ceil( ((double)x)/((double)y));}
//inline int MAX_INT(int x, int y)
//{
	//if(x < y)
	//	return y;
	//else
	//	return x;
//	return x ^ ((x ^ y) & -(x < y));
//}

//inline int MIN_INT(int x, int y)
//{
	//if(x > y)
	//	return y;
	//else
	//	return x;
//	return y ^ ((x ^ y) & -(x < y));
//}

double MIN_DBL(double x, double y)
{
	if(x > y)
		return y;
	else
		return x;
}



int ABS_INT(int x)
{
	//int mask = x >> 31;
	//return ((-x) & mask) | (x & ~mask);

	if(x > 0)
		return x;
	else
		return -x;

}
double ABS_DBL(double x)
{
	if(x > 0)
		return x;
	else
		return -x;
}

//return a random number between min(inclusivly) and max(exclusivly)
int mat_func_get_rand_int(int min, int max)
{
	if(min == max) return min;
	return (rand() % (max - min)) + min;
}

int mat_func_get_rand_int_diff(int min, int max, int no)
{
	int n = mat_func_get_rand_int(min, max);
	while(n == no)
		n = mat_func_get_rand_int(min, max);

	return n;
}

double mat_func_get_rand_double()
{
	return rand() / (double)RAND_MAX;
}

double mat_abs_diff(double x1, double x2, double y1, double y2)
{
	return ABS_DBL(x1-x2) + ABS_DBL(y1-y2);
}

double mat_func_get_max_smaller_than(double ** mat, int dim, double max_value)
{
	double maxv = -INFINITE;
	int i,j;
	for(i = 0 ; i < dim ; i++)
		for(j = 0 ; j < dim ; j++)
			if(mat[i][j] > maxv && mat[i][j] < max_value)
				maxv = mat[i][j];
	return maxv;
}

double 	mat_func_get_rand_double_between(double min, double max)
{
	return (max-min) * mat_func_get_rand_double() + min;
}

double * math_func_get_double_array(int n)
{
	return (double*)malloc(sizeof(double)*n);
}
double ** math_func_get_double_matrix(int n,int m)
{
	double ** p = (double**)malloc(sizeof(double*)*n);
	int i;
	for(i=0;i<n;i++)
		p[i] = (double*)malloc(sizeof(double)*m);
	return p;
}
void math_func_free_double_array(double * a);
void math_func_free_double_matrix(double ** a,int n);
