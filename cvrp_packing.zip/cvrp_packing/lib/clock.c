/*
   This file contains functions that can be used to get some timing
   information about your program.

   Available functions : ClkInit, ClkReset, ClkStart, ClkStop, secClkGetTime
 */

#include "clock.h"
static clock_t clockTicks=0;

/*
   This function initializes the structure so it can be used later.
   It must be called before using any of the other functions,
   otherwise they will not produce valid results.

 */
void ClkInit(ClkCLK *pclk)
{
  if(!clockTicks) {clockTicks = sysconf(_SC_CLK_TCK);}
  pclk->clockTotal = 0;
  pclk->fStart = 0;
}

/*
    Resets cumulated time to 0 and indicate that the timer is stopped.
 */    
void ClkReset(ClkCLK *pclk)
{
  pclk->clockTotal = 0;
  pclk->fStart = 0;
}

/*
   This function indicates that the clock should be started now.  

 */   
void ClkStart(ClkCLK *pclk)
{
  struct tms tmsStart[1];
  times(tmsStart);
  pclk->clockStart = tmsStart->tms_utime + tmsStart->tms_stime;
  pclk->fStart = 1;
}

/*
    This stops the clock.  This means that the time elapsed between
    the stop and the next start will not be accumulated.
 */
void ClkStop(ClkCLK *pclk)
{
  struct tms tmsCur[1];
  times(tmsCur);
  pclk->clockTotal += tmsCur->tms_utime + tmsCur->tms_stime - pclk->clockStart;
  pclk->fStart = 0;
}

/*
    This function returns the current elapsed time.  This function can
    be used after the clock is started and after is it stopped.

 */
ClkSEC secClkGetTime(ClkCLK *pclk)
{
  if(pclk->fStart)
    {
      struct tms tmsCur[1];
      times(tmsCur);
      pclk->clockTotal += tmsCur->tms_utime + tmsCur->tms_stime
	- pclk->clockStart; 
      pclk->clockStart = tmsCur->tms_utime + tmsCur->tms_stime; 
    }
  return (ClkSEC) pclk->clockTotal / clockTicks ;
}

/* Simple code to test the functions */
#ifdef TEST
#include <stdio.h>

int main(void);
int main(void)
{
  ClkCLK pclk[2];
  int i, j;

  ClkInit(&pclk[0]);
  ClkInit(&pclk[1]);
  ClkStart(&pclk[1]);

  for(j=0;j<2;j++)
    {
      ClkReset(&pclk[0]);
      ClkStart(&pclk[0]);
      for(i=0;i<10000;i++)
	{
	  printf("%d %f\n", i, secClkGetTime(&pclk[0]));
	}
      ClkStop(&pclk[0]);
    }
  ClkStop(&pclk[1]);
  printf("%f\n", secClkGetTime(&pclk[0]));
  printf("%f\n", secClkGetTime(&pclk[1]));
  return 0;
}

#endif
