/*
 * Copyright Jean-Francois Cote 2012
 *
 * The code may be used for academic, non-commercial purposes only.
 *
 * Please contact me at cotejean@iro.umontreal.ca for questions
 *
 * If you have improvements, please contact me!
*/

#ifndef COVER_H
#define COVER_H

#ifndef COVER_OUTPUT
//#define COVER_OUTPUT
#endif

#ifdef __cplusplus
	extern "C" {
#endif

typedef struct
{
	int id; 	//id of the item from 0 to n-1
	int w;		//weight
	double v;	//value
	int x;		//1 if in the set, 0 otherwise
	double sort;
} cover_item_t;
typedef cover_item_t * cover_item_ptr;

typedef struct
{
	cover_item_t * items;
	int w;
	int nb;
	int max_nb_items; //max nb items from the cover that can fit in the knapsack
	int has_a_cover;	//1 if there is a cover, 0 otherwise
} cover_t;

typedef cover_t * cover_ptr;

cover_ptr cover_init(int w, int nb);

void cover_free(cover_ptr p);
void cover_heur_solve(cover_ptr p);



#ifdef __cplusplus
	}
#endif

#endif