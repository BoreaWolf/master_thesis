/*
 * Copyright Jean-Francois Cote 2013
 * 
 * The code may be used for academic, non-commercial purposes only.
 * 
 * Please contact me at cotejean@iro.umontreal.ca for questions
 *
 * If you have improvements, please contact me!
 *
 * 
 * 
*/

#ifndef DFF_H
#define DFF_H

#ifdef __cplusplus
	extern "C" {
#endif


//dual feasible function by Fekete and Schepers 1997,1998, 2000
// f_fs : [0,W] -> [0, W * alpha]
int dff_fs(int w, int W, int alpha);

//dual feasible function by Martello, Monaci and Vigo 2003
int dff_mmv(int w, int W, int alpha);

//dual feasible function by Carlier, Clautieux and Moukrim 2007
int dff_ccm(int w, int W, int alpha);


#ifdef __cplusplus
	}
#endif

#endif 
