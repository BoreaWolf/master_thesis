
#include "skyline.h"
#include "stdlib.h"
#include "stdio.h"

skyline_ptr 	skyline_init(int length)
{
	skyline_ptr s = (skyline_ptr)malloc(sizeof(skyline_t));
	s->head = skyline_init_elem();
	s->head->x = 0;
	s->head->y = 0;
	s->head->length = length;
	return s;
}

skyline_elem_ptr skyline_init_elem()
{
	skyline_elem_ptr p = (skyline_elem_ptr)malloc(sizeof(skyline_elem_t));
	p->next = NULL;
	p->prev = NULL;
	p->length = 0;
	p->x = 0;
	p->y = 0;
	return 	p;
}

void skyline_free(skyline_ptr s)
{
	skyline_elem_ptr c = s->head;
	while(c != NULL)
	{
		skyline_elem_ptr next = c->next;
		free(c);
		c = next;
	}
	free(s);
}

int skyline_count(skyline_ptr s)
{
	int nb=0;
	skyline_elem_ptr c = s->head;
	while(c != NULL)
	{
		nb++;
		c = c->next;
	}
	return nb;
}

skyline_elem_ptr skyline_get_min_y(skyline_ptr s)
{
	skyline_elem_ptr cur_min_y = s->head;
	
	skyline_elem_ptr cur = s->head->next;
	while(cur != NULL)
	{
		if(cur->y < cur_min_y->y)
			cur_min_y = cur;
		cur = cur->next;
	}
	return cur_min_y;
}

void skyline_add(skyline_ptr s, int x, int y, int length)
{
	//printf("skyline_add x:%d y:%d len:%d\n",x,y,length);
	//skyline_show(s);
	
	//first, find the place to insert it
	skyline_elem_ptr cur = s->head;
	while(cur != NULL && cur->x + cur->length <= x)
		cur = cur->next;
	
	if(cur == NULL || length <= 0)
	{
		printf("Should not happen..\n");
		printf("skyline_add x:%d y:%d len:%d cur:%p\n",x,y,length,cur);
		skyline_show(s);
		skyline_elem_ptr ptrrr = NULL;
		ptrrr->x = 1;
		exit(1);
	}
	
	if(cur->x == x)
	{
		//printf("in here 1\n");
		skyline_add_over(s,cur,y,length);
	}
	else if(cur->x + cur->length == x + length)
	{
		//printf("in here 2\n");
		skyline_elem_ptr new_elem = skyline_init_elem();
		new_elem->x = x;
		new_elem->y = y;
		new_elem->length = length;
		cur->length = x - cur->x;
		
		new_elem->prev = cur;
		new_elem->next = cur->next;
		if(cur->next != NULL) cur->next->prev = new_elem;
		cur->next = new_elem;
		
		//we have to go forward in the list of segments to remove
		//segments that are now blocked by the new one
		skyline_elem_ptr sg = new_elem->next;
		while(sg != NULL && sg->x < x + length)
		{
			//if the segment is partially covered
			//update the x and the length of the segment
			if(sg->x + sg->length > x + length)
			{
				sg->length -= (cur->x + length) - sg->x;
				sg->x = cur->x + length;
				break;	
			}
			
			//otherwise, the segment is totally overlapped by cur
			//delete it
			skyline_elem_ptr next = sg->next;
			skyline_remove(s,sg);
			sg = next;
		}	
		skyline_partial_remove_same_y_elements(s,cur);
	}
	//the segment is added in the middle of a segment
	/*else
	{
		skyline_elem_ptr ne1 = skyline_init_elem();
		ne1->x = x;
		ne1->y = y;
		ne1->length = length;
		
		skyline_elem_ptr ne2 = skyline_init_elem();
		ne2->x = x+length;
		ne2->y = cur->y;
		ne2->length = (cur->x + cur->length) - (x+length);
		ne1->next = ne2;
		ne1->prev = cur;
		ne2->prev = ne1;
		ne2->next = cur->next;
		
		cur->length = x - cur->x;
		
		if(cur->next != NULL) cur->next->prev = ne2;
		cur->next = ne1;
	}*/
	//the segment is added in the middle of a segment
	else if(cur->x < x && cur->x + cur->length > x + length)
	{
		//printf("in here 4\n");
		skyline_elem_ptr ne1 = skyline_init_elem();
		ne1->x = x;
		ne1->y = y;
		ne1->length = length;
		
		skyline_elem_ptr ne2 = skyline_init_elem();
		ne2->x = x+length;
		ne2->y = cur->y;
		ne2->length = (cur->x + cur->length) - (x+length);
		
		ne1->next = ne2;
		ne1->prev = cur;
		ne2->prev = ne1;
		ne2->next = cur->next;
		
		cur->length = x - cur->x;
		
		if(cur->next != NULL) cur->next->prev = ne2;
		cur->next = ne1;
	} 
	else if(cur->x < x && cur->x + cur->length < x + length)
	{
		//printf("in here 5 : curx:%d cury:%d curlen:%d\n",cur->x,cur->y,cur->length);
		//printf("skyline_seq_add x:%d y:%d len:%d seq:%d\n",x,y,length,seq);
		//skyline_seq_show(s);
		
		skyline_elem_ptr ne = skyline_init_elem();
		ne->x = x;
		ne->y = y;
		ne->length = cur->x + cur->length - x;
		cur->length = x-cur->x;
		
		
		ne->next = cur->next;
		ne->prev = cur;
		cur->next = ne;
		ne->next->prev = ne->next->prev = ne;
		
		//printf("skyline_seq_add_over x:%d y:%d len:%d seq:%d\n",cur->next->x,y,length - ne->length,seq);
		skyline_add_over(s,ne->next,y,length - ne->length);
		
		//printf("result\n");
		//skyline_seq_show(s);
	}
	//printf("after\n");
	//skyline_show(s);
}

void skyline_add_over(skyline_ptr s,skyline_elem_ptr cur, int y, int length)
{	
	//printf("skyline_add_over curx:%d cury:%d curlen:%d y:%d len:%d\n", cur->x,cur->y,cur->length,y,length);
	if(length == cur->length)
		cur->y = y;
	else if(length < cur->length) 
	{
		if(cur->y == y) return;
		//otherwise, //if the segment is longer than the item
		//update the height of the segment and its length and add another segment at the end of this one
		//first add a segment
		skyline_elem_ptr sg = skyline_init_elem();
		sg->x = cur->x + length;
		sg->y = cur->y;
		sg->length = cur->length - length;
		sg->next = cur->next;
		sg->prev = cur;
		
		cur->length = length;
		cur->y = y;
		
		//put pointers
		skyline_elem_ptr next = cur->next;
		if(next != NULL) next->prev = sg;
		cur->next = sg;
	}
	else if(length > cur->length)
	{
		//the item is longer than the segment				
		cur->length = length;
		cur->y = y;
		
		//we have to go forward in the list of segments to remove
		//segments that are now blocked by the item
		skyline_elem_ptr sg = cur->next;
		while(sg != NULL && sg->x < cur->x + length)
		{
			//if the segment is partially covered
			//update the x and the length of the segment
			if(sg->x + sg->length > cur->x + length)
			{
				sg->length -= (cur->x + length) - sg->x;
				sg->x = cur->x + length;
				break;	
			}
			
			//otherwise, the segment is totally overlapped by cur
			//delete it
			skyline_elem_ptr next = sg->next;
			skyline_remove(s,sg);
			sg = next;
		}
	}
	skyline_remove_same_y_elements(s);
	//skyline_partial_remove_same_y_elements(s,cur);
}

int skyline_close_element(skyline_ptr s,skyline_elem_ptr elem)
{
	skyline_elem_ptr prev = elem->prev;
	skyline_elem_ptr next = elem->next;
	
	int nexty = prev != NULL? prev->y:9999999;
	nexty = next != NULL && nexty > next->y?next->y:nexty; 
	
	elem->y = nexty;
	skyline_partial_remove_same_y_elements(s,elem);
	return nexty;
	/*
	int newy = elem->y;
	skyline_elem_ptr next = elem->next;
	skyline_elem_ptr prev = elem->prev;
	
	if(next != NULL && prev != NULL)
	{
		if(prev->y < next->y)
		{
			prev->length += elem->length;
			newy = prev->y;
		}
		else if(next->y < prev->y)
		{
			next->x = elem->x;
			next->length += elem->length;
			newy = next->y;
		}
		else//prev and next are at the same y
		{
			newy = prev->y;
			prev->length += elem->length + next->length;
			skyline_remove(s,next);
		}
	}
	else if(prev != NULL)
	{
		newy = prev->y;
		prev->length += elem->length;
	}
	else if(next != NULL)
	{
		newy = next->y;
		next->x = elem->x;
		next->length += elem->length;	
	}	
	
	if(prev != NULL || next != NULL)
	{
		skyline_remove(s,elem);	
		skyline_remove_same_y_elements(s);
	}
	return newy;*/
}

void skyline_partial_remove_same_y_elements(skyline_ptr s,skyline_elem_ptr line)
{
	skyline_elem_ptr next = line->next;
	skyline_elem_ptr prev = line->prev;	
	
	if(next != NULL && next->y == line->y)
	{
		line->length += next->length;
		skyline_remove(s,next);
	}
	
	if(prev != NULL && prev->y == line->y)
	{
		prev->length += line->length;
		skyline_remove(s,line);
	}
}

void skyline_remove_same_y_elements(skyline_ptr s)
{
	skyline_elem_ptr sg = s->head;
	while(sg != NULL)
	{
		skyline_elem_ptr next = sg->next;
		if(next != NULL && sg->y == next->y)
		{
			next->length += sg->length;
			next->x = sg->x;
			//printf("Removing same y element\n");
			//skyline_show(s);
			skyline_remove(s,sg);
			if(s->head == sg)
			{
				s->head = next;
				if(s->head == NULL)
				{
					int a = 3;
				}
			}
		}
		sg = next;
	}
}

void skyline_remove(skyline_ptr s,skyline_elem_ptr elem)
{
	skyline_elem_ptr next = elem->next;
	skyline_elem_ptr prev = elem->prev;
	if(prev != NULL) prev->next = next;
	if(next != NULL) next->prev = prev;
	free(elem);
	
	if(s->head == elem) 
		s->head = next;
}

void skyline_show(skyline_ptr s)
{
	int k = 0;
	skyline_elem_ptr cur = s->head;
	while(cur != NULL && k++ < 90000)
	{
		printf("Segment x:%d y:%d length:%d\n", cur->x,cur->y,cur->length);
		cur = cur->next;
	}
	if(k == 90000)
	{
		printf("Infinite loop detected in skyline_show_segments\n");
		exit(1);	
	}
}


