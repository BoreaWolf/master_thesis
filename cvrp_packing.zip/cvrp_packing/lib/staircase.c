
#include "staircase.h"
#include "stdlib.h"
#include "stdio.h"

staircase_ptr 	staircase_init(int length,int height)
{
	staircase_ptr s = (staircase_ptr)malloc(sizeof(staircase_t));
	s->head = staircase_init_elem();
	s->head->x = 0;
	s->head->y = 0;
	s->head->length = length;
	s->height = height;
	return s;
}

staircase_elem_ptr staircase_init_elem()
{
	staircase_elem_ptr p = (staircase_elem_ptr)malloc(sizeof(staircase_elem_t));
	p->next = NULL;
	p->prev = NULL;
	p->length = 0;
	p->x = 0;
	p->y = 0;
	return 	p;
}

void staircase_free(staircase_ptr s)
{
	staircase_elem_ptr c = s->head;
	while(c != NULL)
	{
		staircase_elem_ptr next = c->next;
		free(c);
		c = next;
	}
	free(s);
}

staircase_elem_ptr staircase_get_min_x_not_closed(staircase_ptr s)
{	
	staircase_elem_ptr cur = s->head;
	while(cur != NULL)
	{
		if(cur->y < s->height)
			return cur;
		cur = cur->next;
	}
	return NULL;//it is full
}

staircase_elem_ptr staircase_get_min_y(staircase_ptr s)
{
	staircase_elem_ptr cur_min_y = s->head;
	staircase_elem_ptr cur = s->head->next;
	while(cur != NULL)
	{
		if(cur->y < cur_min_y->y)
			cur_min_y = cur;
		cur = cur->next;
	}
	return cur_min_y;
}

staircase_elem_ptr staircase_get_last(staircase_ptr s)
{
	staircase_elem_ptr cur = s->head;
	while(cur != NULL)
	{
		if(cur->next == NULL)
			return cur;
		cur = cur->next;
	}
	return NULL;
}

void staircase_add(staircase_ptr s, int x, int h, int len)
{
	//printf("staircase add x:%d h:%d len:%d\n", x,h,len);
	//staircase_show(s);
	
	staircase_elem_ptr cur = s->head;
	while(cur != NULL)
	{
		if(cur->x + cur->length < x) 
		{
			cur = cur->next;
			continue;	
		}
		//the segment is fully covered by (x, x+len)
		if(x <= cur->x && cur->x + cur->length <= x+len)
		{
			cur->y += h;	
			if(cur->x + cur->length == x+len) break;
		}
		else if(cur->x < x+len && x < cur->x + cur->length)
		{
			//the segment is partially cover, we have to split it in 2
			staircase_elem_ptr new_elem = staircase_init_elem();

			new_elem->prev = cur;
			new_elem->next = cur->next;			
			if(cur->next != NULL) cur->next->prev = new_elem;
			cur->next = new_elem;
			
			if(cur->x == x && len < cur->length)
			{
				new_elem->y = cur->y;
				new_elem->x = x+len;
				new_elem->length = cur->length - len;
				cur->length = x+len - cur->x;
				cur->y += h;
			}
			else if(cur->x < x && cur->x + cur->length < x+len)
			{
				new_elem->y = cur->y + h;
				new_elem->x = x;
				new_elem->length = cur->x + cur->length - x;
				cur->length = x - cur->x;
			}
			else if(cur->x < x)
			{
				new_elem->y = cur->y + h;
				new_elem->x = x;
				new_elem->length = len;
				cur->length = x - cur->x;
			}
			else //cur->x > x
			{
				new_elem->x = x+len;
				new_elem->y = cur->y;
				new_elem->length = cur->x + cur->length - x - len;
				cur->y += h;	
				cur->length = x+len-cur->x;
			}
			cur = new_elem->next;
			continue;
		}
		else if (cur->x > x+len)
			break;
		cur = cur->next;
	}
	staircase_remove_same_y_elements(s);
}

void staircase_add_skyline(staircase_ptr s,int x, int y, int length)
{
	//first, find the place to insert it
	staircase_elem_ptr cur = s->head;
	while(cur != NULL && cur->x + cur->length <= x)
		cur = cur->next;
	
	if(cur == NULL)
	{
		printf("Should not happen..\tstaircase_add\n");
		exit(1);
	}
	
	if(cur->x == x)
	{
		staircase_add_skyline_over(s,cur,y,length);
	}
	else if(cur->x + cur->length == x + length)
	{
		staircase_elem_ptr new_elem = staircase_init_elem();
		new_elem->x = x;
		new_elem->y = y;
		new_elem->length = length;
		cur->length = x - cur->x;
		
		new_elem->prev = cur;
		new_elem->next = cur->next;
		if(cur->next != NULL) cur->next->prev = new_elem;
		cur->next = new_elem;
		
		//we have to go forward in the list of segments to remove
		//segments that are now blocked by the new one
		staircase_elem_ptr sg = new_elem->next;
		while(sg != NULL && sg->x < x + length)
		{
			//if the segment is partially covered
			//update the x and the length of the segment
			if(sg->x + sg->length > x + length)
			{
				sg->length -= (cur->x + length) - sg->x;
				sg->x = cur->x + length;
				break;	
			}
			
			//otherwise, the segment is totally overlapped by cur
			//delete it
			staircase_elem_ptr next = sg->next;
			staircase_remove(s,sg);
			sg = next;
		}	
	}
	//the segment is added in the middle of a segment
	else
	{
		staircase_elem_ptr ne1 = staircase_init_elem();
		ne1->x = x;
		ne1->y = y;
		ne1->length = length;
		
		staircase_elem_ptr ne2 = staircase_init_elem();
		ne2->x = x+length;
		ne2->y = cur->y;
		ne2->length = (cur->x + cur->length) - (x+length);
		ne1->next = ne2;
		ne1->prev = cur;
		ne2->prev = ne1;
		ne2->next = cur->next;
		
		cur->length = x - cur->x;
		
		if(cur->next != NULL) cur->next->prev = ne2;
		cur->next = ne1;
	}
	staircase_remove_same_y_elements(s);
}

void staircase_add_skyline_over(staircase_ptr s,staircase_elem_ptr cur, int y, int length)
{	
	if(length == cur->length)
		cur->y = y;
	else if(length < cur->length) 
	{
		//otherwise, //if the segment is longer than the item
		//update the height of the segment and its length and add another segment at the end of this one
		//first add a segment
		staircase_elem_ptr sg = staircase_init_elem();
		sg->x = cur->x + length;
		sg->y = cur->y;
		sg->length = cur->length - length;
		sg->next = cur->next;
		sg->prev = cur;
		
		cur->length = length;
		cur->y = y;
		
		//put pointers
		staircase_elem_ptr next = cur->next;
		if(next != NULL) next->prev = sg;
		cur->next = sg;
	}
	else if(length > cur->length)
	{
		//the item is longer than the segment				
		cur->length = length;
		cur->y = y;
		
		//we have to go forward in the list of segments to remove
		//segments that are now blocked by the item
		staircase_elem_ptr sg = cur->next;
		while(sg != NULL && sg->x < cur->x + length)
		{
			//if the segment is partially covered
			//update the x and the length of the segment
			if(sg->x + sg->length > cur->x + length)
			{
				sg->length -= (cur->x + length) - sg->x;
				sg->x = cur->x + length;
				break;	
			}
			
			//otherwise, the segment is totally overlapped by cur
			//delete it
			staircase_elem_ptr next = sg->next;
			staircase_remove(s,sg);
			sg = next;
		}	
	}
	staircase_remove_same_y_elements(s);
}


void staircase_remove_same_y_elements(staircase_ptr s)
{
	staircase_elem_ptr sg = s->head;
	while(sg != NULL)
	{
		staircase_elem_ptr next = sg->next;
		if(next != NULL && sg->y == next->y)
		{
			next->length += sg->length;
			next->x = sg->x;
			//printf("Removing same y element\n");
			//staircase_show(s);
			staircase_remove(s,sg);
			if(s->head == sg)
				s->head = next;
		}
		sg = next;
	}
}

void staircase_remove(staircase_ptr s,staircase_elem_ptr elem)
{
	staircase_elem_ptr next = elem->next;
	staircase_elem_ptr prev = elem->prev;
	if(prev != NULL) prev->next = next;
	if(next != NULL) next->prev = prev;
	free(elem);
	
	if(s->head == elem) 
		s->head = next;
}

void staircase_show(staircase_ptr s)
{
	int k = 0;
	staircase_elem_ptr cur = s->head;
	while(cur != NULL && k++ < 90000)
	{
		printf("(x:%d y:%d l:%d) ", cur->x,cur->y,cur->length);
		//if(cur->y < 0 || cur->y > s->height || cur->length == 0)
		{
		//	printf("BUGGGGGGGGGGGG\n");
		//	exit(1);
		}
		//if(cur->prev != NULL && 
		//  (cur->prev->y < cur->y || cur->prev->x == cur->x || cur->prev->x + cur->prev->length >= cur->x + cur->length))
		{
		//	printf("BUGGGGGGGGGGGG\n");
		//	exit(1);
		}
		
		cur = cur->next;
	}
	printf("\n");
	if(k == 90000)
	{
		printf("Infinite loop detected in staircase_show_segments\n");
		exit(1);	
	}
}

