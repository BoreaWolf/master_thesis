

#include "kp_mt1_dbl.h"
#include <stdio.h> 
#include <stdlib.h> 

//definition of the items
typedef struct
{
	int id;			//id
	int w;			//weight
	double p;		//profit
	int x;			//0-1 value if the item is in the knapsack or not
} kp_mt1_dbl_item_t;

typedef struct
{
	unsigned long long nbnodes; 	//number of visited nodes	
	int n;							//number of items
	int W;							//Capacity
	kp_mt1_dbl_item_t * items;		//list of items
	double ub;						//value of the best solution so far		
	double lb;						//best lower bound so far
	int cur_item;					//Current item that is consider
	int cur_sum_w;					//Current sum of weight
	double cur_sum_p;				//Current sum of profits
	int * sol; 						//current best solution
} kp_mt1_dbl_t;


//Function for sorting, sort by decreasing ratio p/w
int kp_mt1_dbl_item_cmp(const void *a, const void *b)
{
	kp_mt1_dbl_item_t * a1 = (kp_mt1_dbl_item_t *)a;
	kp_mt1_dbl_item_t * b1 = (kp_mt1_dbl_item_t *)b;
	double a2 = a1->p / (double)a1->w;
	double b2 = b1->p / (double)b1->w;
	return  a2<b2?1:-1;
}

//return best found upper bound
int kp_mt1_dbl_bb(kp_mt1_dbl_t * sa)
{
	sa->nbnodes++;
	int i;
	int item = sa->cur_item;

#ifdef KNAPSACK_MT1_DBL_OUTPUT
	//printf("node:%llu item:%d lb:%lf sump:%lf items:", sa->nbnodes,sa->cur_item, sa->lb,sa->cur_sum_p);
	//for(i=0;i<sa->cur_item;i++)
	//	printf("%d ", sa->items[i].x);
	//printf("\n");
#endif

	if(sa->cur_sum_p > sa->lb)
	{
		sa->lb = sa->cur_sum_p;
		for(i=0;i<item;i++)
			sa->sol[sa->items[i].id] = sa->items[i].x;
		for(i=item;i<sa->n;i++)
			sa->sol[sa->items[i].id] = 0;
			
#ifdef KNAPSACK_MT1_DBL_OUTPUT			
		printf("Found new solution sumw:%d sump:%lf nbnodes:%llu\n", sa->cur_sum_w,sa->cur_sum_p,sa->nbnodes);
		for(i=0;i<item;i++)
			if(sa->items[i].x == 1)
				printf("%d ", sa->items[i].id);
		printf("\n");
#endif
		if(sa->ub < sa->cur_sum_p)
			sa->ub = sa->cur_sum_p;
	}
	if(sa->cur_item >= sa->n) return sa->cur_sum_p;
	
	int lb1 = 0;
	int lb2 = 0;
	int sum_w = sa->cur_sum_w;
	double sum_p = sa->cur_sum_p;
	
	//calculate an upper bound from the current item
	for(i=item;i<sa->n;i++)
		if(sum_w + sa->items[i].w <= sa->W)
		{
			sum_p += sa->items[i].p;
			sum_w += sa->items[i].w;
		}
		else
			break;
			
	//take the last fractional part	
	if(i < sa->n)	
		sum_p += (int)(((sa->W - sum_w) / (double)sa->items[i].w) * sa->items[i].p);
	
	//printf("sum_p:%lf lb:%d\n", sum_p, sa->lb);
	if(sum_p - 0.001 <= sa->lb)
	{
		return 0;
	}		
	else
	{
		if(sa->items[item].w + sa->cur_sum_w <= sa->W)
		{
			sa->items[item].x = 1;
			sa->cur_sum_w += sa->items[item].w;
			sa->cur_sum_p += sa->items[item].p;
			sa->cur_item = item+1;
			
			lb1 = kp_mt1_dbl_bb(sa);
			
			sa->cur_sum_w -= sa->items[item].w;
			sa->cur_sum_p -= sa->items[item].p;
		}
			
		sa->items[item].x = 0;
		sa->cur_item = item+1;
		
		lb2 = kp_mt1_dbl_bb(sa);
		sa->cur_item = item;
	}
	return lb1<lb2?lb1:lb2;
}

double kp_mt1_dbl_solve(int W, int n, int * w, double * p, int * x,double ub)
{
	int i;
	kp_mt1_dbl_t sa;
	sa.nbnodes = 0;
	sa.n = n;
	sa.W = W;
	sa.items = (kp_mt1_dbl_item_t*)malloc(sizeof(kp_mt1_dbl_item_t) * n);
	sa.sol =(int*)calloc(n,sizeof(int)); 
	sa.lb = 0;
	
	for(i=0;i<n;i++)
	{
		sa.items[i].id = i;
		sa.items[i].w = w[i];
		sa.items[i].p = p[i];
		sa.items[i].x = 0;
	}
	qsort(sa.items, n, sizeof(kp_mt1_dbl_item_t), kp_mt1_dbl_item_cmp);

#ifdef KNAPSACK_MT1_DBL_OUTPUT	
	for(i=0;i<n;i++)
	{
		printf("item:%d w:%d p:%lf ", sa.items[i].id,sa.items[i].w,sa.items[i].p);
		printf("fr:%lf ", sa.items[i].p/(double)sa.items[i].w);
		printf("\n");
	}
#endif
	
	int sumw = 0;
	for(i=0;i<n;i++)
		if(sumw + sa.items[i].w <= W)
		{			
			sa.sol[ sa.items[i].id ] = 1;
			sa.lb += sa.items[i].p;
			sumw += sa.items[i].w;	
		}
		else
			break;

	if(ub > sa.lb) sa.lb = ub;
	
	sa.ub = sa.lb;
	if(i < n) 
		sa.ub += sa.items[i].p * ((W - sumw) / (double)sa.items[i].w);
	
#ifdef KNAPSACK_MT1_DBL_OUTPUT		
	printf("ub:%lf lb:%lf sumw:%d\n", sa.ub,sa.lb,sumw);
#endif

	if(sa.ub == ((double)sa.lb))// if all objects fit in the knapsack
		goto END;
	
	sa.cur_sum_w = 0;
	sa.cur_sum_p = 0;
	sa.cur_item = 0;
	
	kp_mt1_dbl_bb(&sa);
#ifdef KNAPSACK_MT1_DBL_OUTPUT	
	printf("ub:%lf lb:%lf nbnodes:%llu\n", sa.ub,sa.lb,sa.nbnodes);
#endif
END:
	//if(sa.ub == ((double)sa.lb))
	{
#ifdef KNAPSACK_MT1_DBL_OUTPUT
		printf("in knapsack:");
		for(i=0;i<n;i++)
			if(sa.sol[sa.items[i].id] == 1)
				printf("%d ", sa.items[i].id);
		printf("\n");		
#endif
		for(i=0;i<n;i++)
			x[ sa.items[i].id ] = sa.sol[sa.items[i].id];
	}

	free(sa.items);
	free(sa.sol);
	return sa.lb;
}




