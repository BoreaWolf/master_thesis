

#include "knapsack.h"
#include <stdio.h> 
#include <stdlib.h> 


typedef struct
{
	int id;
	int w;
	int p;
	int x;
} knapsack_item_t;

typedef struct
{
	unsigned long long nbnodes;
	int n;
	int W;
	knapsack_item_t * items;
	double ub;	//
	int lb;		//
	int cur_item;
	int cur_sum_w;
	int cur_sum_p;
	int * sol; //current best solution
} knapsack_t;


//for sorting
int knapsack_knapsack_item_cmp(const void *a, const void *b)
{
	knapsack_item_t * a1 = (knapsack_item_t *)a;
	knapsack_item_t * b1 = (knapsack_item_t *)b;
	double a2 = a1->p / (double)a1->w;
	double b2 = b1->p / (double)b1->w;
	return  a2>b2?0:1;
}

//return best found upper bound
int knapsack_bb(knapsack_t * sa)
{
	sa->nbnodes++;
	if(sa->cur_item >= sa->n) return 0;
	
	int i;
	printf("node:%llu item:%d items:", sa->nbnodes, sa->cur_item);
	for(i=0;i<sa->cur_item;i++)
		printf("%d ", sa->items[i].x);
	printf("\n");
	
	int lb1 = 0;
	int lb2 = 0;
	int item = sa->cur_item;
	int cur_sum_w = sa->cur_sum_w;
	int cur_sum_p = sa->cur_sum_p;
	int sum_w = sa->cur_sum_w;
	double sum_p = sa->cur_sum_p;
	
	//calculate an upper bound from the current item
	for(i=item;i<sa->n;i++)
		if(sum_w + sa->items[i].w <= sa->W)
		{
			sum_p += sa->items[i].p;
			sum_w += sa->items[i].w;
		}
		else
			break;
	
	
	//found new best solution
	if(sum_p > sa->lb)
	{
		printf("found new best solution node:%llu sump:%d\n", sa->nbnodes, (int)sum_p);
		sa->lb = (int)sum_p;
		sa->ub = (int)sum_p;
		for(i=0;i<item;i++)
			sa->sol[i] = sa->items[i].x;
		
		int temp_sum_w = sa->cur_sum_w;
		for(i=item;i<sa->n;i++)
			if(temp_sum_w + sa->items[i].w <= sa->W)
			{
				temp_sum_w += sa->items[i].w;
				sa->sol[i] = 1;
			}
			else
				break;
	}
	
	if(i < sa->n)	
		sum_p += ((sa->W - sum_w) / (double)sa->items[i].w) * sa->items[i].p;
	
	printf("\tsumw:%d sump:%d sumw:%d sump:%.2lf lb:%d\n",sa->cur_sum_w,sa->cur_sum_p,sum_w,sum_p,sa->lb);
	
	
	
	if(sum_p <= sa->lb)
	{
		printf("\treturn\n");
		return 0;
	}		
	if(i == sa->n) //found an integer solution
	{
		printf("\treturn\n");
		return (int)sum_p;
	}
	else
	{
		if(sa->items[item].w + sa->cur_sum_w <= sa->W)
		{
			sa->items[item].x = 1;
			sa->cur_sum_w += sa->items[item].w;
			sa->cur_sum_p += sa->items[item].p;
			sa->cur_item = item+1;
			
			
			lb1 = knapsack_bb(sa);
			sa->cur_sum_w -= sa->items[item].w;
			sa->cur_sum_p -= sa->items[item].p;
		}
			
		sa->items[item].x = 0;
		sa->cur_item = item+1;
		
		lb2 = knapsack_bb(sa);
	}
	return lb1<lb2?lb1:lb2;
}

int knapsack_solve(int W, int n, int * w, int * p, int * x)
{
	int i;
	knapsack_t sa;
	sa.nbnodes = 0;
	sa.n = n;
	sa.W = W;
	sa.items = (knapsack_item_t*)malloc(sizeof(knapsack_item_t) * n);
	sa.sol =(int*)calloc(n,sizeof(int)); 
	
	for(i=0;i<n;i++)
	{
		sa.items[i].id = i;
		sa.items[i].w = w[i];
		sa.items[i].p = p[i];
		sa.items[i].x = 0;
	}
	qsort(sa.items, n, sizeof(knapsack_item_t), knapsack_knapsack_item_cmp);
	
	for(i=0;i<n;i++)
		printf("item:%d w:%d p:%d\n", sa.items[i].id, sa.items[i].w,sa.items[i].p);
		
	sa.lb = 0;
	int sumw = 0;
	for(i=0;i<n;i++)
		if(sumw + sa.items[i].w <= W)
		{
			sa.sol[i] = 1;
			sa.lb += sa.items[i].p;
			sumw += sa.items[i].w;
		}
		else
			break;
	printf("sumw:%d sump:%d\n", sumw, sa.lb);
	
	sa.ub = sa.lb;
	if(i < n) 
		sa.ub += ((W - sumw) / (double)sa.items[i].w) * sa.items[i].p;
	
	sa.lb--;
	printf("ub:%lf lb:%d\n", sa.ub,sa.lb);
	
	if(sa.ub == ((double)sa.lb))// if all objects fit in the knapsack
		goto END;
	
	sa.cur_sum_w = 0;
	sa.cur_sum_p = 0;
	sa.cur_item = 0;
	
	knapsack_bb(&sa);
	
	printf("ub:%lf lb:%d\n", sa.ub,sa.lb);
END:
	if(sa.ub == ((double)sa.lb))
	{
		for(i=0;i<n;i++)
			x[ sa.items[i].id ] = sa.sol[sa.items[i].id];
	}

	free(sa.items);
	free(sa.sol);
	
	return sa.lb;
}




