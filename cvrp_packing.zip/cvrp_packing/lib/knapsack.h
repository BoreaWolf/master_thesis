/*
 * Copyright Jean-Francois Cote 2011
 *
 * The code may be used for academic, non-commercial purposes only.
 *
 * Please contact me at cotejean@iro.umontreal.ca for questions
 *
 * If you have improvements, please contact me!
*/

/*
	Solve the knapsack using the MT1 algorithm of 
	Martello and Toth 


	by Jean-Francois Cote
	December 2011
*/



#ifndef KNAPSACK_H
#define KNAPSACK_H

//comment/uncomment to have the output
//#ifndef KNAPSACK_H_OUTPUT
//#define KNAPSACK_H_OUTPUT
//#endif

#ifdef __cplusplus
	extern "C" {
#endif


// W : capacity of the knapsack
// n : number of items
// w[0..n-1] : weights of items 
// p[0..n-1] : profits of the items
// x[0..n-1] : 0-1 vector if the item is in the knapsack or not
// return the Optimal knapsack value
int knapsack_solve(int W, int n, int * w, int * p, int * x);



#ifdef __cplusplus
	}
#endif


#endif