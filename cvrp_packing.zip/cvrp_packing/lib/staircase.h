/*
 * Copyright Jean-Francois Cote 2012
 *
 * The code may be used for academic, non-commercial purposes only.
 *
 * Please contact me at cotejean@iro.umontreal.ca for questions
 *
 * If you have improvements, please contact me!
*/

#ifndef STAIRCASE_H
#define STAIRCASE_H

#ifdef __cplusplus
	extern "C" {
#endif

typedef struct staircase_elem* staircase_elem_ptr;
typedef struct staircase_elem
{
	int x;
	int y;
	int length;
	staircase_elem_ptr next;
	staircase_elem_ptr prev;
} staircase_elem_t;

typedef struct
{
	staircase_elem_ptr head;
	int height;
} staircase_t;

typedef staircase_t* staircase_ptr;

//create a new data structure staircase
staircase_ptr 	staircase_init(int length,int height);

//create a new element in the structure
staircase_elem_ptr staircase_init_elem();

//delete a staircase and all its elements
void staircase_free(staircase_ptr s);

//add a segment into the structure
void staircase_add(staircase_ptr s,int x, int h, int length);

void staircase_add_skyline(staircase_ptr s,int x, int y, int length);
void staircase_add_skyline_over(staircase_ptr s,staircase_elem_ptr elem, int y, int length);

//delete an element of the skyline
void staircase_remove(staircase_ptr s,staircase_elem_ptr elem);

//get the segment with the minimal x with its y < H
staircase_elem_ptr staircase_get_min_x_not_closed(staircase_ptr s);

//get the segment with the minimal y
staircase_elem_ptr staircase_get_min_y(staircase_ptr s);


staircase_elem_ptr staircase_get_last(staircase_ptr s);

//put the y of the elem to the y minimal y of its neighboors
//its neightboor should have a bigger y otherwise it will crash
//return the y of the choosen neighboor
int staircase_close_element(staircase_ptr s,staircase_elem_ptr elem);

void staircase_show(staircase_ptr s);

void staircase_remove_same_y_elements(staircase_ptr s);

#ifdef __cplusplus
	}
#endif

#endif


