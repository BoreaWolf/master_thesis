
#include "print_2d.h"

#include <stdio.h>
//#include <cstdlib>
//#include <iostream>
#define MAXN 1000

//using namespace std;

// ************************************************************************************************************
int Print_2D_PhaseII(int n, int W, int H, int *w, int *h, int *x, int *y, bool print_labels,
				 bool print_caption, char* caption, char* output_file_name)
	// n = number of items
	// W, H = width, height of the bin
	// *w, *h, *x, *y = widths, heights, x-coordinates and y-coordinates of the items
	// print_labels = true if items labels on output, false otherwise
	// print_caption = true if items number on output, false otherwise
	// caption = caption to be printed
	// output_file_name = name of output file
{
	// *** variables ***
	double textwidth, textheight, top, xunit, yunit; //counters
	double epsx = 0.05; //to put a string
	double epsy = 0.2; //to put a string
	int i;
	FILE *fo; //output file

	// *** open file ***
    if ( (fo = fopen(output_file_name,"w")) == NULL ) {
        printf("\not able to open file %s \n", output_file_name);
        return -1;
    }

    // *** init file info ***
	textwidth = 18.0;
	textheight = 23.0;
	top = 2.0;

    // *** starting doc stuff ***
	fprintf(fo,"\\documentclass[11pt]{article}\n");
	fprintf(fo,"\\usepackage[textwidth=%.1fcm, textheight=%.1fcm, top=%.1fcm]{geometry}\n",
		textwidth, textheight, top);
	fprintf(fo,"\\usepackage{pst-all}\n");
	fprintf(fo,"\\usepackage{amssymb}\n");
	fprintf(fo,"\\begin{document}\n");
	fprintf(fo,"\t\\pagestyle{empty}\n");
	fprintf(fo,"\t\\begin{figure}[htp]\n");

	// *** W and H ***
	xunit = textwidth / W;
	yunit = textheight / H;
	fprintf(fo,"\t\t\\psset{xunit=%.5fcm, yunit=%.5fcm}\n",xunit,yunit);
	fprintf(fo,"\t\t\\begin{pspicture}(0,0)(%d,%d)\n",W,H);

	// *** bin ***
	fprintf(fo,"\t\t\\pspolygon[linewidth=1.5pt, fillstyle=solid, fillcolor=lightgray](0,0)(%d,0)(%d,%d)(0,%d)\n",W,W,H,H);

	// *** items ***
	for (i = 0; i < n; i++) {
		fprintf(fo,"\t\t\\pspolygon[linewidth=0.5pt, fillstyle=solid, fillcolor=white](%d,%d)(%d,%d)(%d,%d)(%d,%d)\n",
			x[i],y[i],x[i]+w[i],y[i],x[i]+w[i],y[i]+h[i],x[i],y[i]+h[i]);
		if (print_labels)
		{
	        fprintf(fo, "\t\t%%\\rput[bl](%.5f,%.5f){\\tiny %d (%d x %d)}\n" ,x[i]+epsx,y[i]+epsy,i,w[i],h[i]);
	        fprintf(fo, "\t\t\\rput[bl](%.5f,%.5f){\\tiny %d}\n" ,x[i]+epsx,y[i]+epsy,i);
        }
	}

    // *** final doc stuff ***
	fprintf(fo,"\t\t\\end{pspicture}\n");

	if (print_caption) fprintf(fo,"\t\t\\caption{%s.}\n",caption);

	fprintf(fo,"\t\\end{figure}\n");
	fprintf(fo,"\\end{document}\n");

    // *** close file ***
	fclose(fo);
	return 0;
}
// ************************************************************************************************************

// ************************************************************************************************************
int Print_2D_PhaseI(int n, int W, int H, int *w, int *h, int *x, bool print_labels,
				 bool print_caption, bool print_colors, char* caption, char* output_file_name)
	// n = number of items
	// W, H = width, height of the bin
	// *w, *h, *x = widths, heights AND x-coordinates of the items
	// print_labels = true if items number on output, false otherwise
	// print_caption = true if items number on output, false otherwise
	// print_colors = true if colors should be used, false otherwise
	// caption = caption to be printed
	// output_file_name = name of output file
{
	// *** variables ***
	double textwidth, textheight, top, xunit, yunit; //counters
	double eps = 0.05; //to put a string
	int i, j, *hh, y;
	FILE *fo; //output file

	// *** memory ***
	hh = (int*)malloc(sizeof(int)*W);

	// *** open file ***
    if ( (fo = fopen(output_file_name,"w")) == NULL ) {
        printf("\not able to open file %s \n", output_file_name);
        return -1;
    }

    // *** init file info ***
	textwidth = 18.0;
	textheight = 23.0;
	top = 0.5;

    // *** starting doc stuff ***
	fprintf(fo,"\\documentclass[11pt]{article}\n");
	fprintf(fo,"\\usepackage[textwidth=%.1fcm, textheight=%.1fcm, top=%.1fcm]{geometry}\n",
		textwidth, textheight, top);
	fprintf(fo,"\\usepackage[usenames,dvipsnames]{xcolor}\n");
	fprintf(fo,"\\usepackage{pst-all}\n");
	fprintf(fo,"\\usepackage{amssymb}\n");
	fprintf(fo,"\\begin{document}\n");
	fprintf(fo,"\t\\pagestyle{empty}\n");
	fprintf(fo,"\t\\begin{figure}[htp]\n");

	// *** W and H ***
	xunit = textwidth / W;
	yunit = textheight / H;
	fprintf(fo,"\t\t\\psset{xunit=%.5fcm, yunit=%.5fcm}\n",xunit,yunit);
	fprintf(fo,"\t\t\\begin{pspicture}(0,0)(%d,%d)\n",W,H);

	// *** bin ***
	fprintf(fo,"\t\t\\pspolygon[linewidth=1.5pt, fillstyle=solid, fillcolor=lightgray](0,0)(%d,0)(%d,%d)(0,%d)\n",W,W,H,H);

	// *** items ***
	for (i = 0; i < W; i++) hh[i]=0;
	for (j = 0; j < n; j++) {
		for (i = x[j]; i < x[j] + w[j]; i++) {
			y = hh[i];
			hh[i] += h[j];
			if (print_colors) {
				fprintf(fo,"\t\t\\pspolygon[linewidth=0.5pt, fillstyle=solid, fillcolor=");
				switch(j){
					case(0):fprintf(fo,"red");break;
					case(1):fprintf(fo,"green");break;
					case(2):fprintf(fo,"blue");break;
					case(3):fprintf(fo,"cyan");break;
					case(4):fprintf(fo,"magenta");break;
					case(5):fprintf(fo,"yellow");break;
					case(6):fprintf(fo,"gray");break;
					case(7):fprintf(fo,"darkgray");break;
					case(8):fprintf(fo,"lightgray");break;
					case(9):fprintf(fo,"brown");break;
					case(10):fprintf(fo,"lime");break;
					case(11):fprintf(fo,"olive");break;
					case(12):fprintf(fo,"orange");break;
					case(13):fprintf(fo,"pink");break;
					case(14):fprintf(fo,"purple");break;
					case(15):fprintf(fo,"teal");break;
					case(16):fprintf(fo,"violet");break;
					case(17):fprintf(fo,"Apricot");break;
					case(18):fprintf(fo,"Aquamarine");break;
					case(19):fprintf(fo,"Bittersweet");break;
					case(20):fprintf(fo,"BlueGreen");break;
					case(21):fprintf(fo,"BlueViolet");break;
					case(22):fprintf(fo,"BrickRed");break;
					case(23):fprintf(fo,"BurntOrange");break;
					case(24):fprintf(fo,"CadetBlue");break;
					case(25):fprintf(fo,"CarnationPink");break;
					case(26):fprintf(fo,"Cerulean");break;
					case(27):fprintf(fo,"CornflowerBlue");break;
					case(28):fprintf(fo,"Dandelion");break;
					case(29):fprintf(fo,"DarkOrchid");break;
					case(30):fprintf(fo,"Emerald");break;
					case(31):fprintf(fo,"ForestGreen");break;
					case(32):fprintf(fo,"Fuchsia");break;
					case(33):fprintf(fo,"Goldenrod");break;
					case(34):fprintf(fo,"GreenYellow");break;
					case(35):fprintf(fo,"JungleGreen");break;
					case(36):fprintf(fo,"Lavender");break;
					case(37):fprintf(fo,"LimeGreen");break;
					case(38):fprintf(fo,"Mahogany");break;
					case(39):fprintf(fo,"Maroon");break;
					case(40):fprintf(fo,"Melon");break;
					case(41):fprintf(fo,"MidnightBlue");break;
					case(42):fprintf(fo,"Mulberry");break;
					case(43):fprintf(fo,"NavyBlue");break;
					case(44):fprintf(fo,"OliveGreen");break;
					case(45):fprintf(fo,"OrangeRed");break;
					case(46):fprintf(fo,"Orchid");break;
					case(47):fprintf(fo,"Peach");break;
					case(48):fprintf(fo,"Periwinkle");break;
					case(49):fprintf(fo,"PineGreen");break;
					case(50):fprintf(fo,"Plum");break;
					case(51):fprintf(fo,"ProcessBlue");break;
					case(52):fprintf(fo,"Purple");break;
					case(53):fprintf(fo,"RawSienna");break;
					case(54):fprintf(fo,"Red");break;
					case(55):fprintf(fo,"RedOrange");break;
					case(56):fprintf(fo,"RedViolet");break;
					case(57):fprintf(fo,"Rhodamine");break;
					case(58):fprintf(fo,"RoyalBlue");break;
					case(59):fprintf(fo,"RoyalPurple");break;
					case(60):fprintf(fo,"RubineRed");break;
					case(61):fprintf(fo,"Salmon");break;
					case(62):fprintf(fo,"SeaGreen");break;
					case(63):fprintf(fo,"Sepia");break;
					case(64):fprintf(fo,"SkyBlue");break;
					case(65):fprintf(fo,"SpringGreen");break;
					case(66):fprintf(fo,"Tan");break;
					case(67):fprintf(fo,"TealBlue");break;
					case(68):fprintf(fo,"Thistle");break;
					case(69):fprintf(fo,"Turquoise");break;
					case(70):fprintf(fo,"Violet");break;
					case(71):fprintf(fo,"VioletRed");break;
					case(72):fprintf(fo,"WildStrawberry");break;
					case(73):fprintf(fo,"YellowGreen");break;
					case(74):fprintf(fo,"YellowOrange");break;
					default:fprintf(fo,"white");break;
				}
				fprintf(fo,"](%d,%d)(%d,%d)(%d,%d)(%d,%d)\n",i,y,i+1,y,i+1,y+h[j],i,y+h[j]);
			} else {
				fprintf(fo,"\t\t\\pspolygon[linewidth=0.5pt, fillstyle=solid, fillcolor=white](%d,%d)(%d,%d)(%d,%d)(%d,%d)\n",
					i,y,i+1,y,i+1,y+h[j],i,y+h[j]);
			}
			if (print_labels) fprintf(fo,"\t\t\\rput[bl](%.5f,%.5f){\\tiny %d}\n",i+eps,y+eps,j);
		}
	}

    // *** final doc stuff ***
	fprintf(fo,"\t\t\\end{pspicture}\n");

	if (print_caption) fprintf(fo,"\t\t\\caption{%s.}\n",caption);

	fprintf(fo,"\t\\end{figure}\n");
	fprintf(fo,"\\end{document}\n");

	int hmax = 0;
	for (i = 0; i < W; i++) if (hh[i]>hmax) hmax = hh[i];
	printf("hmax = %d\n",hmax);

    // *** close file and erase memory ***
	fclose(fo);
	free(hh);
	return 0;
}
