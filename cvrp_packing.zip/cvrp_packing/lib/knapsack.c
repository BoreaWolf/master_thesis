

#include "knapsack.h"
#include <stdio.h> 
#include <stdlib.h> 

//definition of the items
typedef struct
{
	int id;			//id
	int w;			//weight
	int p;			//profit
	int x;			//0-1 value if the item is in the knapsack or not
} knapsack_item_t;

typedef struct
{
	unsigned long long nbnodes; 	//number of visited nodes	
	int n;							//number of items
	int W;							//Capacity
	knapsack_item_t * items;		//list of items
	int ub;							//value of the best solution so far		
	int lb;							//best lower bound so far
	int cur_item;					//Current item that is consider
	int cur_sum_w;					//Current sum of weight
	int cur_sum_p;					//Current sum of profits
	int * sol; 						//current best solution
} knapsack_t;


//Function for sorting, sort by decreasing ratio p/w
int knapsack_knapsack_item_cmp(const void *a, const void *b)
{
	knapsack_item_t * a1 = (knapsack_item_t *)a;
	knapsack_item_t * b1 = (knapsack_item_t *)b;
	double a2 = a1->p / (double)a1->w;
	double b2 = b1->p / (double)b1->w;
	return  a2<b2?1:-1;
}

//return best found upper bound
int knapsack_bb(knapsack_t * sa)
{
	sa->nbnodes++;
	int i;
	int item = sa->cur_item;

#ifdef KNAPSACK_H_OUTPUT
	printf("node:%llu item:%d lb:%d sump:%d items:", 
				sa->nbnodes,sa->cur_item, sa->lb,sa->cur_sum_p);
	for(i=0;i<sa->cur_item;i++)
		printf("%d ", sa->items[i].x);
	printf("\n");
#endif

	if(sa->cur_sum_p > sa->lb)
	{
		sa->lb = sa->cur_sum_p;
		for(i=0;i<item;i++)
			sa->sol[sa->items[i].id] = sa->items[i].x;
		for(i=item;i<sa->n;i++)
			sa->sol[sa->items[i].id] = 0;
			
#ifdef KNAPSACK_H_OUTPUT			
		printf("Found new solution sumw:%d sump:%d\n", sa->cur_sum_w,sa->cur_sum_p);
		for(i=0;i<item;i++)
			if(sa->items[i].x == 1)
				printf("%d ", sa->items[i].id);
		printf("\n");
#endif
		if(sa->ub < sa->cur_sum_p)
			sa->ub = sa->cur_sum_p;
	}
	if(sa->cur_item >= sa->n) return sa->cur_sum_p;
	
	int lb1 = 0;
	int lb2 = 0;
	int sum_w = sa->cur_sum_w;
	double sum_p = sa->cur_sum_p;
	
	//calculate an upper bound from the current item
	for(i=item;i<sa->n;i++)
		if(sum_w + sa->items[i].w <= sa->W)
		{
			sum_p += sa->items[i].p;
			sum_w += sa->items[i].w;
		}
		else
			break;
			
	//take the last fractional part	
	if(i < sa->n)	
		sum_p += (int)(((sa->W - sum_w) / (double)sa->items[i].w) * sa->items[i].p);
	
	//printf("sum_p:%lf lb:%d\n", sum_p, sa->lb);
	if(sum_p <= sa->lb)
	{
		return 0;
	}		
	else
	{
		if(sa->items[item].w + sa->cur_sum_w <= sa->W)
		{
			sa->items[item].x = 1;
			sa->cur_sum_w += sa->items[item].w;
			sa->cur_sum_p += sa->items[item].p;
			sa->cur_item = item+1;
			
			lb1 = knapsack_bb(sa);
			
			sa->cur_sum_w -= sa->items[item].w;
			sa->cur_sum_p -= sa->items[item].p;
		}
			
		sa->items[item].x = 0;
		sa->cur_item = item+1;
		
		lb2 = knapsack_bb(sa);
		sa->cur_item = item;
	}
	return lb1<lb2?lb1:lb2;
}

int knapsack_solve(int W, int n, int * w, int * p, int * x)
{
	int i;
	knapsack_t sa;
	sa.nbnodes = 0;
	sa.n = n;
	sa.W = W;
	sa.items = (knapsack_item_t*)malloc(sizeof(knapsack_item_t) * n);
	sa.sol =(int*)calloc(n,sizeof(int)); 
	
	for(i=0;i<n;i++)
	{
		sa.items[i].id = i;
		sa.items[i].w = w[i];
		sa.items[i].p = p[i];
		sa.items[i].x = 0;
	}
	qsort(sa.items, n, sizeof(knapsack_item_t), knapsack_knapsack_item_cmp);

#ifdef KNAPSACK_H_OUTPUT	
	for(i=0;i<n;i++)
		printf("item:%d w:%d p:%d fr:%lf\n", sa.items[i].id, sa.items[i].w,sa.items[i].p,sa.items[i].p/(double)sa.items[i].w );
#endif
	
	sa.lb = 0;
	int sumw = 0;
	for(i=0;i<n;i++)
		if(sumw + sa.items[i].w <= W)
		{
			sa.sol[ sa.items[i].id ] = 1;
			sa.lb += sa.items[i].p;
			sumw += sa.items[i].w;
		}
		else
			break;
#ifdef KNAPSACK_H_OUTPUT
	printf("sumw:%d sump:%d\n", sumw, sa.lb);
#endif

	sa.ub = sa.lb;
	if(i < n) 
		sa.ub += (int)(((W - sumw) / (double)sa.items[i].w) * sa.items[i].p);
	
	sa.lb--;
	//printf("ub:%d lb:%d\n", sa.ub,sa.lb);
	
	if(sa.ub == ((double)sa.lb))// if all objects fit in the knapsack
		goto END;
	
	sa.cur_sum_w = 0;
	sa.cur_sum_p = 0;
	sa.cur_item = 0;
	
	knapsack_bb(&sa);
#ifdef KNAPSACK_H_OUTPUT	
	printf("ub:%d lb:%d nbnodes:%llu\n", sa.ub,sa.lb,sa.nbnodes);
#endif
END:
	if(sa.ub == ((double)sa.lb))
	{
#ifdef KNAPSACK_H_OUTPUT
		printf("in knapsack:");
		for(i=0;i<n;i++)
			if(sa.sol[sa.items[i].id] == 1)
				printf("%d ", sa.items[i].id);
		printf("\n");		
#endif
		for(i=0;i<n;i++)
			x[ sa.items[i].id ] = sa.sol[sa.items[i].id];
	}

	free(sa.items);
	free(sa.sol);
	return sa.lb;
}




