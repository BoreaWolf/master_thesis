#define SPARC_SUN_SOLARIS2

#ifndef CLOCK_INCLUDED
#define CLOCK_INCLUDED

#ifdef HPPA_1_1_HP_HPUX
#define _INCLUDE_POSIX_SOURCE
#include <unistd.h>
#include <sys/times.h>
#include <time.h>
#endif

#ifdef SPARC_SUN_SOLARIS1
#include <unistd.h>
#include <sys/types.h>
#include <sys/times.h>
#endif

#ifdef SPARC_SUN_SOLARIS2
#include <unistd.h>
#include <sys/times.h>
#include <limits.h>
#endif

struct ClkCLK
{
  clock_t clockStart;		/* Last time we consulted the clock          */
  clock_t clockTotal;		/* Total time elapsed                        */
  unsigned int fStart;		/* Is the clock started or not               */
};

typedef struct ClkCLK ClkCLK;
typedef double ClkSEC;


void ClkInit(ClkCLK *pclk);
void ClkReset(ClkCLK *pclk);
void ClkStart(ClkCLK *pclk);
void ClkStop(ClkCLK *pclk);
ClkSEC secClkGetTime(ClkCLK *pclk);

#endif
