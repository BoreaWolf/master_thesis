
#include "skyline_seq.h"
#include "mathfunc.h"
#include "stdlib.h"
#include "stdio.h"

skyline_seq_ptr skyline_seq_init(int length, int init_seq)
{
	skyline_seq_ptr s = (skyline_seq_ptr)malloc(sizeof(skyline_seq_t));
	s->head = skyline_seq_init_elem();
	s->head->x = 0;
	s->head->y = 0;
	s->head->length = length;
	s->head->seq = init_seq;
	return s;
}

skyline_seq_elem_ptr skyline_seq_init_elem()
{
	skyline_seq_elem_ptr p = (skyline_seq_elem_ptr)malloc(sizeof(skyline_seq_elem_t));
	p->next = NULL;
	p->prev = NULL;
	p->length = 0;
	p->x = 0;
	p->y = 0;
	p->seq = 99999;
	return 	p;
}

void skyline_seq_free(skyline_seq_ptr s)
{
	skyline_seq_elem_ptr c = s->head;
	while(c != NULL)
	{
		skyline_seq_elem_ptr next = c->next;
		free(c);
		c = next;
	}
	free(s);
}


int skyline_seq_touching(skyline_seq_ptr s, skyline_seq_elem_ptr line, int x,int h, int w, int seq)
{
	int y = line->y;
	int touch = 0;
	int lastx = line->x + line->length;
	
	if(((line->next != NULL && line->next->y > line->y) || line == NULL) && line->length < w)
		return -INF;
	
	if(line->prev != NULL && line->prev->y > y && line->prev->x + line->prev->length == x)
		touch += MIN_INT(h, line->prev->y - y);
	
	while(line != NULL && line->x < x+w && line->y <= y)
	{
		if(line->seq < seq) 
			return -INF;
		
		if(line->y == y) touch += MIN_INT(x+w, line->x + line->length) - MAX_INT(line->x, x);
		
		lastx = line->x + line->length;
		line = line->next;	
	}
	if(line != NULL && line->x == x+w && line->y > y)
		touch += MIN_INT(h, line->y - y);
	//else if (line == NULL)
	//	touch += h;
	
	if(lastx - x < w) return -INF;
	
	
	return touch;
}

skyline_seq_elem_ptr skyline_seq_get_min_y(skyline_seq_ptr s)
{
	skyline_seq_elem_ptr cur_min_y = s->head;
	
	skyline_seq_elem_ptr cur = s->head->next;
	while(cur != NULL)
	{
		if(cur->y < cur_min_y->y)
			cur_min_y = cur;
		cur = cur->next;
	}
	return cur_min_y;
}

void skyline_seq_add(skyline_seq_ptr s, int x, int y, int length, int seq)
{
	//printf("skyline_seq_add x:%d y:%d len:%d seq:%d\n",x,y,length,seq);
	//first, find the place to insert it
	skyline_seq_elem_ptr cur = s->head;
	while(cur != NULL && cur->x + cur->length <= x)
		cur = cur->next;
	
	if(cur == NULL || length <= 0)
	{
		printf("Should not happen..\n");
		printf("skyline_seq_add x:%d y:%d len:%d seq:%d\n",x,y,length,seq);
		exit(1);
	}
	
	if(cur->x == x)
		skyline_seq_add_over(s,cur,y,length,seq);
	else if(cur->x + cur->length == x + length) 
	{
		//if the end at the same spot and x is after cur->x
		skyline_seq_elem_ptr new_elem = skyline_seq_init_elem();
		new_elem->x = x;
		new_elem->y = y;
		new_elem->seq = seq;
		new_elem->length = length;
		cur->length = x - cur->x;
		
		new_elem->prev = cur;
		new_elem->next = cur->next;
		if(cur->next != NULL) cur->next->prev = new_elem;
		cur->next = new_elem;		
		
		//we have to go forward in the list of segments to remove
		//segments that are now blocked by the new one
		skyline_seq_elem_ptr sg = new_elem->next;
		while(sg != NULL && sg->x < x + length)
		{
			//if the segment is partially covered
			//update the x and the length of the segment
			if(sg->x + sg->length > x + length)
			{
				sg->length -= (cur->x + length) - sg->x;
				sg->x = cur->x + length;
				break;	
			}
			
			//otherwise, the segment is totally overlapped by cur
			//delete it
			skyline_seq_elem_ptr next = sg->next;
			skyline_seq_remove(s,sg);
			sg = next;
		}
		skyline_seq_partial_remove_same_y_elements(s,new_elem);
	}
	//the segment is added in the middle of a segment
	else if(cur->x < x && cur->x + cur->length > x + length)
	{
		skyline_seq_elem_ptr ne1 = skyline_seq_init_elem();
		ne1->x = x;
		ne1->y = y;
		ne1->length = length;
		ne1->seq = seq;
		
		skyline_seq_elem_ptr ne2 = skyline_seq_init_elem();
		ne2->x = x+length;
		ne2->y = cur->y;
		ne2->length = (cur->x + cur->length) - (x+length);
		ne1->next = ne2;
		ne1->prev = cur;
		ne2->prev = ne1;
		ne2->next = cur->next;
		ne2->seq = cur->seq;
		
		cur->length = x - cur->x;
		
		if(cur->next != NULL) cur->next->prev = ne2;
		cur->next = ne1;
	} 
	else if(cur->x < x && cur->x + cur->length < x + length)
	{
		//printf("Got here\n");
		//printf("skyline_seq_add x:%d y:%d len:%d seq:%d\n",x,y,length,seq);
		//skyline_seq_show(s);
		
		skyline_seq_elem_ptr ne = skyline_seq_init_elem();
		ne->x = x;
		ne->y = y;
		ne->seq = seq;
		ne->length = cur->x + cur->length - x;
		cur->length = x-cur->x;
		
		
		ne->next = cur->next;
		ne->prev = cur;
		cur->next = ne;
		ne->next->prev = ne->next->prev = ne;
		
		//printf("skyline_seq_add_over x:%d y:%d len:%d seq:%d\n",cur->next->x,y,length - ne->length,seq);
		skyline_seq_add_over(s,cur->next,y,length - ne->length,seq);
		
		//printf("result\n");
		//skyline_seq_show(s);
	}
}

void skyline_seq_add_over(skyline_seq_ptr s,skyline_seq_elem_ptr cur, int y, int length, int seq)
{	
	if(length == cur->length)
	{
		cur->y = y;
		cur->seq = seq;
	}
	else if(length < cur->length) 
	{
		//otherwise, //if the segment is longer than the item
		//update the height of the segment and its length and add another segment at the end of this one
		//first add a segment
		skyline_seq_elem_ptr sg = skyline_seq_init_elem();
		sg->x = cur->x + length;
		sg->y = cur->y;
		sg->length = cur->length - length;
		sg->next = cur->next;
		sg->prev = cur;
		sg->seq = cur->seq;
		
		cur->length = length;
		cur->y = y;
		cur->seq = seq;
		
		//put pointers
		skyline_seq_elem_ptr next = cur->next;
		if(next != NULL) next->prev = sg;
		cur->next = sg;
	}
	else if(length > cur->length)
	{
		//the item is longer than the segment				
		cur->length = length;
		cur->y = y;
		cur->seq = seq;
		
		//we have to go forward in the list of segments to remove
		//segments that are now blocked by the item
		skyline_seq_elem_ptr sg = cur->next;
		while(sg != NULL && sg->x < cur->x + length)
		{
			//if the segment is partially covered
			//update the x and the length of the segment
			if(sg->x + sg->length > cur->x + length)
			{
				sg->length -= (cur->x + length) - sg->x;
				sg->x = cur->x + length;
				break;	
			}
			
			//otherwise, the segment is totally overlapped by cur
			//delete it
			skyline_seq_elem_ptr next = sg->next;
			skyline_seq_remove(s,sg);
			sg = next;
		}
	}
	skyline_seq_partial_remove_same_y_elements(s,cur);
}


//elevate line and its others neighbors that are at the same height
int skyline_seq_close(skyline_seq_ptr s,skyline_seq_elem_ptr line)
{
	int miny_prev = 999999;
	
	skyline_seq_elem_ptr first = line;
	skyline_seq_elem_ptr last = line;
	while(first->prev != NULL && first->prev->y == line->y)
		first = first->prev;
	
	while(last->next != NULL && last->next->y == line->y)
		last = last->next;
	
	
	skyline_seq_elem_ptr prev = first->prev;
	skyline_seq_elem_ptr next = last->next;

	int nexty = prev != NULL? prev->y:9999999;
	nexty = next != NULL && nexty > next->y?next->y:nexty; 
	
	line->y = nexty;
	skyline_seq_elem_ptr cur = first;
	while(cur != last->next)
	{
		cur->y = nexty;
		cur = cur->next;	
	}
	if(first != last)
	{
		skyline_seq_partial_remove_same_y_elements(s,first);
		skyline_seq_partial_remove_same_y_elements(s,last);
	}
	else
		skyline_seq_partial_remove_same_y_elements(s,line);
	return nexty;
}

void skyline_seq_partial_remove_same_y_elements(skyline_seq_ptr s,skyline_seq_elem_ptr line)
{
	skyline_seq_elem_ptr next = line->next;
	skyline_seq_elem_ptr prev = line->prev;	
	
	if(next != NULL && next->y == line->y && next->seq == line->seq)
	{
		line->length += next->length;
		skyline_seq_remove(s,next);
	}
	
	if(prev != NULL && prev->y == line->y && prev->seq == line->seq)
	{
		prev->length += line->length;
		skyline_seq_remove(s,line);
	}
}

void skyline_seq_remove_same_y_elements(skyline_seq_ptr s)
{
	skyline_seq_elem_ptr sg = s->head;
	while(sg != NULL)
	{
		skyline_seq_elem_ptr next = sg->next;
		if(next != NULL && sg->y == next->y && sg->seq == next->seq)
		{
			next->length += sg->length;
			next->x = sg->x;
			//printf("Removing same y element\n");
			//skyline_seq_show(s);
			skyline_seq_remove(s,sg);
			if(s->head == sg)
			{
				s->head = next;
				if(s->head == NULL)
				{
					int a = 3;
				}
			}
		}
		sg = next;
	}
}

void skyline_seq_remove(skyline_seq_ptr s,skyline_seq_elem_ptr elem)
{
	skyline_seq_elem_ptr next = elem->next;
	skyline_seq_elem_ptr prev = elem->prev;
	if(prev != NULL) prev->next = next;
	if(next != NULL) next->prev = prev;
	free(elem);
	
	if(s->head == elem) 
		s->head = next;
}

void skyline_seq_show(skyline_seq_ptr s)
{
	printf("skyline_seq_show\n");
	int k = 0;
	skyline_seq_elem_ptr cur = s->head;
	while(cur != NULL && k++ < 90000)
	{
		printf("x:%d y:%d len:%d seq:%d\n", cur->x,cur->y,cur->length,cur->seq);
		cur = cur->next;
	}
	//printf("\n");
	if(k == 90000)
	{
		printf("Infinite loop detected in skyline_seq_show_segments\n");
		exit(1);	
	}
}

void skyline_seq_check(skyline_seq_ptr s)
{
	int k = 0;
	skyline_seq_elem_ptr cur = s->head;
	while(cur != NULL && k++ < 90000)
	{
		if(cur->length <= 0)
		{
			printf("skyline_seq_check : length should not be zero\n");
			skyline_seq_show(s);
			exit(1);	
		}
		
		if(cur->next != NULL && cur->x >= cur->next->x)
		{
			printf("skyline_seq_check : next segment shouldn't be the same\n");
			skyline_seq_show(s);
			exit(1);
			
		}
		//printf("x:%d y:%d len:%d seq:%d\n", cur->x,cur->y,cur->length,cur->seq);
		cur = cur->next;
	}
	//printf("\n");
	if(k == 90000)
	{
		printf("Infinite loop detected in skyline_seq_show_segments\n");
		exit(1);	
	}	
}

