/*
 * Copyright Jean-Francois Cote 2012
 *
 * The code may be used for academic, non-commercial purposes only.
 *
 * Please contact me at cotejean@iro.umontreal.ca for questions
 *
 * If you have improvements, please contact me!
*/

#ifndef SKYLINE_H
#define SKYLINE_H

#ifdef __cplusplus
	extern "C" {
#endif

typedef struct skyline_elem* skyline_elem_ptr;
typedef struct skyline_elem
{
	int x;
	int y;
	int length;
	skyline_elem_ptr next;
	skyline_elem_ptr prev;
} skyline_elem_t;

typedef struct
{
	skyline_elem_ptr head;
} skyline_t;

typedef skyline_t* skyline_ptr;

//create a new data structure skyline
skyline_ptr 	skyline_init(int length);

//create a new element in the structure
skyline_elem_ptr skyline_init_elem();

//returns the number of line inside
int skyline_count(skyline_ptr s);

//delete a skyline and all its elements
void skyline_free(skyline_ptr s);

//add a segment into the structure
void skyline_add(skyline_ptr s,int x, int y, int length);

//add a segment over elem
void skyline_add_over(skyline_ptr s,skyline_elem_ptr elem, int y, int length);

//delete an element of the skyline
void skyline_remove(skyline_ptr s,skyline_elem_ptr elem);

//get the segment with the minimal y
skyline_elem_ptr skyline_get_min_y(skyline_ptr s);

//put the y of the elem to the y minimal y of its neighboors
//its neightboor should have a bigger y otherwise it will crash
//return the y of the choosen neighboor
int skyline_close_element(skyline_ptr s,skyline_elem_ptr elem);

void skyline_show(skyline_ptr s);

void skyline_partial_remove_same_y_elements(skyline_ptr s,skyline_elem_ptr line);
void skyline_remove_same_y_elements(skyline_ptr s);

#ifdef __cplusplus
	}
#endif

#endif