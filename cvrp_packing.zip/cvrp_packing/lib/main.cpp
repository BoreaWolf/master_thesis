/* 
 * File:   main.cpp
 * Author: MI
 *
 * Created on 23/02/2012
 */
#include <stdio.h>
#include <cstdlib>
#include <iostream>
#define MAXN 1000
using namespace std;

//void DrawSolPhaseI(int n,int W, int H, int* w, int* h, int* x, int* y);
int DrawSolPhaseI(int n, int W, int H, int *w, int *h, int *x, bool print_labels, 
				 bool print_caption, bool print_colors, char* caption, char* output_file_name);
int DrawSolPhaseII(int n, int W, int H, int *w, int *h, int *x, int *y, bool print_labels, 
				 bool print_caption, char* caption, char* output_file_name);

int main(int argc, char** argv) {
	int n;
	int W, H;
	int j;
	int w[MAXN], h[MAXN], x[MAXN], y[MAXN];
	char output_file_nameI[12]= "outputI.tex";
	char output_file_nameII[13]= "outputII.tex";
	bool print_labels = true;
	bool print_caption = true;
	bool print_colors = true;
	char caption[9] = "instance";
	freopen("input.txt", "r", stdin );

	// INPUT
	cin >> n;
	cin >> W >> H;
	for (j = 0; j < n; j++) cin >> w[j] >> h[j] >> x[j] >> y[j];

	// PHASE I
	DrawSolPhaseI(n,W,H,w,h,x,print_labels,print_caption,print_colors,caption,output_file_nameI);

	// PHASE II
	DrawSolPhaseII(n,W,H,w,h,x,y,print_labels,print_caption,caption,output_file_nameII);

	cout << "done" << endl;
	return 0;
}

// ************************************************************************************************************
int DrawSolPhaseII(int n, int W, int H, int *w, int *h, int *x, int *y, bool print_labels, 
				 bool print_caption, char* caption, char* output_file_name)
	// n = number of items
	// W, H = width, height of the bin
	// *w, *h, *x, *y = widths, heights, x-coordinates and y-coordinates of the items
	// print_labels = true if items number on output, false otherwise
	// print_caption = true if items number on output, false otherwise
	// caption = caption to be printed
	// output_file_name = name of output file
{
	// *** variables ***
	double textwidth, textheight, top, xunit, yunit; //counters
	double eps = 0.05; //to put a string 
	int i;
	FILE *fo; //output file

	// *** open file ***
    if ( (fo = fopen(output_file_name,"w")) == NULL ) {
        printf("\not able to open file %s \n", output_file_name);
        return -1;
    }

    // *** init file info ***
	textwidth = 18.0;
	textheight = 23.0; 
	top = 0.5;

    // *** starting doc stuff ***
	fprintf(fo,"\\documentclass[11pt]{article}\n");
	fprintf(fo,"\\usepackage[textwidth=%.1fcm, textheight=%.1fcm, top=%.1fcm]{geometry}\n",
		textwidth, textheight, top);
	fprintf(fo,"\\usepackage{pst-all}\n");
	fprintf(fo,"\\usepackage{amssymb}\n");
	fprintf(fo,"\\begin{document}\n");
	fprintf(fo,"\t\\pagestyle{empty}\n");
	fprintf(fo,"\t\\begin{figure}[htp]\n");

	// *** W and H ***
	xunit = textwidth / W;
	yunit = textheight / H;
	fprintf(fo,"\t\t\\psset{xunit=%.5fcm, yunit=%.5fcm}\n",xunit,yunit);
	fprintf(fo,"\t\t\\begin{pspicture}(0,0)(%d,%d)\n",W,H);

	// *** bin ***
	fprintf(fo,"\t\t\\pspolygon[linewidth=1.5pt, fillstyle=solid, fillcolor=lightgray](0,0)(%d,0)(%d,%d)(0,%d)\n",W,W,H,H);
    
	// *** items ***
	for (i = 0; i < n; i++) {
		fprintf(fo,"\t\t\\pspolygon[linewidth=0.5pt, fillstyle=solid, fillcolor=white](%d,%d)(%d,%d)(%d,%d)(%d,%d)\n",
			x[i],y[i],x[i]+w[i],y[i],x[i]+w[i],y[i]+h[i],x[i],y[i]+h[i]);
		if (print_labels)
			fprintf(fo,"\t\t\\rput[bl](%.5f,%.5f){\\tiny %d (%d x %d)}\n",x[i]+eps,y[i]+eps,i,w[i],h[i]);
	}
        
    // *** final doc stuff ***
	fprintf(fo,"\t\t\\end{pspicture}\n");

	if (print_caption) fprintf(fo,"\t\t\\caption{%s.}\n",caption);

	fprintf(fo,"\t\\end{figure}\n");
	fprintf(fo,"\\end{document}\n");

    // *** close file ***
	fclose(fo);
	return 0;
}
// ************************************************************************************************************

// ************************************************************************************************************
int DrawSolPhaseI(int n, int W, int H, int *w, int *h, int *x, bool print_labels, 
				 bool print_caption, bool print_colors, char* caption, char* output_file_name)
	// n = number of items
	// W, H = width, height of the bin
	// *w, *h, *x = widths, heights AND x-coordinates of the items
	// print_labels = true if items number on output, false otherwise
	// print_caption = true if items number on output, false otherwise
	// print_colors = true if colors should be used, false otherwise
	// caption = caption to be printed
	// output_file_name = name of output file
{
	// *** variables ***
	double textwidth, textheight, top, xunit, yunit; //counters
	double eps = 0.05; //to put a string
	int i, j, *hh, y;
	FILE *fo; //output file

	// *** memory ***
	hh = new int[W];

	// *** open file ***
    if ( (fo = fopen(output_file_name,"w")) == NULL ) {
        printf("\not able to open file %s \n", output_file_name);
        return -1;
    }

    // *** init file info ***
	textwidth = 18.0;
	textheight = 23.0; 
	top = 0.5;

    // *** starting doc stuff ***
	fprintf(fo,"\\documentclass[11pt]{article}\n");
	fprintf(fo,"\\usepackage[textwidth=%.1fcm, textheight=%.1fcm, top=%.1fcm]{geometry}\n",
		textwidth, textheight, top);
	fprintf(fo,"\\usepackage{pst-all}\n");
	fprintf(fo,"\\usepackage{amssymb}\n");
	fprintf(fo,"\\usepackage{xcolor}\n");
	fprintf(fo,"\\begin{document}\n");
	fprintf(fo,"\t\\pagestyle{empty}\n");
	fprintf(fo,"\t\\begin{figure}[htp]\n");

	// *** W and H ***
	xunit = textwidth / W;
	yunit = textheight / H;
	fprintf(fo,"\t\t\\psset{xunit=%.5fcm, yunit=%.5fcm}\n",xunit,yunit);
	fprintf(fo,"\t\t\\begin{pspicture}(0,0)(%d,%d)\n",W,H);

	// *** bin ***
	fprintf(fo,"\t\t\\pspolygon[linewidth=1.5pt, fillstyle=solid, fillcolor=lightgray](0,0)(%d,0)(%d,%d)(0,%d)\n",W,W,H,H);
    
	// *** items ***
	for (i = 0; i < W; i++) hh[i]=0; 
	for (j = 0; j < n; j++) {
		for (i = x[j]; i < x[j] + w[j]; i++) {
			y = hh[i];
			hh[i] += h[j];
			if (print_colors) {
				fprintf(fo,"\t\t\\pspolygon[linewidth=0.5pt, fillstyle=solid, fillcolor=");
				switch(j){
					case(0):fprintf(fo,"red");break;
					case(1):fprintf(fo,"green");break;
					case(2):fprintf(fo,"blue");break;
					case(3):fprintf(fo,"cyan");break;
					case(4):fprintf(fo,"magenta");break;
					case(5):fprintf(fo,"yellow");break;
					case(6):fprintf(fo,"gray");break;
					case(7):fprintf(fo,"darkgray");break;
					case(8):fprintf(fo,"lightgray");break;
					case(9):fprintf(fo,"brown");break;
					case(10):fprintf(fo,"lime");break;
					case(11):fprintf(fo,"olive");break;
					case(12):fprintf(fo,"orange");break;
					case(13):fprintf(fo,"pink");break;
					case(14):fprintf(fo,"purple");break;
					case(15):fprintf(fo,"teal");break;
					case(16):fprintf(fo,"violet");break;
					default:fprintf(fo,"white");break;
				}
				fprintf(fo,"](%d,%d)(%d,%d)(%d,%d)(%d,%d)\n",i,y,i+1,y,i+1,y+h[j],i,y+h[j]);
			} else {
				fprintf(fo,"\t\t\\pspolygon[linewidth=0.5pt, fillstyle=solid, fillcolor=white](%d,%d)(%d,%d)(%d,%d)(%d,%d)\n",
					i,y,i+1,y,i+1,y+h[j],i,y+h[j]);
			}
			if (print_labels) fprintf(fo,"\t\t\\rput[bl](%.5f,%.5f){\\tiny %d}\n",i+eps,y+eps,j);
		}
	}
        
    // *** final doc stuff ***
	fprintf(fo,"\t\t\\end{pspicture}\n");

	if (print_caption) fprintf(fo,"\t\t\\caption{%s.}\n",caption);

	fprintf(fo,"\t\\end{figure}\n");
	fprintf(fo,"\\end{document}\n");

    // *** close file and erase memory ***
	fclose(fo);
	free(hh);
	return 0;
}
// ************************************************************************************************************
