

#include "subset.h"
#include "util.h"
#include "mathfunc.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

void subset_init(subset_ptr s,unsigned int n,unsigned int W)
{
	s->n = n;
	s->W = W;
	s->w = (unsigned short int*)malloc(sizeof(unsigned int) * n);
	s->pos = (char*)malloc(sizeof(char) * (s->W+1));
	s->bits0 = (uint32_t*)(uint32_t*)calloc((W+32)/32+2, sizeof(uint32_t));
	s->bits1 = (uint32_t*)(uint32_t*)calloc((W+32)/32+2, sizeof(uint32_t));
}

void subset_free(subset_ptr s)
{
	free(s->w);
	free(s->pos);
	free(s->bits0);
	free(s->bits1);
}

void subset_sum_pos(subset_ptr s)
{
	subset_t tt = *s;

	unsigned max_words = (s->W+32)/32;

	memset(s->bits0, 0, max_words*sizeof(uint32_t));
	memset(s->bits1, 0, max_words*sizeof(uint32_t));

	s->bits0[0] = 1;
	s->bits1[0] = 1;
	unsigned last_word = 0;
	unsigned max_last_word = max_words;
    unsigned i;
	for ( i = 0; i < s->n; i++)
	{
		unsigned w = s->w[i];
		if(w > s->W) continue;
		unsigned word_shift = w/32;
		unsigned bit_shift = w%32;
		unsigned max_weight = max_last_word-word_shift;
		max_weight = MIN_INT(max_weight, last_word);
		unsigned j;
		for (j = 0; j <= max_weight; j++)
		{
			uint64_t mask = (uint64_t)s->bits0[j]<<bit_shift;
			s->bits1[j] |= s->bits0[j];
			s->bits1[j+word_shift] |= (uint32_t)mask;
			s->bits1[j+word_shift+1] |= (uint32_t)(mask>>32);
		}
		for (; j <= max_last_word; j++)
			s->bits1[j] |= s->bits0[j];
		{
			uint32_t * tmp = s->bits0;
			s->bits0 = s->bits1;
			s->bits1 = tmp;
		}
		last_word = last_word + word_shift+1;
		last_word = MIN_INT(last_word, max_last_word);
	}

	for (i = 0; i <= s->W; i++)
	{
		unsigned word = i/32;
		unsigned bit  = i%32;
		s->pos[i] = (s->bits0[word]>>bit)&1;
	}
}


void subset_sum_pos_simple(int n, int * w,int W, char * pos)
{
	unsigned int last = 0;
	/* variables */
	int i,p,b; //counter

	// *** initialize ***
	pos[0] = 1;
	for (i = 1; i <= W; i++)
		pos[i] = 0;

	for (i = 0; i < n; i++)
	{
		p = MIN_INT(W-w[i],last);
		b = p + w[i];
		for (;p >= 0; p--,b--)
		{
			pos[b] |= pos[p];
			last = MAX_INT(b * pos[p],last);
		}
	}
}

int subset_max_sum_pos_hot_start(int n, int * w,int W, char * pos)
{
	unsigned int last = 0;
	/* variables */
	int i,p,b; //counter

	// *** initialize ***
	pos[0] = 1;

	i = W+1;
	while(pos[--i] == 0);
	last = i;

	//printf("subset_max_sum_pos_hot_start n:%d W:%d last:%d\n",n,W,last);
	//for (i = 0; i < n; i++)
	//	printf("%d ", w[i]);
	//printf("\n");
	//for (i = 0; i <= W; i++)
	//	printf("%d ", pos[i]);
	//printf("\n");

	for (i = 0; i < n; i++)
	{
		p = MIN_INT(W-w[i],last);
		b = p + w[i];
		for (;p >= 0; p--,b--)
		{
			pos[b] |= pos[p];
			last = MAX_INT(b * pos[p],last);
		}
	}
	//printf("Sol:\n");
	//for (i = 0; i <= W; i++)
	//	printf("%d ", pos[i]);
	//printf("\n");
	for (i = 0; i <= W; i++)
		pos[i] = 0;
	return last;
}

int subset_max_sum_pos_multiple_choice(int n, int * w,int W, int * clss, int class_count)
{
	int i,j,b,p,c,last;
	char * next_pos = (char*)calloc((W+1),sizeof(char));
	char * pos = (char*)calloc((W+1),sizeof(char));
	int * classes_count = (int*)calloc(class_count,sizeof(int));
	int ** classes = (int**)malloc(sizeof(int*) * class_count);

	for(i=0;i<n;i++)
		classes_count[ clss[i] ]++;
	for(i=0;i<class_count;i++)
	{
		classes[i] = (int*)malloc(sizeof(int*) * classes_count[i]);
		classes_count[i] = 0;
	}
	for(i=0;i<n;i++)
		classes[ clss[i] ][ classes_count[ clss[i] ]++ ] = w[i];

	pos[0] = 1;
	next_pos[0] = 1;
	last = 0;
	for (c = 0; c < class_count; c++) //c is the class
	{
		for(i=0;i<classes_count[c];i++)
		{
			printf("class:%d i:%d w:%d\n\t", c,i,classes[c][i]);
			for(p=0;p<=W;p++)
				printf("%d ", p % 10);
			printf("\n\t");
			for(p=0;p<=W;p++)
				printf("%d ", pos[p]);

			p = MIN_INT(W - classes[c][i],last);
			b = p +  classes[c][i];

			for (;p >= 0; p--,b--)
			{
				next_pos[b] |= pos[p];
				last = MAX_INT(b * next_pos[p],last);
			}

		}

		for(p=0;p<=W;p++)
			pos[p] |= next_pos[p];
		//char * temp = pos;
		//pos = next_pos;
		//next_pos = temp;
	}

	for(p=W;p>=0 && pos[p] == 0;p--);
	last = p;


	for(i=0;i<class_count;i++)
		free(classes[i]);
	free(classes);
	free(pos);
	free(next_pos);
	return last;
}

int subset_max_sum_pos_multiple_choice_space_constrained(int n, int * w,int W, int * clss, int class_count, int * free_space)
{
	int i,j,b,p,c,fs,last,ifs;
	/*
	printf("subset_max_sum_pos_multiple_choice_space_constrained n:%d W:%d class_count:%d\n",n,W,class_count);
	for(i=0;i<n;i++)
		printf("i:%d w:%d class:%d fs:%d\n", i, w[i], clss[i],free_space[i]);
	*/

	int * pos_fs = (int*)calloc((W+1),sizeof(int));
	int diff_fs_count = 0;
	int * diff_fs = (int*)malloc(sizeof(int) * (W+1));

	/*printf("free_space:");
	for(i=0;i<n;i++)
		printf("%d ", free_space[i]);
	printf("\n");*/

	for(i=0;i<n;i++)
		if(pos_fs[ free_space[i] ] == 0)
		{
			diff_fs[ diff_fs_count ] = free_space[i];
			pos_fs[ free_space[i] ] = 1;
			diff_fs_count++;
		}

	/*printf("diff_free_space:");
	for(i=0;i<diff_fs_count;i++)
		printf("%d ", diff_fs[i]);
	printf("\n");
	printf("diff_free_space:");*/
	util_sort_int(diff_fs, diff_fs_count);
	for(i=0;i<diff_fs_count;i++)
	{
		//printf("%d ", diff_fs[i]);
		pos_fs[ diff_fs[i] ] = i;
	}
	//printf("\n");


	char ** pos = (char**)malloc(sizeof(char*) * diff_fs_count);
	char ** next_pos = (char**)malloc(sizeof(char*) * diff_fs_count);
	for(i=0;i<diff_fs_count;i++)
	{
		pos[i] = (char*)calloc((W+1),sizeof(char));
		next_pos[i] = (char*)calloc((W+1),sizeof(char));
	}

	int * classes_count = (int*)calloc(class_count,sizeof(int));
	int ** classes = (int**)malloc(sizeof(int*) * class_count);

	for(i=0;i<n;i++)
		classes_count[ clss[i] ]++;
	for(i=0;i<class_count;i++)
	{
		classes[i] = (int*)malloc(sizeof(int*) * classes_count[i]);
		classes_count[i] = 0;
	}
	for(i=0;i<n;i++)
		classes[ clss[i] ][ classes_count[ clss[i] ]++ ] = i;

	for(fs=0;fs<diff_fs_count;fs++)
	{
		pos[fs][0] = 1;
		next_pos[fs][0] = 1;
	}
	last = 0;
	for (c = 0; c < class_count; c++) //c is the class
	{
		for(i=0;i<classes_count[c];i++)
		{
			/*printf("class:%d i:%d w:%d index:%d fs:%d pos:%d\n\t  ", c,i,w[classes[c][i]],classes[c][i],
																	free_space[classes[c][i]],pos_fs[ free_space[classes[c][i]]]);
			for(p=0;p<=W;p++)
				printf("%d ", p % 10);
			printf("\n");

			for(fs=0;fs<diff_fs_count;fs++)
			{
				printf("\t%d:",diff_fs[fs]);
				for(p=0;p<=W;p++)
					printf("%d ", pos[fs][p]);
				printf("\n");
			}*/


			ifs = pos_fs[ free_space[ classes[c][i] ] ];
			for(fs=ifs;fs<diff_fs_count;fs++)
			{
				p = MIN_INT(W - w[classes[c][i]] - diff_fs[fs],last);
				b = p +  w[classes[c][i]];
				for (;p >= 0; p--,b--)
					if(pos[fs][p] > 0)
					{
						next_pos[fs][b] = MAX_INT(MAX_INT(pos[fs][p],next_pos[fs][b]),ifs+1);
						if(next_pos[fs][b] > 0 && last < b)
							last = b;
					}
			}

			/*printf("\n");
			for(fs=0;fs<diff_fs_count;fs++)
			{
				printf("\t%d:",diff_fs[fs]);
				for(p=0;p<=W;p++)
					printf("%d ", next_pos[fs][p]);
				printf("\n");
			}*/

		}

		for(fs=0;fs<diff_fs_count;fs++)
			for(p=0;p<=W;p++)
				pos[fs][p] = next_pos[fs][p];
	}


	int max_v = 0;
	for(fs=0;fs<diff_fs_count;fs++)
	{
		for(p=W-diff_fs[fs];p>=0 && pos[fs][p] <= pos_fs[diff_fs[fs]] ;p--);

		//printf("max for fs:%d space:%d p:%d v:%d pos:%d\n", fs, diff_fs[fs],p, p + diff_fs[fs],pos_fs[diff_fs[fs]]);
		max_v = MAX_INT(max_v,p + diff_fs[fs]);
	}

	for(i=0;i<class_count;i++)
		free(classes[i]);
	free(classes);
	free(classes_count);
	for(i=0;i<diff_fs_count;i++)
	{
		free(pos[i]);
		free(next_pos[i]);
	}
	free(pos);
	free(next_pos);
	free(pos_fs);
	free(diff_fs);
	return max_v;
}


/*void subset_init(subset_ptr s,unsigned int n,unsigned int W)
{
	s->n = n;
	s->W = W;
	s->w = (unsigned short int*)malloc(sizeof(unsigned int) * n);
	s->w_temp = (unsigned short int*)malloc(sizeof(unsigned short int) * n);
	s->ident = (unsigned short int*)malloc(sizeof(unsigned short int) * n);
	s->pos = (char*)malloc(sizeof(char) * (s->W+1));
	s->pos_list = (unsigned int*)malloc(sizeof(unsigned int) * (s->W+1));
	s->pos_count = 0;
}

void subset_free(subset_ptr s)
{
	free(s->w);
	free(s->w_temp);
	free(s->ident);
	free(s->pos);
	free(s->pos_list);
}

void subset_identicals(subset_ptr s)
{
	int i,j,m;
	util_sort_unsigned_short_int(s->w, s->n);

	for(i=0;i<s->n;i++)
		s->ident[i] = 1;

	m = 1;
	s->w_temp[0] = s->w[0];
	for(i=1;i<s->n;i++)
		if(s->w[i-1] != s->w[i])
			s->w_temp[m++] = s->w[i];
		else
			s->ident[m-1]++;
	for(i=0;i<m;i++)
		s->w[i] = s->w_temp[i];
	s->n = m;
}

void subset_get_positions(subset_ptr s)
{
	subset_identicals(s);

	unsigned int i,j,k,l,a;
	for(i=0;i<=s->W;i++)
		s->pos[i] = 0;

	s->pos_count = 1;
	s->pos_list[0] = 0;
	s->pos[0] = 1;
	s->ident[0]--;

	if(s->w[0] > s->W)
	{
		s->pos_count = 0;
		return;
	}
	else
	{
		s->pos_count = 1;
		s->pos_list[0] = 0;
		s->pos[0] = 1;
		s->ident[0]--;
	}

	for(i=0;i<s->n;i++)
	{
		l = s->pos_count;
		for(k=0;k<s->ident[i];k++)
			for(j=0;j<l;j++)
			{
				a = s->pos_list[j] + s->w[i] * (k+1);
				if(a <= s->W && s->pos[a] == 0)
				{
					s->pos[a] = 1;
					s->pos_list[s->pos_count++] = a;
				}
			}
	}

	//util_sort_unsigned_int(s->pos_list,(int) s->pos_count);
}*/
