/*
 * Copyright Jean-Francois Cote 2012
 *
 * The code may be used for academic, non-commercial purposes only.
 *
 * Please contact me at cotejean@iro.umontreal.ca for questions
 *
 * If you have improvements, please contact me!
*/

#ifndef SKYLINE_SEQ_H
#define SKYLINE_SEQ_H

#ifdef __cplusplus
	extern "C" {
#endif

typedef struct skyline_seq_elem* skyline_seq_elem_ptr;
typedef struct skyline_seq_elem
{
	int x;
	int y;
	int seq;					//minimal seq number
	int length;
	skyline_seq_elem_ptr next;
	skyline_seq_elem_ptr prev;
} skyline_seq_elem_t;

typedef struct
{
	skyline_seq_elem_ptr head;
} skyline_seq_t;

typedef skyline_seq_t* skyline_seq_ptr;

//create a new data structure skyline_seq
skyline_seq_ptr skyline_seq_init(int length, int init_seq);

//create a new element in the structure
skyline_seq_elem_ptr skyline_seq_init_elem();

//delete a skyline_seq and all its elements
void skyline_seq_free(skyline_seq_ptr s);

//return the amount of area that is touched by the rectangle (w,h,seq) put in x
//return -1 if it is not possible to put the object there (due to the sequential loading)
//return 0, if no line segment is bigger than w
int skyline_seq_touching(skyline_seq_ptr s, skyline_seq_elem_ptr line, int x,int h, int w, int seq);

//add a segment into the structure
void skyline_seq_add(skyline_seq_ptr s,int x, int y, int length, int seq);

//add a segment over elem
void skyline_seq_add_over(skyline_seq_ptr s,skyline_seq_elem_ptr cur, int y, int length,int seq);

//delete an element of the skyline_seq
void skyline_seq_remove(skyline_seq_ptr s, skyline_seq_elem_ptr elem);

//get the segment with the minimal y
skyline_seq_elem_ptr skyline_seq_get_min_y(skyline_seq_ptr s);

//put the y of the elem to the y minimal y of its neighboors
//its neightboor should have a bigger y otherwise it will crash
//return the y of the choosen neighboor
int skyline_seq_close(skyline_seq_ptr s,skyline_seq_elem_ptr elem);

void skyline_seq_check(skyline_seq_ptr s);
void skyline_seq_show(skyline_seq_ptr s);

void skyline_seq_remove_same_y_elements(skyline_seq_ptr s);

void skyline_seq_partial_remove_same_y_elements(skyline_seq_ptr s,skyline_seq_elem_ptr line);

#ifdef __cplusplus
	}
#endif

#endif


