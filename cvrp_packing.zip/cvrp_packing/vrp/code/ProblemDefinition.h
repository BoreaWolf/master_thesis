/*
 * Copyright Jean-Francois Cote 2012
 * 
 * The code may be used for academic, non-commercial purposes only.
 * 
 * Please contact me at cotejean@iro.umontreal.ca for questions
 *
 * If you have improvements, please contact me!
 *
*/

#ifndef PROBLEM_DEF_
#define PROBLEM_DEF_

#include <stddef.h>
#include <vector>
#include "constants.h"
#include "../../lib/primes.h"

template <class NodeT, class DriverT>
class Prob
{
	public:	
	Prob(): _nodes(0),_customers(0),_drivers(0),_distances(NULL), _times(NULL), _dimension(0),_problemName(NULL),_shortName(NULL), _path(NULL),_upper_bound(9999999999.9),_wanted_driver_count(0),_driver_lb(0),_driver_ub(0), _configuration(~0),_class(0)
	{
		_nodes.reserve(4000);		//not so clean....
		_customers.reserve(4000);	
		_drivers.reserve(200);	
	}
	~Prob()
	{
		if(	_distances != NULL && _distances != _times)
		{
			for(int i = 0 ; i < _dimension ; i++)
				delete [] _distances[i];
			delete [] _distances;
		}
		if(	_times != NULL && _distances != _times)
		{
			for(int i = 0 ; i < _dimension ; i++)
				delete [] _times[i];
			delete [] _times;
		}
		_times = NULL;
		_distances = NULL;
	}
	
	void AddCustomer(NodeT * n){ _customers.push_back(n); }
	void AddNode(NodeT & n){ _nodes.push_back(n); }
	
	int GetCustomerCount(){ return (int)_customers.size();}
	int GetNodeCount(){ return (int)_nodes.size();}
	
	NodeT* GetCustomer(int i){ return _customers[i]; }
	NodeT* GetNode(int i){ return &_nodes[i]; }
	
	void AddDriver(DriverT & d){ _drivers.push_back(d);}
	int GetDriverCount(){ return (int)_drivers.size();}
	DriverT* GetDriver(int i){ return &_drivers[i];}
		
	
	void SetMaxtrices(double ** d, double ** t, int dim){ _distances = d; _times = t; _dimension = dim;}
	double ** GetDistances(){ return _distances;}
	double ** GetTimes(){ return _times;}
	int GetDimension(){return _dimension;}
	
	void TruncateMatrices()
	{
		for(int i=0;i<_dimension;i++)
			for(int j=0;j<_dimension;j++)	
			{
				_distances[i][j] = (int)_distances[i][j];
				_times[i][j] = (int)_times[i][j];
			}
	}
	
	static unsigned long long GetCustomerSetKey(std::vector<NodeT*> & nodes)
	{
		unsigned long long l = 1;
		for(size_t k=0;k<nodes.size();k++)
		{
			if(nodes[k]->type == NODE_TYPE_CUSTOMER)
				l *= prime_get_ith(nodes[k]->id);	
		}
		return l;
	}
	
	
	static void GetIdListNoDepot(std::vector<NodeT*> & nodes, std::vector<int> & ids)
	{
		ids.clear();
		for(size_t k=0;k<nodes.size();k++)
			if(nodes[k]->type == NODE_TYPE_CUSTOMER)
				ids.push_back(nodes[k]->id);
	}
	
	NodeT* GetNodeByOriginID(int id)
	{
		for(size_t i=0;i<_nodes.size();i++)
			if(_nodes[i].origin_id == id)
				return &(_nodes[i]);
		return NULL;
	}
	
	char * GetProblemName(){return _problemName;}
	void SetProblemName(char * name){_problemName = name;}
	
	char * GetShortName(){return _shortName;}
	void SetShortName(char * name){_shortName = name;}
	
	char * GetProblemPath(){return _path;}
	void SetProblemPath(char * name){_path = name;}
	
	double GetUpperBound(){return _upper_bound;}
	void SetUpperBound(double ub){_upper_bound = ub;}
	
	int GetWantedDriverCount(){return _wanted_driver_count;}
	void SetWantedDriverCount(int ub){_wanted_driver_count = ub;}
	
	int GetDriverCountLB(){return _driver_lb;}
	void SetDriverCountLB(int lb){_driver_lb = lb;}
	
	int GetDriverCountUB(){return _driver_ub;}
	void SetDriverCountUB(int ub){_driver_ub = ub;}
	
	int GetConfiguration(){return _configuration;}
	void SetConfiguration(int conf){_configuration = conf;}
	
	int GetClass(){return _class;}
	void SetClass(int cl){_class = cl;}
	
	//create a problem using the first driver and the set of nodes
	void CopyImportantDataTo(Prob<NodeT,DriverT> * pr)
	{
		pr->_distances = _distances;
		pr->_times = _times;
		pr->_dimension = _dimension;
		pr->_problemName = _problemName;
		pr->_shortName = _shortName;
		pr->_path = _path;
		pr->_upper_bound = _upper_bound;
		pr->_wanted_driver_count = _wanted_driver_count;
		pr->_driver_lb = _driver_lb;
		pr->_driver_ub = _driver_ub;
		pr->_configuration = _configuration;
		pr->_class = _class;
	} 
	
	
	
	
	private:
	std::vector<NodeT> _nodes;
	std::vector<NodeT*> _customers;
	std::vector<DriverT> _drivers;
	
	double ** _distances;
	double ** _times;
	int _dimension;
	
	char * _problemName;
	char * _shortName;
	char * _path;
	
	double _upper_bound;
	int _wanted_driver_count;	//number of wanted drivers
	int _driver_lb;				//lower bound on the number of required drivers
	int _driver_ub;				//upper bound on the number of required drivers
	int _configuration;
	int _class;
};

#endif















