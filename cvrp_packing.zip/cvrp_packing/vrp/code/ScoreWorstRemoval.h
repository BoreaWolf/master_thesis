/*
 * Copyright Jean-Francois Cote 2012
 * 
 * The code may be used for academic, non-commercial purposes only.
 * 
 * Please contact me at cotejean@iro.umontreal.ca for questions
 *
 * If you have improvements, please contact me!
 *
*/

#ifndef SCOREWORSTREMOVAL_H
#define SCOREWORSTREMOVAL_H

#include "Relatedness.h"
#include "ProblemDefinition.h"
#include "Solution.h"
#include "constants.h"
#include <vector>
#include "../../lib/mathfunc.h"

template <class NodeT, class DriverT>
class ScoreWorstRemoval : public Relatedness<NodeT,DriverT>
{
	public:
		ScoreWorstRemoval(){}
		~ScoreWorstRemoval(){}	
		void Increase(Sol<NodeT,DriverT> & s){}
		void Decrease(Sol<NodeT,DriverT> & s){}
	
		double GetScore(Sol<NodeT,DriverT> & s, NodeT* n)
		{
			double ** m = s.GetDistances();
			NodeT * prev = s.Prev[n->id];
			NodeT * next = s.Next[n->id];
			return 	m[prev->distID][n->distID] + 
					m[n->distID][next->distID] -
					m[prev->distID][next->distID];
		}
	
		double GetRelatedness(NodeT * n1, NodeT * n2)
		{
			return 0;
		}		
};

#endif
