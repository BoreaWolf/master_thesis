/*
 * Copyright Jean-Francois Cote 2012
 * 
 * The code may be used for academic, non-commercial purposes only.
 * 
 * Please contact me at cotejean@iro.umontreal.ca for questions
 *
 * If you have improvements, please contact me!
 *
*/




#ifndef REMOVE_RELATED
#define REMOVE_RELATED

#include "Solution.h"
#include "../../lib/mathfunc.h"
#include "RemoveOperator.h"
#include "Relatedness.h"
#include <vector>
#include <algorithm>

template< class NodeT, class DriverT> 
struct RemoveRelatedSorter
{
	NodeT* selectedNode;
	Relatedness<NodeT,DriverT> * rel;
	bool operator() (NodeT * n1,NodeT * n2)
	{ 
		return ( rel->GetRelatedness(n1,selectedNode) < rel->GetRelatedness(n2,selectedNode)); 
	}
};

template< class NodeT, class DriverT> 
class RemoveRelated : public RemoveOperator<NodeT,DriverT> 
{
	public:
		RemoveRelated(Relatedness<NodeT,DriverT> * rel):relatedness(rel){}
		~RemoveRelated(){}	
	
		void Remove(Sol<NodeT, DriverT> & s, int count)
		{
			//printf("RemoveRelated\n");
			vect.clear();
			removed.clear();
			for(int i = 0 ; i < s.GetCustomerCount() ; i++)
			{
				if( s.GetAssignedTo( s.GetCustomer(i) ) != NULL)
					vect.push_back(s.GetCustomer(i));
				else
					removed.push_back(s.GetCustomer(i));
			}		
			if(vect.size() <= 1) return;
			
			int size = vect.size() - 1;
			int index = mat_func_get_rand_int(0, vect.size());	
			s.RemoveAndUnassign( vect[index] );
			removed.push_back(vect[index]);
			vect[index] = vect[size];
			
			RemoveRelatedSorter<NodeT,DriverT> mysorter;
			mysorter.rel = relatedness;
			
			int cpt = MIN_INT(count-1, (int)vect.size()-2);
			for(int i = 0 ; i < cpt ; i++)
			{
				index = mat_func_get_rand_int(0, removed.size());
				mysorter.selectedNode = removed[index];
				
				sort(vect.begin(), vect.begin()+size, mysorter);
				
				index = mat_func_get_rand_int(0, size);
				s.RemoveAndUnassign( vect[index] );
				removed.push_back(vect[index]);
				vect[index] = vect[size-1];
				size--;
			}
			
		}
	private:
		std::vector<NodeT*> vect;
		std::vector<NodeT*> removed;
		Relatedness<NodeT,DriverT> * relatedness;
		
		
};


#endif
