/*
 * Copyright Jean-Francois Cote 2012
 * 
 * The code may be used for academic, non-commercial purposes only.
 * 
 * Please contact me at cotejean@iro.umontreal.ca for questions
 *
 * If you have improvements, please contact me!
 *
*/


#ifndef REGRET_INSERTION
#define REGRET_INSERTION

#include "Solution.h"
#include "Move.h"
#include "InsRmvMethod.h"
#include "../../lib/mathfunc.h"
#include "InsertOperator.h"


template< class NodeT, class DriverT, class MoveT>
struct RegretMoveSorter
{
	bool operator() (Move<NodeT,DriverT,MoveT> * n1,Move<NodeT,DriverT,MoveT> * n2)
	{ 
		return ( n1->DeltaCost < n2->DeltaCost);
	}
};

template <class NodeT, class DriverT, class MoveT>
class RegretInsertion : public InsertOperator<NodeT, DriverT>
{
		
	public:
	RegretInsertion(Prob<NodeT,DriverT> & pr, InsRmvMethod<NodeT, DriverT, MoveT> & insrmv): 
											move_vect(0),_insrmv(insrmv), _moves(0),_used_k(2),_k_regret(2)
	{
		for(int i = 0 ; i < pr.GetCustomerCount() ; i++)
		{
			std::vector< Move<NodeT,DriverT,MoveT> > vect;
			_moves.push_back(vect);
			Move<NodeT,DriverT,MoveT> m;
			for(int j = 0 ; j < pr.GetDriverCount() ; j++)
				_moves[i].push_back(m);			
		}
	}
	
	void SetK(int k){_k_regret = k;}
	void SetNoise(double noise){ _insrmv.SetNoise(noise);}
	
	void Insert(Sol<NodeT,DriverT> & s)
	{
		_used_k = MIN_INT(s.GetDriverCount(), _k_regret);
		if((int)_moves[0].size() < s.GetDriverCount()) //Add 
		{
			int cpt = s.GetDriverCount() - (int)_moves[0].size();
			Move<NodeT,DriverT,MoveT> m;
			for(int j = 0 ; j < cpt ; j++)
				for(int i = 0 ; i < s.GetCustomerCount() ; i++)
					_moves[i].push_back(m);
		}

		//printf("\n\nRegretInsertion k:%d\n",_k_regret);
		std::vector<NodeT*> toRemove(0);
		std::vector<NodeT*> refused(0);
		s.Update();
		for(int i=0;i<s.GetUnassignedCount();i++)
			for(int j = 0 ; j < s.GetDriverCount() ; j++)
			{
				NodeT * n = s.GetUnassigned(i);
				DriverT * d = s.GetDriver(j);
				_insrmv.InsertCost(s, n, d, _moves[n->id][d->id]);
			}
		
		
		while(s.GetUnassignedCount() > 0)
		{
			//printf("\nIteration:%d\n",s.GetUnassignedCount());
			Move<NodeT, DriverT, MoveT> best;
			best.IsFeasible = false;
			double maxRegret = -INFINITE;
			
			for(int i=0;i<s.GetUnassignedCount();i++)
			{
				Move<NodeT, DriverT, MoveT> m;
				double regret = GetRegretCost(s, s.GetUnassigned(i), m);
				//printf("regret:%.lf maxRegret:%.lf feas:%d dmd:%d\tn:%d\n", 
				//		regret, maxRegret, (int)m.IsFeasible,m.n->demand, m.n->id);
				
				if(m.IsFeasible && (regret > maxRegret || (regret == maxRegret && m.DeltaCost < best.DeltaCost)))
				{
					maxRegret = regret;
					best = m;
				}
				else if (!m.IsFeasible)
					toRemove.push_back( s.GetUnassigned(i) );
			}

			
			if(best.IsFeasible)
			{
				//printf("Accepted Node:%d Regret:%lf\n", best.n->id, maxRegret);
				best.from = NULL;
				_insrmv.ApplyInsertMove(s,best);
				s.Update(best.to);
			}
			//else
			//	printf("No feasible move found\n");

			for(size_t i = 0 ; i < toRemove.size() ; i++)
			{
				refused.push_back(toRemove[i]);
				s.RemoveFromUnassigneds(toRemove[i]);
			}
			toRemove.clear();

			for(int i=0;i<s.GetUnassignedCount();i++)
			{
				NodeT * n = s.GetUnassigned(i);
				if(_moves[n->id][best.to->id].IsFeasible)
					_insrmv.InsertCost(s, n, best.to, _moves[n->id][best.to->id]);
			}
			
			/*for(int i=0;i<s.GetUnassignedCount();i++)
				for(int j = 0 ; j < s.GetDriverCount() ; j++)
				{
					NodeT * n = s.GetUnassigned(i);
					DriverT * d = s.GetDriver(j);
					_insrmv.InsertCost(s, n, d, _moves[n->id][d->id]);
				}*/
			
			//s.Show();
		}//end while
		
		for(size_t i = 0 ; i < refused.size() ; i++)
			s.AddToUnassigneds( refused[i] );
	}	
	
	
	double GetRegretCost(Sol<NodeT,DriverT> & s, NodeT * n, Move<NodeT,DriverT,MoveT> & m)
	{
		int nbfeasible = 0;
		move_vect.clear();
		for(int j = 0 ; j < s.GetDriverCount() ; j++)
		{
			move_vect.push_back(&_moves[n->id][ s.GetDriver(j)->id ]);
			if(_moves[n->id][ s.GetDriver(j)->id ].IsFeasible)
				nbfeasible++;
		}
		//printf("Node:%d nbfeasible:%d ", n->id,nbfeasible);
		partial_sort(move_vect.begin(), move_vect.begin()+_used_k,  move_vect.end(), move_sorter);

		double cost = 0;
		m = *move_vect[0];
		for(int j = 1 ; j < _used_k ; j++)
			cost += move_vect[j]->DeltaCost - move_vect[0]->DeltaCost;
		return cost;
	}
	
	private:
		std::vector< Move<NodeT,DriverT,MoveT>* > move_vect;
		InsRmvMethod<NodeT, DriverT, MoveT> & _insrmv;	
		std::vector< std::vector< Move<NodeT, DriverT, MoveT> > > _moves; //[nodes][driver]
		
		int _used_k;
		int _k_regret;
		RegretMoveSorter<NodeT,DriverT,MoveT> move_sorter;
};


#endif




