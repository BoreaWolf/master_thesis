/*
 * Copyright Jean-Francois Cote 2012
 * 
 * The code may be used for academic, non-commercial purposes only.
 * 
 * Please contact me at cotejean@iro.umontreal.ca for questions
 *
 * If you have improvements, please contact me!
 *
*/


#ifndef REMOVE_CLUSTER
#define REMOVE_CLUSTER

#include "Solution.h"
#include "../../lib/mathfunc.h"
#include "RemoveOperator.h"
#include "Relatedness.h"
#include "constants.h"
#include <vector>
#include <algorithm>


struct cluster_arc_t
{
	int i;
	int j;	
	double distance;
};

struct cluster_node_t
{
	int i;
	int nodeid;
	int parent;
	int rank;
};

struct RemoveClusterSorter
{
	bool operator() (cluster_arc_t * a1,cluster_arc_t * a2)
	{ 
		return ( a1->distance < a2->distance); 
	}
};

template< class NodeT, class DriverT> 
class RemoveCluster : public RemoveOperator<NodeT,DriverT> 
{
	public:
		RemoveCluster(Prob<NodeT,DriverT> & pr)
		{
			int nb = pr.GetNodeCount() * pr.GetNodeCount();
			for(int i=0;i < nb ; i++)
				arcs.push_back(new cluster_arc_t());
			
			cluster_node_t node;
			for(int i=0;i<pr.GetNodeCount();i++)
				nodes.push_back(node);
		}
		~RemoveCluster()
		{
			for(size_t i=0;i < arcs.size() ; i++)
				delete arcs[i];
			arcs.clear();
		}	
	
		void Remove(Sol<NodeT, DriverT> & s, int count)
		{
			removed.clear();
			
			int toRemove = MIN_INT(s.GetCustomerCount() - s.GetUnassignedCount(), count);
			if(toRemove <= 1) return;
			
			int _last_used_driver = -1;
			int protect = 0;
			while(removed.size() <= (size_t)toRemove && protect++ < 20)
			{				
				if(_last_used_driver == -1 || removed.size() == 0)
				{
					DriverT * d = s.GetDriver( mat_func_get_rand_int(0, s.GetDriverCount()));		
					_last_used_driver = d->id;
					RunKruskal(s, d);
				}
				else
				{
					//find the route with the closest node different than _last_used_driver
					NodeT * n1 = removed[ mat_func_get_rand_int(0, (int)removed.size()) ];
					double mindist = INF;
					DriverT * d = NULL;
					for(int i = 0 ; i < s.GetCustomerCount() ; i++)
					{
						NodeT * n2 = s.GetCustomer(i);
						if(s.AssignTo[n2->id] != NULL && s.AssignTo[n2->id]->id != _last_used_driver)
							if(s.GetDistances()[n1->distID][n2->distID] < mindist)
							{
								d = s.AssignTo[n2->id];
								mindist = s.GetDistances()[n1->id][n2->id];
							}
					}
					if(d == NULL) return;
					_last_used_driver = d->id;
					RunKruskal(s, d);
				}
			}
		}
		
		void RunKruskal(Sol<NodeT, DriverT> & s, DriverT * d)
		{
			int nbnodes = 0;
			NodeT * n = s.GetNode(d->StartNodeID);
			while(n != NULL)
			{
				if( (n->type & NODE_TYPE_CUSTOMER) == NODE_TYPE_CUSTOMER)
				{
					nodes[nbnodes].i = nbnodes;
					nodes[nbnodes].nodeid = n->id;
					nodes[nbnodes].parent = nbnodes;
					nodes[nbnodes].rank = 0;
					nbnodes++;
				}
				n = s.Next[n->id];	
			}	
			
			if(nbnodes <= 1) return;
			
			int k = 0;
			for(int i = 0 ; i < nbnodes ; i++)
				for(int j = i+1 ; j < nbnodes ; j++)
				{
					arcs[k]->i = i;
					arcs[k]->j = j;
					NodeT * n1 = s.GetNode(nodes[i].nodeid);
					NodeT * n2 = s.GetNode(nodes[j].nodeid);
					arcs[k]->distance = s.GetDistances()[n1->distID][n2->distID];
					k++;
				}
			
			RemoveClusterSorter mysorter;
			sort(arcs.begin(), arcs.begin()+k, mysorter);
			
			int nbclusters = nbnodes;
			for(int i = 0 ; i < k ; i++)
				if(GetParent(arcs[i]->i) != GetParent(arcs[i]->j))
				{
					Fusion(arcs[i]->i, arcs[i]->j);
					nbclusters--;
					
					if(nbclusters == 2) //remove all the nodes from one of the two clusters left
					{
						int p1 = nodes[	arcs[i]->i ].parent;
						int p2 = -1;
						for(int j = 0 ; j < nbnodes ; j++)
						{
							int p3 = GetParent(nodes[j].i);
							if(p3 != p1)
							{
								p2 = p3;
								break;	
							}
						}
						int p = mat_func_get_rand_int(0,2) == 0?p1:p2;
						for(int j = 0 ; j < nbnodes ; j++)
							if(GetParent(nodes[j].i) != p)
							{
								s.RemoveAndUnassign( s.GetNode(nodes[j].nodeid) );
								removed.push_back( s.GetNode(nodes[j].nodeid) );
							}
					}
				}
		}
		
		int GetParent(int i)
		{
			if(nodes[i].parent != nodes[i].i)
				nodes[i].parent = GetParent(nodes[i].parent);
			return nodes[i].parent;
		}
		
		void Fusion(int i, int j)
		{
			int pi = GetParent(i);
			int pj = GetParent(j);
			
			if(nodes[pi].rank > nodes[pj].rank)
				nodes[pj].parent = pi;
			else if(nodes[pi].rank < nodes[pj].rank)
				nodes[pi].parent = pj;
			else
			{
				nodes[pj].parent = pi;
				nodes[pi].rank++;
			}
		}
		
	private:
		std::vector<NodeT*> removed;
		std::vector<cluster_arc_t*> arcs;
		std::vector<cluster_node_t> nodes;
};


#endif
