/*
 * Copyright Jean-Francois Cote 2012
 * 
 * The code may be used for academic, non-commercial purposes only.
 * 
 * Please contact me at cotejean@iro.umontreal.ca for questions
 *
 * If you have improvements, please contact me!
 *
*/

#ifndef COST_FUNCTION
#define COST_FUNCTION


template <class NodeT, class DriverT> class Sol;


template <class NodeT, class DriverT>
class CostFunction
{
	public:
		CostFunction(){}
		~CostFunction(){}	
		
		//Calculate the cost of a solution without modifying the nodes and drivers
		virtual double GetCost(Sol<NodeT,DriverT> & s) = 0;
		virtual double GetCost(Sol<NodeT,DriverT> & s, DriverT * d) = 0;
		
		//Calculate the cost of a solution AND possibly updates the nodes and drivers fields
		virtual void Update(Sol<NodeT,DriverT> & s) = 0;
		virtual void Update(Sol<NodeT,DriverT> & s, DriverT * d) = 0;
		
		
		virtual void Show(Sol<NodeT,DriverT> * s, DriverT * d){}
};


#endif 

