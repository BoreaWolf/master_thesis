/*
 * Copyright Jean-Francois Cote 2012
 * 
 * The code may be used for academic, non-commercial purposes only.
 * 
 * Please contact me at cotejean@iro.umontreal.ca for questions
 *
 * If you have improvements, please contact me!
 *
*/

#ifndef RELATEDNESSHISTORICALCOSTPAIR_H
#define RELATEDNESSHISTORICALCOSTPAIR_H

#include "Relatedness.h"
#include "ProblemDefinition.h"
#include "Solution.h"
#include "constants.h"
#include <vector>
#include "../../lib/mathfunc.h"

template <class NodeT, class DriverT>
class RelatednessHistoricalCostPair : public Relatedness<NodeT,DriverT>
{
	public:
		RelatednessHistoricalCostPair(Prob<NodeT,DriverT> & pr) : _historic(0)
		{	
			for(int i=0;i < pr.GetNodeCount() ; i++)
			{
				std::vector<double> v(0);
				_historic.push_back(v);
				for(int j=0;j < pr.GetNodeCount() ; j++)
					_historic[i].push_back(INF);
			}
		}
		
		~RelatednessHistoricalCostPair(){}	
		
		void Increase(Sol<NodeT,DriverT> & s)
		{
			Update(s);
		}
		
		void Decrease(Sol<NodeT,DriverT> & s)
		{
		}
	
		double GetScore(Sol<NodeT,DriverT> & s, NodeT* n)
		{
			NodeT * prev = s.Prev[n->id];
			NodeT * next = s.Next[n->id];
			return - _historic[prev->id][n->id] 
				   - _historic[n->id][next->id];
		}
	
		double GetRelatedness(NodeT * n1, NodeT * n2)
		{
			return 0;
		}
		
	private:
	
		void Update(Sol<NodeT,DriverT> & s)
		{
			double cost = s.GetLastCalculatedCost();
			for(int i=0;i<s.GetDriverCount();i++)
			{
				DriverT * d = s.GetDriver(i);	
				NodeT * n2 = s.GetNode(d->StartNodeID);
				NodeT * n1 = s.Next[n2->id];
				while(n1 != NULL)
				{
					_historic[n2->id][n1->id] = MIN_DBL(_historic[n2->id][n1->id], cost);
					n2 = n1;	
					n1 = s.Next[n1->id];
				}
			}
		}
	
		std::vector< std::vector<double> > _historic;
		
};

#endif
