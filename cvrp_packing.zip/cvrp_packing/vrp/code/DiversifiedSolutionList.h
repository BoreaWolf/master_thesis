/*
 * Copyright Jean-Francois Cote 2012
 * 
 * The code may be used for academic, non-commercial purposes only.
 * 
 * Please contact me at cotejean@iro.umontreal.ca for questions
 *
 * If you have improvements, please contact me!
 *
*/
#ifndef DIVERSIFIEDSOLUTIONLIST_H
#define DIVERSIFIEDSOLUTIONLIST_H

#include <stdio.h>
#include "Solution.h"
#include "Relatedness.h"
#include "ISolutionList.h"
#include <vector>
#include <algorithm>
#include <iostream>
#include "../../lib/SetHashTable.h"

#define DiversifiedSolutionListF1 0.9
#define DiversifiedSolutionListF2 0.1

template <class NodeT, class DriverT>
class DiversifiedSolutionNode
{
	public:
		DiversifiedSolutionNode():sol(NULL),distance(0),compare(0),value(0){}
		DiversifiedSolutionNode(Sol<NodeT,DriverT>* s, double d, double c):sol(s),distance(d),compare(c),value(0)
		{
			CalculateValue();	
		}
		void CalculateValue()
		{
			value = distance*DiversifiedSolutionListF1 + compare*DiversifiedSolutionListF2;
		}
		Sol<NodeT,DriverT>* sol;
		double distance;
		double compare;
		double value;
};

template <class NodeT, class DriverT>
struct DiversifiedSolutionComparer
{
    bool operator() (const DiversifiedSolutionNode<NodeT,DriverT>* a, const DiversifiedSolutionNode<NodeT,DriverT>* b) const 
    {
    	if(a->value != b->value)
        	return a->value < b->value;
        else if(a->distance != b->distance)
        	return a->distance > b->distance;
        else
        	return a->compare < b->compare;
    }
};

struct DiversifiedSolutionContainer
{
	double cost;
	int nb;
	DiversifiedSolutionContainer():cost(0.0),nb(0){}
	DiversifiedSolutionContainer(double c, int n):cost(c),nb(n){}
};



template <class NodeT, class DriverT>
class DiversifiedSolutionList : public ISolutionList<NodeT,DriverT>
{
	public:
		DiversifiedSolutionList(size_t max_count): _nb_items(0), _list(max_count),_map_routes(2000000),_worst_sol_index(0){}
		~DiversifiedSolutionList()
		{
			for(size_t i=0;i<_nb_items;i++)
			{
				delete _list[i]->sol;
				delete _list[i];
			}
			_list.clear();
		}
		
		int GetSolutionCount(){return (int)_list.size();}
		Sol<NodeT,DriverT>* GetSolution(int i){ return _list[i]->sol;}
		
		void GetSolutions(std::vector< Sol<NodeT,DriverT>* > & v)
		{
			v.clear();
			for(int i=0;i<_nb_items;i++)
				v.push_back(_list[i]->sol);
		}
		
		
	
		void Add(Sol<NodeT,DriverT> & s)
		{
			double distance = s.GetCost();
			//double distance = s.GetTotalDistances();
			int compare = GetCompareValue(&s);
			int nbused = s.GetUsedDriverCount();
			if(compare == 0) return;
			
			double value = DiversifiedSolutionListF1*distance + compare*DiversifiedSolutionListF2;
			if(_nb_items == 0)
			{
				Sol<NodeT,DriverT> * newsol = new Sol<NodeT,DriverT>(s);
				_list[0] = new DiversifiedSolutionNode<NodeT,DriverT>(newsol,distance,compare);
				_worst_sol_index = 0;
				_nb_items = 1;
				AddToMap(newsol);
			}
			else if(_nb_items == (int)_list.size() && _list[ _worst_sol_index ]->value < value)
				return;
			else
			{
				//first check if another solution with exactly the same distance exists, if yes, return
				for(size_t i=0;i<_nb_items;i++)
					if(_list[i]->distance - distance < 0.0001 && distance - _list[i]->distance < 0.0001) 
						return;
				
				
				Sol<NodeT,DriverT> * newsol = new Sol<NodeT,DriverT>(s);
				AddToMap(newsol);
				if(_nb_items < _list.size())
					_list[ _nb_items++ ] = new DiversifiedSolutionNode<NodeT,DriverT>(newsol,distance,compare);
				else	
				{
					DiversifiedSolutionNode<NodeT,DriverT>* stemp = _list[ _worst_sol_index ];
					_list[ _worst_sol_index ] = new DiversifiedSolutionNode<NodeT,DriverT>(newsol,distance,compare);
					RemoveAndDelete(stemp);
				}
				
				EvaluateAll();
			}
		}
	
		void Show()
		{
			DiversifiedSolutionComparer<NodeT,DriverT> comp;
			sort(_list.begin(),_list.begin()+_nb_items,comp);
			
			printf("List of best solutions count:%d\n",(int)_list.size() );
			for(size_t i=0;i<_nb_items;i++)
			{
				printf("i:%d dist:%.10lf comp:%.2lf v:%.2lf\n", (int)i ,_list[i]->distance,_list[i]->compare,_list[i]->value);
				
				for(int j=0;j<_list[i]->sol->GetDriverCount();j++)
					if(_list[i]->sol->RoutesLength[j] >= 1)
					{
						std::vector<int> nodes;	
						_list[i]->sol->GetIdRouteNoDepot(j, nodes);
						DiversifiedSolutionContainer * dsc = NULL;
						bool r = _map_routes.GetData(nodes, &dsc);
						
						if(r) printf("Route cost:%lf ", dsc->cost);
						_list[i]->sol->Show(_list[i]->sol->GetDriver(j));
					}
				
				
			}
			EvaluateAll();
		}
	
	
		void Resize(int size)
		{
			if(size < _list.size())
			{
				printf("Cannot resize this list to a smaller size. Current size:%d new size:%d\n",(int)_list.size(),size);
				exit(1);
			}
			_list.resize(size);
		}
	
		int GetSize()
		{
			return (int)_list.size();
		}
		
	private:
		int GetCompareValue(Sol<NodeT,DriverT> * s)
		{
			int v2 = 0;
			double cost = s->GetLastCalculatedCost();
			std::vector<int> nodes;
			for(int i=0;i<s->GetDriverCount();i++)
				if(s->RoutesLength[i] >= 1)
				{
					s->GetIdRouteNoDepot(i, nodes);
					DiversifiedSolutionContainer * dsc = NULL;
					bool r = _map_routes.GetData(nodes, &dsc);
					if(r == false || dsc->cost + 0.001 >= cost)
 						v2++;
				}
			return v2;
		}
		
		void AddToMap(Sol<NodeT,DriverT> * s)
		{
			double cost = s->GetLastCalculatedCost();
			std::vector<int> nodes;
			for(int i=0;i<s->GetDriverCount();i++)
				if(s->RoutesLength[i] >= 1)
				{
					s->GetIdRouteNoDepot(i, nodes);
					DiversifiedSolutionContainer * dsc = NULL;
					bool r = _map_routes.GetData(nodes, &dsc);
					if(r == false)
						_map_routes.Assign(nodes, DiversifiedSolutionContainer(cost,1));
					else
					{
						dsc->nb++;
						dsc->cost = std::min(dsc->cost, cost);
					}
				}	
		}
		
		void RemoveAndDelete(DiversifiedSolutionNode<NodeT,DriverT>* s)
		{
			std::vector<int> nodes;
			for(int i=0;i<s->sol->GetDriverCount();i++)
				if(s->sol->RoutesLength[i] >= 1)
				{
					s->sol->GetIdRouteNoDepot(i, nodes);
					
					DiversifiedSolutionContainer * dsc = NULL;
					bool r = _map_routes.GetData(nodes, &dsc);
					if(r && s->distance - 0.0001 <= dsc->cost)
					{
						dsc->nb--;
						if(dsc->nb == 0) _map_routes.Remove(nodes);
					}
				}
				
			delete s->sol;
			delete s;
		}
		
		void EvaluateAll()
		{
			for(int i= (int)_nb_items-1;i>=0;i--)
			{
				_list[i]->compare = GetCompareValue(_list[i]->sol);
				_list[i]->CalculateValue();
				if(_list[i]->compare == 0)
				{
					RemoveAndDelete(_list[i]);
					_list[i] = _list[_nb_items-1];
					_list[_nb_items-1] = NULL;
					_nb_items--;
				}
			}
			
			double worst_value = 0;
			_worst_sol_index = -1;
			for(size_t i=0;i<_nb_items;i++)
				if(worst_value < _list[i]->value)
					{
						worst_value = _list[i]->value;
						_worst_sol_index = i;
					}
		}
		
		size_t _nb_items;
		std::vector< DiversifiedSolutionNode<NodeT,DriverT>* > _list;
		SetHashTable< DiversifiedSolutionContainer > _map_routes;
		int _worst_sol_index;
	
};

#endif

