/*
 * Copyright Jean-Francois Cote 2014
 * 
 * The code may be used for academic, non-commercial purposes only.
 * 
 * Please contact me at cotejean@iro.umontreal.ca for questions
 *
 * If you have improvements, please contact me!
 *
 *
 *
 *
 * Class that builds a lower and an upper bound
 *
*/

#ifndef ILOWERUPPERBOUND
#define ILOWERUPPERBOUND

#include "constants.h"
#include "ProblemDefinition.h"
#include <vector>
#include <map>

template <class NodeT, class DriverT>
class ILowerUpperBound
{
	public : 
		ILowerUpperBound(){}
		virtual ~ILowerUpperBound(){}	
		
		virtual void LowerBound(Prob<NodeT,DriverT> & p) = 0;
		virtual void UpperBound(Prob<NodeT,DriverT> & p) = 0;
};

#endif
