/*
 * Copyright Jean-Francois Cote 2012
 * 
 * The code may be used for academic, non-commercial purposes only.
 * 
 * Please contact me at cotejean@iro.umontreal.ca for questions
 *
 * If you have improvements, please contact me!
 *
*/

#ifndef ERASE_DRIVER_H
#define ERASE_DRIVER_H

#include "ProblemDefinition.h"
#include "Solution.h"

template <class NodeT, class DriverT>
class EraseDriver
{
	public:	
	
	void Erase(Sol<NodeT,DriverT> & sol)
	{
		//for each driver, check if the route contains a customer
		//if not, delete the driver
		std::vector<int> toDelete;
		
		for(int i=0;i< sol.GetDriverCount() ;i++)
		{
			DriverT * d = sol.GetDriver(i);
			NodeT * cur = sol.GetNode(d->StartNodeID);
			
			while(cur != NULL)
			{
				if(cur->type == NODE_TYPE_CUSTOMER)
					break;				
				cur = sol.Next[ cur->id ];	
			}
			
			if(cur == NULL)
				toDelete.push_back(i);
		}
		
		
	}
	
};


#endif
