/*
 * Copyright Jean-Francois Cote 2012
 * 
 * The code may be used for academic, non-commercial purposes only.
 * 
 * Please contact me at cotejean@iro.umontreal.ca for questions
 *
 * If you have improvements, please contact me!
 *
*/
#ifndef _OPT2_H
#define _OPT2_H

#include "Solution.h"
#include "../../lib/mathfunc.h"

template <class NodeT, class DriverT>
class Opt2
{

	public:
	void Optimize(Sol<NodeT,DriverT> & s)
	{
		for(int i=0;i<s.GetDriverCount();i++)
			Optimize(s,s.GetDriver(i));	
	}
	
	
	void Optimize(Sol<NodeT,DriverT> & s,DriverT * d)
	{
		//printf("2Opt Optimize Driver : %d\n", d->id);
		//s.Show(d);
		
		double ** m = s.GetDistances();
		bool flag = true;
		while(flag)
		{
			flag = false;	
			
			NodeT * prev1 = s.GetNode(d->StartNodeID);
			NodeT * cur1 = s.Next[ prev1->id ];
			NodeT * end =  s.GetNode(d->EndNodeID);
			
			while(cur1 != end)
			{
				NodeT * cur2 = s.Next[ cur1->id ];
				while(cur2 != end)
				{
					NodeT * next2 = s.Next[ cur2->id ];
					
					double di =	m[prev1->distID][cur2->distID] +
							   	m[cur1->distID][next2->distID] -
								m[prev1->distID][cur1->distID] -
							   	m[cur2->distID][next2->distID];
					
					//printf("Check for %d %d cost:%lf\n", cur1->no, cur2->no, di);
					
					if(di < -EPSILON)
					{
						
						s.RevertPath(cur1,cur2);
						//printf("Found new path for %d %d cost:%lf\n",cur1->no, cur2->no, di);
						//s.Show(d);
						flag = true;
						cur2 = end;
						cur1 =  s.Prev[ end->id ];
						break;
					}
					cur2 = next2;
				}//end while cur2
				
				prev1 = cur1;
				cur1 = s.Next[ cur1->id ];
			}//end while cur2
		}//end while flag
	}
};


#endif
