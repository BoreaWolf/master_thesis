/*
 * Copyright Jean-Francois Cote 2012
 * 
 * The code may be used for academic, non-commercial purposes only.
 * 
 * Please contact me at cotejean@iro.umontreal.ca for questions
 *
 * If you have improvements, please contact me!
 *
*/

#ifndef RELATEDNESSHISTORICALREQUESTPAIR_H
#define RELATEDNESSHISTORICALREQUESTPAIR_H

#include "Relatedness.h"
#include "ProblemDefinition.h"
#include "Solution.h"
#include "constants.h"
#include <vector>

template <class NodeT, class DriverT>
class RelatednessHistoricalRequestPair : public Relatedness<NodeT,DriverT>
{
	public:
		RelatednessHistoricalRequestPair(Prob<NodeT,DriverT> & pr) : _historic(0)
		{
			std::vector<int> v(0);
			for(int i=0;i < pr.GetCustomerCount() ; i++)
				v.push_back(0);
			
			for(int i=0;i < pr.GetCustomerCount() ; i++)
			{
				_historic.push_back(v);
				for(int j=0;j < pr.GetCustomerCount() ; j++)
					_historic[i].push_back(0);
			}
		}
		
		~RelatednessHistoricalRequestPair(){}	
		
		void Increase(Sol<NodeT,DriverT> & s)
		{
			Update(s, 1);
		}
		
		void Decrease(Sol<NodeT,DriverT> & s)
		{
			Update(s, -1);
		}
		
		double GetScore(Sol<NodeT,DriverT> & s, NodeT* n1)
		{
			return 0;
		}
		
		double GetRelatedness(NodeT * n1, NodeT * n2)
		{
			return _historic[n1->id][n2->id];
		}
		
	private:
	
		void Update(Sol<NodeT,DriverT> & s, int value)
		{
			
			for(int i=0;i<s.GetCustomerCount();i++)
				for(int j=0;j < s.GetCustomerCount() ; j++)
				{
					NodeT * n1 = s.GetCustomer(i);
					NodeT * n2 = s.GetCustomer(j);
					if(s.AssignTo[n1->id] == s.AssignTo[n2->id])
						_historic[n1->id][n2->id] += value;
				}
			/*
			for(int i=0;i<s.GetDriverCount();i++)
			{
				DriverT * d = s.GetDriver(i);	
				
				NodeT * n1 = s.GetNode(d->StartNodeID);
				NodeT * n2 = NULL;
				while(n1 != NULL)
				{
					if((n1->type & NODE_TYPE_CUSTOMER) == NODE_TYPE_CUSTOMER)
					{
						if(n2 != NULL)
							_historic[n1->id][n2->id] -= value;
						n2 = n1;	
					}
					n1 = s.Next[n1->id];
				}
			}*/
		}
	
		std::vector< std::vector<int> > _historic;
		
};

#endif
