	/*
 * Copyright Jean-Francois Cote 2014
 * 
 * The code may be used for academic, non-commercial purposes only.
 * 
 * Please contact me at cotejean@iro.umontreal.ca for questions
 *
 * If you have improvements, please contact me!
 *
*/
#ifndef _RELOCATE_H
#define _RELOCATE_H

#include "Solution.h"
#include "IAlgorithm.h"
#include "InsRmvMethod.h"
#include "../../lib/mathfunc.h"



template <class NodeT, class DriverT, class MoveT>
class Relocate : IAlgorithm<NodeT,DriverT>
{

public:
	Relocate(InsRmvMethod<NodeT,DriverT,MoveT> * insrmv):_insrmv(insrmv){}
	
	
	void Optimize(Sol<NodeT,DriverT> & s)
	{
		printf("Relocate Optimize\n");
		printf("SolCost:%.3lf\n", s.GetCost());
		bool found = true;
		while(found)
		{
			found = false;	
			
			nodes.clear();
			for(int i = 0 ; i < s.GetCustomerCount() ; i++)
				nodes.push_back( s.GetCustomer(i) );
			
			//std::shuffle (vect.begin(), vect.end(), std::default_random_engine());
			
			for(size_t i=0;i<nodes.size();i++)
			{
				Move<NodeT,DriverT,MoveT> rmv;
				_insrmv->RemoveCost(s, nodes[i],rmv);
				
				Move<NodeT,DriverT,MoveT> best;
				for(int j=0;j<s.GetDriverCount();j++)
				{
					DriverT * d = s.GetDriver(j);
					if(d == s.GetAssignedTo( nodes[i] )) continue;
					
					Move<NodeT,DriverT,MoveT> tmp;
					_insrmv->InsertCost(s,nodes[i],d,tmp);
					if(tmp.DeltaCost + 0.0001 < best.DeltaCost)
						best = tmp;
				}
				
				if(rmv.DeltaCost + best.DeltaCost < -0.0001)
				{
					if(rmv.from != NULL)
						s.Remove(nodes[i]);	
					_insrmv->ApplyInsertMove(s, best);
					found = true;
					printf("n:%d rmv:%.2lf best:%.2lf from:%d to:%d SolCost:%.3lf\n",nodes[i]->no,rmv.DeltaCost, best.DeltaCost,
																rmv.from->id,best.to->id,s.GetCost());
					//s.Show();					
				}
			} 
			
		}
		
		printf("Final Cost:%.3lf\n", s.GetCost());
		
		
		
	}
	
	
	
	
private:
	InsRmvMethod<NodeT,DriverT,MoveT> * _insrmv;
	std::vector<NodeT*> nodes;
};


#endif
