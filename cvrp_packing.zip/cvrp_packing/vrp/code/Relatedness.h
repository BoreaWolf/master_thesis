/*
 * Copyright Jean-Francois Cote 2012
 * 
 * The code may be used for academic, non-commercial purposes only.
 * 
 * Please contact me at cotejean@iro.umontreal.ca for questions
 *
 * If you have improvements, please contact me!
 *
*/

#ifndef RELATEDNESS_H
#define RELATEDNESS_H

#include "Solution.h"

template<class NodeT, class DriverT>
class Relatedness
{
	public:
		Relatedness(){}
		virtual ~Relatedness(){}
		virtual double GetRelatedness(NodeT* n1, NodeT* n2) = 0;
		virtual double GetScore(Sol<NodeT,DriverT> & s, NodeT* n1) = 0;
		
		//for those with memory
		virtual void Increase(Sol<NodeT,DriverT> & s) = 0;
		virtual void Decrease(Sol<NodeT,DriverT> & s) = 0; 
};

#endif
