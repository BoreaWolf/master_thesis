/*
 * Copyright Jean-Francois Cote 2012
 * 
 * The code may be used for academic, non-commercial purposes only.
 * 
 * Please contact me at cotejean@iro.umontreal.ca for questions
 *
 * If you have improvements, please contact me!
 *
 *
 * This code is a variant of FeasibleSeqRouteList
 *
 * 
 * Produce a list of unique routes where the order of customers manners.
 *
*/

#ifndef FEASIBLESEQROUTELIST
#define FEASIBLESEQROUTELIST


#include "../../lib/primes.h"
#include "Solution.h"
#include <map>
#include <vector>
#include <string>
#include <sstream>      // std::ostringstream

template <class NodeT, class DriverT>
struct route_seq_elem_t
{
	Sol<NodeT, DriverT> * sol;
	DriverT * drv;
	double route_cost;
	int packing_status;
};

template <class NodeT, class DriverT>
class FeasibleSeqRouteList
{
	public:
		FeasibleSeqRouteList(){}
		~FeasibleSeqRouteList(){}
	
		void Add(Sol<NodeT, DriverT> * s,DriverT * d)
		{
			if(s->RoutesLength[d->id] == 0) return;
			
			std::string key;
			GetUniqueID(s,d,key);
			
			map_iter it;
			it = mapped_routes.find(key);
			if(it == mapped_routes.end())
			{
				route_seq_elem_t<NodeT,DriverT> r;
				r.sol = s;
				r.drv = d;
				r.route_cost = s->GetCost(d);
				r.packing_status = 0;
				mapped_routes.insert( std::make_pair (key, r) );
				feasible_routes.push_back(r);
			}
		}
	
		void GetUniqueID(Sol<NodeT, DriverT> * s,DriverT * d,std::string & key)
		{
			std::ostringstream oss;
			NodeT * n = s->GetNode(d->StartNodeID);
			while(n != NULL)
			{
				if(n->type == NODE_TYPE_CUSTOMER)
					oss << n->no << "-";
				n = s->Next[n->id];
			}
			key = oss.str();
		}
	
		void ShowAllUniqueRoutes()
		{
			printf("All unique routes :%d\n", (int)feasible_routes.size());
			for(size_t i = 0 ; i < feasible_routes.size() ; i++)
				feasible_routes[i].sol->Show(feasible_routes[i].drv);
		}
	
	int GetUniqueRouteCount(){return (int)feasible_routes.size();}
	void GetUniqueRoute(int i, Sol<NodeT, DriverT> ** s,DriverT ** d)
	{
		*s = feasible_routes[i].sol;
		*d = feasible_routes[i].drv;
	}
	
	private:
		std::vector< route_seq_elem_t<NodeT,DriverT> > feasible_routes;
		std::map<std::string, route_seq_elem_t<NodeT,DriverT> > mapped_routes;
		typedef typename std::map<std::string, route_seq_elem_t<NodeT,DriverT> >::iterator map_iter;
};




#endif
