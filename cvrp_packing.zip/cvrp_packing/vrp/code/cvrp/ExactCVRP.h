
#ifndef EXACT_CVRP_H
#define EXACT_CVRP_H

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <cstring>
#include <ilcplex/ilocplex.h>
#include <algorithm>
#include <vector>
#include "NodeCVRP.h"
#include "DriverCVRP.h"
#include "../ProblemDefinition.h"
#include "../Solution.h"
#include "ExactCvrpGraph.h"
#include "ExactCvrpSep.h"
#include "ExactCvrpCallBacks.h"


class ExactCVRP
{
	public:
		ExactCVRP(){}
		~ExactCVRP(){}
	
	
		void Solve(Prob<Node,Driver> * prob, Sol<Node,Driver> & s);
	
	private:
		void Init(Sol<Node,Driver> & s);
		void TestSolution(Sol<Node,Driver> & s);
		void SolveProblem(Sol<Node,Driver> & s);
		void Clear();
		
		Prob<Node,Driver> * prob;
		ExactCvrpGraph * graph;
		
		IloEnv env;
		IloModel model;
		IloObjective obj_func;
		IloCplex cplex;
		IloNumVarArray x;
		ExactCvrpSep * _sep;
		ExactCvrpLazyCallBack * lazy_call;
		ExactCvrpUserCutCallBack * usercut_call;
};




#endif
