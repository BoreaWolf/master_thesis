

#ifndef EXACT_CVRP_LAZY_CALL_BACK_H
#define EXACT_CVRP_LAZY_CALL_BACK_H

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <cstring>
#include <ilcplex/ilocplex.h>
#include <algorithm>
#include <vector>

#include "ExactCvrpGraph.h"
#include "ExactCvrpSep.h"


class ExactCvrpLazyCallBack : public IloCplex::LazyConstraintCallbackI
{
	public:
		ExactCvrpLazyCallBack(IloEnv env, ExactCvrpGraph * graph, IloNumVarArray x, ExactCvrpSep * sep);
		~ExactCvrpLazyCallBack();

		IloCplex::CallbackI *duplicateCallback() const 
		{
        	return new (getEnv()) ExactCvrpLazyCallBack(*this);
        }

        void main();
        
    private:
    	ExactCvrpGraph * _graph;
    	IloNumVarArray _x;
    	ExactCvrpSep * _sep;
    public:
    	IloConstraintArray added_constraints;
};

class ExactCvrpUserCutCallBack : public IloCplex::UserCutCallbackI
{
	public:
		ExactCvrpUserCutCallBack(IloEnv env, ExactCvrpGraph * graph, IloNumVarArray x, ExactCvrpSep * sep);
		~ExactCvrpUserCutCallBack();

		IloCplex::CallbackI *duplicateCallback() const 
		{
        	return new (getEnv()) ExactCvrpUserCutCallBack(*this);
        }

        void main();

	private:
    	ExactCvrpGraph * _graph;
    	IloNumVarArray _x;
    	ExactCvrpSep * _sep;
    public:
    	IloConstraintArray added_constraints;
};



#endif
