/*
 * Copyright Jean-Francois Cote 2012
 * 
 * The code may be used for academic, non-commercial purposes only.
 * 
 * Please contact me at cotejean@iro.umontreal.ca for questions
 *
 * If you have improvements, please contact me!
 *
*/

#include "../ProblemDefinition.h"

#include "NodeCVRP.h"
#include "DriverCVRP.h"

class LoadTSP
{
	public:
		void Load(Prob<Node,Driver> & pr, char * filename);
	
};
