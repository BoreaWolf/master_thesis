/*
 * Copyright Jean-Francois Cote 2012
 * 
 * The code may be used for academic, non-commercial purposes only.
 * 
 * Please contact me at cotejean@iro.umontreal.ca for questions
 *
 * If you have improvements, please contact me!
 *
*/
#ifndef RELATEDNESSCVRP_H
#define RELATEDNESSCVRP_H

#include "../Relatedness.h"
#include "NodeCVRP.h"
#include "DriverCVRP.h"

class RelatednessCVRP : public Relatedness<Node,Driver>
{
	public:
		RelatednessCVRP(double ** m): _m(m){}
		~RelatednessCVRP(){}	
	
		double GetRelatedness(Node * n1, Node* n2)
		{
			return _m[n1->distID][n2->distID];
		}
		
		double GetScore(Sol<Node,Driver> & s, Node* n1)
		{
			return 0;
		}
		
		void Increase(Sol<Node,Driver> & s){}
		void Decrease(Sol<Node,Driver> & s){}
		
	private:
		double ** _m;
};

#endif
