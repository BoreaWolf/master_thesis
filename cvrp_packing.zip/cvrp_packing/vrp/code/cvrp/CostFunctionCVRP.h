/*
 * Copyright Jean-Francois Cote 2012
 * 
 * The code may be used for academic, non-commercial purposes only.
 * 
 * Please contact me at cotejean@iro.umontreal.ca for questions
 *
 * If you have improvements, please contact me!
 *
*/

#ifndef COST_FUNCTION_CVRP
#define COST_FUNCTION_CVRP

#include "NodeCVRP.h"
#include "DriverCVRP.h"
#include "../Solution.h"
#include "../ProblemDefinition.h"
#include "../CostFunction.h"

class CostFunctionCVRP: public CostFunction<Node,Driver>
{
	public:
		CostFunctionCVRP(Prob<Node,Driver> & prob): _m(prob.GetDistances()){}
		~CostFunctionCVRP(){}	
		
		double GetCost(Sol<Node,Driver> & s);
		double GetCost(Sol<Node,Driver> & s, Driver * d);
		void Update(Sol<Node,Driver> & s);
		void Update(Sol<Node,Driver> & s, Driver * d);
		void Show(Sol<Node,Driver> * s, Driver * d);
	private:
		double ** _m;
		
};


#endif 

