/*
 * Copyright Jean-Francois Cote 2012
 * 
 * The code may be used for academic, non-commercial purposes only.
 * 
 * Please contact me at cotejean@iro.umontreal.ca for questions
 *
 * If you have improvements, please contact me!
 *
*/

#ifndef INSRMV_CVRP
#define INSRMV_CVRP

#include "NodeCVRP.h"
#include "DriverCVRP.h"
#include "../Move.h"
#include "../InsRmvMethod.h"
#include "../ProblemDefinition.h"
#include "../Opt2.h"

class MoveCVRP
{
	public:
	Node * prev;
};


class InsRmvMethodCVRP : public InsRmvMethod<Node, Driver, MoveCVRP>
{
	public:
		InsRmvMethodCVRP(Prob<Node,Driver> & prob);
		~InsRmvMethodCVRP();
		void InsertCost(Sol<Node,Driver> & s, Node * n, Driver * d, Move<Node,Driver,MoveCVRP> & m);
		void ApplyInsertMove(Sol<Node,Driver> & s, Move<Node,Driver,MoveCVRP> & m);
		void RemoveCost(Sol<Node,Driver> & s, Node * n, Move<Node,Driver,MoveCVRP> & m);
		void CheckMove(Sol<Node,Driver> & s, Move<Node,Driver,MoveCVRP> & m){};
		
	
	private:
		double ** _m;
		double _added_noise;
		Opt2<Node,Driver> opt2;
};


#endif

