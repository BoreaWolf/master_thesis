
#include "ExactCvrpGraph.h"
#include "../../../lib/mathfunc.h"
#include "../../../lib/Network.h"

ExactCvrpGraph::ExactCvrpGraph(Prob<Node,Driver> * prob)
{
	_prob = prob;
	_nodes.push_back( prob->GetNode(prob->GetDriver(0)->StartNodeID) );
	capacity = prob->GetDriver(0)->capacity;
	
	for(int i=0;i<prob->GetCustomerCount();i++)
		_nodes.push_back(prob->GetCustomer(i));
	
	int n = prob->GetCustomerCount();
	_nbarcs = (n * (n-1))/2 + n;
	
	_arcs.resize(_nbarcs);
	
	int k = 0;
	for(size_t i=0;i<_nodes.size();i++)
		for(size_t j=i+1;j<_nodes.size();j++)
		{
			_arcs[k].from = _nodes[i];
			_arcs[k].to = _nodes[j];
			_arcs[k].index = k;
			_arcs[k].cost = prob->GetDistances()[ _nodes[i]->distID ][ _nodes[j]->distID ];
			k++;
		}
	
	_arcs_of.resize(_nodes.size());
	for(size_t i=0;i<_arcs.size();i++)
	{
		ExCvrpArc * ar = &_arcs[i];
		_arcs_of[ar->from->no].push_back(ar);
		_arcs_of[ar->to->no].push_back(ar);
	}
	
	_paths.resize(prob->GetDriverCount());
	_pos_arcs_of.resize(_nodes.size());
	for(int i=0;i<GetNodeCount();i++)
		_pos_arcs_of[i].resize( GetArcsOfCount(i) );
}

ExactCvrpGraph::~ExactCvrpGraph()
{
		
}


ExCvrpArc* ExactCvrpGraph::GetArc(int from, int to)
{
	for(int i=0;i<GetArcCount();i++)
	{
		ExCvrpArc * ar = GetArc(i);
		if(ar->from->no == from && ar->to->no == to)
			return ar;
		else if(ar->from->no == to && ar->to->no == from)
			return ar;
	}
	return NULL;
}

void ExactCvrpGraph::AssignPositiveValues()
{
	_pos_arcs.clear();
	for(int i=0;i<GetNodeCount();i++)
		_pos_arcs_of[i].clear();
	
	_is_integer = true;
	_cost = 0;
	for(int i=0;i<GetArcCount();i++)
	{
		ExCvrpArc * ar = GetArc(i);
		_cost += ar->value*ar->cost;
		if(ar->value > EPSILON)
		{
			_pos_arcs.push_back(ar);
			_pos_arcs_of[ ar->from->no ].push_back(ar);
			_pos_arcs_of[ ar->to->no ].push_back(ar);
			
			if(ar->value <= 1-EPSILON) _is_integer = false;
		}
	}
}


void ExactCvrpGraph::ShowPosValueArcs()
{
	for(size_t i=0;i<_pos_arcs.size();i++)
	{
		ExCvrpArc * ar = _pos_arcs[i];
		printf("i:%d from:%d to:%d va:%.3lf\n", (int)i, ar->from->no, ar->to->no, ar->value);
	}	
	
}

void ExactCvrpGraph::PrintGraph(char * filename)
{
	Network * n = new Network(GetNodeCount());
	for(size_t i=0;i<_pos_arcs.size();i++)
		n->AddArc(_pos_arcs[i]->from->no,_pos_arcs[i]->to->no,_pos_arcs[i]->index);
	for(size_t i=0;i<_pos_arcs.size();i++)
		n->SetArc(_pos_arcs[i]->index,1,_pos_arcs[i]->value);
	n->PrintGraphViz(filename);
	delete n;
}



void ExactCvrpGraph::ShowPaths()
{
	for(size_t i=0;i<_paths.size();i++)
	{
		printf("path:%d nb:%d nodes:", (int)i,(int)_paths[i].size());
		for(size_t j=0;j<_paths[i].size();j++)
			printf("%d-",_paths[i][j]->no); 
		printf("\n");	
	}
}

void ExactCvrpGraph::MakePaths()
{
	for(size_t i=0;i<_pos_arcs.size();i++)
		_pos_arcs[i]->walked_on = 0;
	
	int nb_out_arcs = (int)GetSumArcValue(0);
	int nb_paths = nb_out_arcs / 2;
	for(int i=0;i<GetArcsOfPosCount(0);i++)
		if(GetArcsOfPos(0,i)->value >= 2-EPSILON)
			nb_paths--;
	
	_paths.resize(nb_paths);
	_paths.clear();
	//printf("nboutarcs:%d size:%d\n", nb_out_arcs,(int)_paths.size());
	
	int cur_path = 0;
	for(int i=0;i<GetArcsOfPosCount(0);i++)
	{
		ExCvrpArc* ar = GetArcsOfPos(0,i);
		if(ar->walked_on == 1) continue;
		
		std::vector<Node*> vv;
		_paths.push_back(vv);
		
		//printf("cur_path:%d ", cur_path);
		//_paths[cur_path].clear();
		_paths[cur_path].push_back(ar->from);
		
		ar->walked_on = 1;
		
		if(ar->value >= 2-EPSILON)
		{
			_paths[cur_path].push_back(ar->to);
			_paths[cur_path].push_back(ar->from);
			cur_path++;
			continue;
		}
		
		
		
		Node * from = ar->from;
		Node * to = ar->to;
		do
		{
			_paths[cur_path].push_back(to);
			//printf("%d-", to->no);
			ExCvrpArc* nar1 = GetArcsOfPos(to->no, 0);
			ExCvrpArc* nar2 = GetArcsOfPos(to->no, 1);
			if(nar1 != ar)
			{
				if(nar1->from == to)
				{
					to = nar1->to;
					from = nar1->from;
				}
				else
				{
					from = nar1->to;
					to = nar1->from;
				}
				ar = nar1;
			}
			else if(nar2 != ar)
			{
				if(nar2->from == to)
				{
					to = nar2->to;
					from = nar2->from;
				}
				else
				{
					from = nar2->to;
					to = nar2->from;
				}
				ar = nar2;
			}
			else
			{
				printf("ERRRRRREEEEEEUUUUURRRR\n");	
			}
			ar->walked_on = 1;
		}
		while(ar->from->no != 0);
		
		_paths[cur_path].push_back(to);
		//printf("%d \n", to->no);
		cur_path++;
	}
	
}









