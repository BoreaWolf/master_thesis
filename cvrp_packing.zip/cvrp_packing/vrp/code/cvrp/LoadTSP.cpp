
#include "LoadTSP.h"
#include <math.h>
#include <vector>
#include "../constants.h"
#include "../../../lib/mathfunc.h"
#include <stdio.h>
#include <stdlib.h>

void LoadTSP::Load(Prob<Node,Driver> & pr, char * filename)
{	
	pr = Prob<Node,Driver>();
	FILE * f = fopen(filename, "r");

	if(f == NULL)
	{
		printf("Error at the opening of the file:%s\n", filename);
		exit(1);
	}
	
	char buf[1024];
	int nb_items;
	int rrr = 0;
	char * rrc = NULL;
	
	rrc = fgets(buf, 1023, f);		 				//nom du fichier
	rrc = fgets(buf, 1023, f);						//commentaire
	rrc = fgets(buf, 1023, f);						//type
	rrr = fscanf(f, "DIMENSION : %d\n", &nb_items);	//nombre d'items
	rrc = fgets(buf, 1023, f);						//type de poids
	rrc = fgets(buf, 1023, f);						//lecture de NODE_COORD_SECTION
	

	std::vector<float> vec_x(0);
	std::vector<float> vec_y(0);
	int no;
	float x,y;

	vec_x.push_back(0);
	vec_y.push_back(0);

	//read customers
	for(int i = 0; i< nb_items; i++)
	{
		rrr= fscanf(f, "%d %f %f\n", &no, &x, &y);
		Node n;
		n.id = i;
		n.no = i+1;
		n.demand = 0;
		n.distID = i+1;
		n.type = NODE_TYPE_CUSTOMER;
		n.serv_time = 0;
		pr.AddNode(n);
		
		vec_x.push_back(x);
		vec_y.push_back(y);
	}
	fclose(f);

	//Driver 
	{
		Node dep1;
		dep1.id = nb_items;
		dep1.no = 0;
		dep1.distID = 0;	
		dep1.demand = 0;
		dep1.type = NODE_TYPE_START_DEPOT;
		dep1.serv_time = 0;
		
		Node dep2(dep1);
		dep2.id = nb_items + 1;
		dep2.type = NODE_TYPE_END_DEPOT;
		
		Driver d;
		d.capacity = nb_items + 1;
		d.StartNodeID = dep1.id;
		d.EndNodeID = dep2.id;
		d.maxDuration = (int)INFINITE;
		d.id = 0;
		
		pr.AddNode(dep1);
		pr.AddNode(dep2);
		pr.AddDriver(d);
	}
	
	for(int i = 0; i< nb_items; i++)
		pr.AddCustomer( pr.GetNode(i) );
	
	int dim = (int) vec_x.size();
	double ** d = new double*[dim];
	
	for(int i = 0 ; i < dim ; i++)
	{
		d[i] = new double[dim];	
		for(int j = 0 ; j < dim ; j++)
		{
			if(i == 0 || j ==0)
				d[i][j] = 0;
			else
				d[i][j] = sqrt( (vec_x[i] - vec_x[j])*(vec_x[i] - vec_x[j]) + (vec_y[i] - vec_y[j])*(vec_y[i] - vec_y[j]));
				
			d[i][j] = (int)( d[i][j] +0.5);
		}
	}
	
	pr.SetMaxtrices(d,d,dim);
}







