

#include "CreateDriverCVRP.h"


void CreateDriverCVRP::Create(Sol<Node,Driver> * s)
{
	Prob<Node,Driver> * p = s->GetProblemDefinition();
	
	Driver d1 = *s->GetDriver(0);
	d1.id = s->GetDriverCount();
		
	Node n1 = *s->GetNode(d1.StartNodeID);
	Node n2 = *s->GetNode(d1.EndNodeID);
	
	n1.id = s->GetNodeCount();
	n2.id = s->GetNodeCount()+1;
	d1.StartNodeID = n1.id;
	d1.EndNodeID = n2.id;
	
	s->AddNode();
	s->AddNode();
	s->AddDriver();
	
	p->AddNode(n1);
	p->AddNode(n2);
	p->AddDriver(d1);
	Driver * d = s->GetDriver(d1.id);
	
	s->Next[n1.id] = s->GetNode(d1.EndNodeID);
	s->Prev[n2.id] = s->GetNode(d1.StartNodeID);
	s->AssignTo[n1.id] = d;
	s->AssignTo[n2.id] = d;
}


