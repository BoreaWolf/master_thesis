
/*
 * Copyright Jean-Francois Cote 2012
 * 
 * The code may be used for academic, non-commercial purposes only.
 * 
 * Please contact me at cotejean@iro.umontreal.ca for questions
 *
 * If you have improvements, please contact me!
 *
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "../ProblemDefinition.h"
#include "../Solution.h"
#include "../SequentialInsertion.h"
#include "../RemoveRandom.h"
#include "../RemoveRelated.h"
#include "../RemoveScore.h"
#include "../RemoveCluster.h"
#include "../RegretInsertion.h"
#include "../RegretInsertionOperator.h"
#include "../ALNS.h"

#include "../BestSolutionList.h"
#include "../RelatednessHistoricalRequestPair.h"
#include "../RelatednessHistoricalCostPair.h"
#include "../ScoreWorstRemoval.h"

#include "NodeCVRP.h"
#include "DriverCVRP.h"
#include "LoadCVRP.h"
#include "LoadTSP.h"
#include "InsRmvMethodCVRP.h"
#include "CostFunctionCVRP.h"
#include "RelatednessCVRP.h"
#include "CreateDriverCVRP.h"

#include "../Relocate.h"

int main(int arg, char ** argv)
{
	time_t tt = 0;//time(0);
	srand(tt);
	printf("Seed:%ld\n", tt);
	//srand(1304445903);
	Prob<Node,Driver> pr;
	
	LoadCVRP loadcvrp;
	
	if(arg > 1)
		loadcvrp.Load(pr, argv[1]);
	//	loadtsp.Load(pr, argv[1]);
	else
		loadcvrp.Load(pr,(char*) "../instances/cvrp/kelly01.txt");
	//	loadtsp.Load(pr, "../instances/tsp/eil76.tsp");
	
	/*for(int i=0;i<pr.GetCustomerCount();i++)
	{
		Node * n = pr.GetCustomer(i); 
		printf("  %.4lf\t%.4lf\t%d\n", n->x, n->y, n->demand);
	}*/
	BestSolutionList<Node,Driver> best_sol_list(&pr,100);
	
	CreateDriverCVRP create_driver;
	
	CostFunctionCVRP cost_func(pr);
	InsRmvMethodCVRP method(pr);
	
	Sol<Node,Driver> sol(&pr,&cost_func);
	sol.PutAllNodesToUnassigned();
	
	SeqInsertion<Node,Driver,MoveCVRP> seq(method);
	
	RegretInsertion<Node,Driver,MoveCVRP> regret(pr,method);
	RegretInsertionOperator<Node,Driver,MoveCVRP> regret2(&regret, 3, 0);
	RegretInsertionOperator<Node,Driver,MoveCVRP> regret2n(&regret, 3, 1);
	RegretInsertionOperator<Node,Driver,MoveCVRP> regretk(&regret, pr.GetDriverCount(), 0);
	RegretInsertionOperator<Node,Driver,MoveCVRP> regretkn(&regret, pr.GetDriverCount(), 1);
	
	RemoveRandom<Node,Driver> random_remove;
	
	ALNS<Node,Driver> alns;
	alns.AddInsertOperator(&seq);
	alns.AddInsertOperator(&regret2);
	alns.AddInsertOperator(&regret2n);
	alns.AddInsertOperator(&regretk);
	alns.AddInsertOperator(&regretkn);
	alns.AddRemoveOperator(&random_remove);
	
	Relocate<Node,Driver,MoveCVRP> relocate(&method);
	relocate.Optimize(sol);
	
	
	regretk.Insert(sol);
	sol.Show();
	relocate.Optimize(sol);
	
	while(sol.GetUnassignedCount() != 0)
	{
		alns.SetTemperatureIterInit(10000); alns.SetIterationCount(2000); alns.SetTemperature(.999);
		
		alns.Optimize(sol);
		sol.Show();
		
		if(sol.GetUnassignedCount() <= 0) break;
		create_driver.Create(&sol);
		sol.Update(sol.GetDriver(sol.GetDriverCount()-1));
		regretk.Insert(sol);
		relocate.Optimize(sol);
	}
	sol.Show();
	
	ScoreWorstRemoval<Node,Driver> worst_score;
	RelatednessCVRP relatd_cvrp(pr.GetDistances());
	RelatednessHistoricalRequestPair<Node,Driver> historicalpair(pr);
	RelatednessHistoricalCostPair<Node,Driver> historicalcost(pr);
	best_sol_list.Add(&historicalpair);
	best_sol_list.Add(&historicalcost);
	
	RemoveRelated<Node,Driver> related_remove(&relatd_cvrp);
	RemoveRelated<Node,Driver> related_remove_hp(&historicalpair);
	RemoveScore<Node,Driver> score_remove_cost(&historicalcost);
	RemoveScore<Node,Driver> score_worst_cost(&worst_score);
	RemoveCluster<Node,Driver> remove_cluster(pr);
	
	
	alns.AddRemoveOperator(&related_remove);
	alns.AddRemoveOperator(&related_remove_hp);
	alns.AddRemoveOperator(&score_remove_cost);
	//alns.AddRemoveOperator(&remove_cluster);
	alns.AddRemoveOperator(&score_worst_cost);
	
	sol.Show();

	
	alns.SetTemperatureIterInit(0);
	alns.SetTemperature(0.9995);
	alns.SetIterationCount(25000);
	//alns.Optimize(sol,&best_sol_list);
	alns.Optimize(sol);
	
	sol.Show();
	
	//best_sol_list.Show();
	
	return 0;
}



