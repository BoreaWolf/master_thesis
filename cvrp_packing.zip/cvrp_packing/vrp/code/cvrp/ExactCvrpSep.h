
#ifndef EXACT_CVRP_SEP_H
#define EXACT_CVRP_SEP_H

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <cstring>
#include <ilcplex/ilocplex.h>
#include <algorithm>
#include <vector>
#include "NodeCVRP.h"
#include "DriverCVRP.h"
#include "../ProblemDefinition.h"
#include "../Solution.h"
#include "ExactCvrpGraph.h"
#include "../../../lib/CVRPSEP/basegrph.h"
#include "../../../lib/CVRPSEP/cnstrmgr.h"
#include "../../../lib/CVRPSEP/capsep.h"
#include "../../../lib/bag.h"

class ExactCvrpSep
{
	public:
		ExactCvrpSep(IloEnv env, ExactCvrpGraph * graph, IloNumVarArray x);
		~ExactCvrpSep();

		void Seperate(IloConstraintArray array);
		
	private:
		void SeperateCap(IloConstraintArray constraints);
	
		IloEnv _env;
		ExactCvrpGraph * _graph;
		IloNumVarArray _x;
		
		int Dim;		
		char IntAndFea;		int NoOfCustomers,CAP,NoOfEdges,MaxNoOfCuts; 
		double EpsForIntegrality,MaxViolation;		int *Demand, *EdgeTail, *EdgeHead;		double *EdgeX;		CnstrMgrPointer MyCutsCMP,MyOldCutsCMP;
		
		BagPtr bag_node;
		BagPtr bag_arc;
		
		int nbseps;
};

#endif
