
/*
 * Copyright Jean-Francois Cote 2012
 * 
 * The code may be used for academic, non-commercial purposes only.
 * 
 * Please contact me at cotejean@iro.umontreal.ca for questions
 *
 * If you have improvements, please contact me!
 *
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "../ProblemDefinition.h"
#include "../Solution.h"
#include "../SequentialInsertion.h"
#include "../RemoveRandom.h"
#include "../RemoveRelated.h"
#include "../RemoveScore.h"
#include "../RemoveCluster.h"
#include "../RegretInsertion.h"
#include "../RegretInsertionOperator.h"
#include "../ALNS.h"

#include "../BestSolutionList.h"
#include "../RelatednessHistoricalRequestPair.h"
#include "../RelatednessHistoricalCostPair.h"
#include "../ScoreWorstRemoval.h"

#include "NodeCVRP.h"
#include "DriverCVRP.h"
#include "LoadCVRP.h"
#include "LoadTSP.h"
#include "InsRmvMethodCVRP.h"
#include "CostFunctionCVRP.h"
#include "RelatednessCVRP.h"
#include "CreateDriverCVRP.h"

#include "ExactCVRP.h"

int main(int arg, char ** argv)
{
	//time_t tt = time(0); printf("Seed:%ld\n", tt);
	time_t tt = 0;
	srand(tt);
	
	Prob<Node,Driver> pr;
	LoadCVRP loadcvrp;
	
	if(arg > 1)
		loadcvrp.Load(pr, argv[1]);
	else
		loadcvrp.Load(pr,(char*) "../instances/cvrp/vrpnc1.txt");
	
	
	BestSolutionList<Node,Driver> best_sol_list(&pr,100); //list of the 100 best solutions
	
	CreateDriverCVRP create_driver;
	
	CostFunctionCVRP cost_func(pr);
	InsRmvMethodCVRP method(pr);
	
	Sol<Node,Driver> sol(&pr,&cost_func);
	sol.PutAllNodesToUnassigned();
	
	//Create the insertion and remove operators
	
	
	SeqInsertion<Node,Driver,MoveCVRP> seq(method);
	RegretInsertion<Node,Driver,MoveCVRP> regret(pr,method);
	RegretInsertionOperator<Node,Driver,MoveCVRP> regret2(&regret, 3, 0);
	RegretInsertionOperator<Node,Driver,MoveCVRP> regret2n(&regret, 3, 1);
	RegretInsertionOperator<Node,Driver,MoveCVRP> regretk(&regret, pr.GetDriverCount(), 0);
	RegretInsertionOperator<Node,Driver,MoveCVRP> regretkn(&regret, pr.GetDriverCount(), 1);
	RemoveRandom<Node,Driver> random_remove;
	
	
	ALNS<Node,Driver> alns;
	alns.AddInsertOperator(&seq);
	alns.AddInsertOperator(&regret2);
	alns.AddInsertOperator(&regret2n);
	alns.AddInsertOperator(&regretk);
	alns.AddInsertOperator(&regretkn);
	alns.AddRemoveOperator(&random_remove);
	
	regretk.Insert(sol);//Generate an initial solution
	 
	 
	 
	//if not all stops could be inserted
	//Optimize and add a driver
	while(sol.GetUnassignedCount() != 0)
	{
		alns.SetTemperatureIterInit(1000); alns.SetIterationCount(50); alns.SetTemperature(.999);
		
		alns.Optimize(sol);
		
		if(sol.GetUnassignedCount() <= 0) break;
		create_driver.Create(&sol);
		sol.Update(sol.GetDriver(sol.GetDriverCount()-1));
		regretk.Insert(sol);
	}
	sol.Show();
	
	
	
	
	
	//create the remaining operators
	ScoreWorstRemoval<Node,Driver> worst_score;
	RelatednessCVRP relatd_cvrp(pr.GetDistances());
	RelatednessHistoricalRequestPair<Node,Driver> historicalpair(pr);
	RelatednessHistoricalCostPair<Node,Driver> historicalcost(pr);
	best_sol_list.Add(&historicalpair);
	best_sol_list.Add(&historicalcost);
	
	RemoveRelated<Node,Driver> related_remove(&relatd_cvrp);
	RemoveRelated<Node,Driver> related_remove_hp(&historicalpair);
	RemoveScore<Node,Driver> score_remove_cost(&historicalcost);
	RemoveScore<Node,Driver> score_worst_cost(&worst_score);
	RemoveCluster<Node,Driver> remove_cluster(pr);
	
	
	alns.AddRemoveOperator(&related_remove);
	alns.AddRemoveOperator(&related_remove_hp);
	alns.AddRemoveOperator(&score_remove_cost);
	//alns.AddRemoveOperator(&remove_cluster);
	alns.AddRemoveOperator(&score_worst_cost);
	

	
	
	//Optimize
	alns.SetTemperatureIterInit(0);
	alns.SetTemperature(0.9995);
	alns.SetIterationCount(25000);
	alns.Optimize(sol);
	sol.Show();
	
	
	//Solve Exactly
	ExactCVRP ex_cvrp;
	ex_cvrp.Solve(&pr, sol);
	sol.Show();


	//print the solution to a file
	//FILE * f = fopen("sol.txt","w");
	//sol.PrintVizToFile(f);
	//fclose(f);

	return 0;
}



