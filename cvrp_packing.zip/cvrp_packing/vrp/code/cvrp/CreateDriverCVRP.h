/*
 * Copyright Jean-Francois Cote 2012
 * 
 * The code may be used for academic, non-commercial purposes only.
 * 
 * Please contact me at cotejean@iro.umontreal.ca for questions
 *
 * If you have improvements, please contact me!
 *
*/

#ifndef CREATE_DRIVERCVRP_H
#define CREATE_DRIVERCVRP_H

#include "../Solution.h"
#include "NodeCVRP.h"
#include "DriverCVRP.h"
#include "../CreateDriver.h"

class CreateDriverCVRP : public CreateDriver<Node,Driver>
{
	public:	
		CreateDriverCVRP(){}
		~CreateDriverCVRP(){}
		void Create(Sol<Node,Driver> * p);
	
};

#endif
