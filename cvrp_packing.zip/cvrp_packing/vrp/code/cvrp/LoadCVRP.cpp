
#include "LoadCVRP.h"
#include <math.h>
#include <vector>
#include <stdio.h>
#include <stdlib.h>
#include "../constants.h"


void LoadCVRP::Load(Prob<Node,Driver> & pr, char * filename)
{	
	pr = Prob<Node,Driver>();
		
	FILE * f = fopen(filename, "r");

	if(f == NULL)
	{
		printf("Error at the opening of the file:%s\n", filename);
		exit(1);
	}
	
	int nb_items, cap, duration, serv_time;

	std::vector<float> vec_x(0);
	std::vector<float> vec_y(0);
	int dmd, sum_dmd = 0;
	float x,y;

	int rrr = 0;
	char * rrc = NULL;

	rrr = fscanf(f, "%d %d %d %d\n", &nb_items, &cap, &duration, &serv_time);
	

	rrr = fscanf(f, "%f %f %d\n", &x, &y,&dmd);
	vec_x.push_back(x);
	vec_y.push_back(y);

	//read customers
	for(int i = 0; i< nb_items; i++)
	{
		rrr = fscanf(f, "%f %f %d\n", &x,&y,&dmd);
		Node n;
		n.id = i;
		n.no = i+1;
		n.demand = dmd;
		n.distID = i+1;
		n.type = NODE_TYPE_CUSTOMER;
		n.serv_time = serv_time;
		n.x = x;
		n.y = y;
		pr.AddNode(n);
		
	
		vec_x.push_back(x);
		vec_y.push_back(y);
		
		sum_dmd += dmd;
	}

	fclose(f);

	int nb_drivers = (sum_dmd / cap) ;
	
	for(int i = 0 ; i < nb_drivers ; i++)
	{
		Node dep1;
		dep1.id = nb_items + i*2;
		dep1.no = 0;
		dep1.distID = 0;	
		dep1.demand = 0;
		dep1.type = NODE_TYPE_START_DEPOT;
		dep1.serv_time = 0;
		
		Node dep2(dep1);
		dep2.id = nb_items + i*2 + 1;
		dep2.type = NODE_TYPE_END_DEPOT;
		
		Driver d;
		d.capacity = cap;
		d.StartNodeID = dep1.id;
		d.EndNodeID = dep2.id;
		d.maxDuration = duration;
		d.id = i;
		
		pr.AddNode(dep1);
		pr.AddNode(dep2);
		pr.AddDriver(d);
	}
	
	for(int i = 0; i< nb_items; i++)
		pr.AddCustomer( pr.GetNode(i) );
	
	int dim = (int) vec_x.size();
	double ** d = new double*[dim];
	
	for(int i = 0 ; i < dim ; i++)
	{
		d[i] = new double[dim];	
		for(int j = 0 ; j < dim ; j++)
		{
			d[i][j] = sqrt( (vec_x[i] - vec_x[j])*(vec_x[i] - vec_x[j]) + (vec_y[i] - vec_y[j])*(vec_y[i] - vec_y[j]));
			//d[i][j] = (int)(d[i][j] + 0.5);
			//d[i][j] = ceil( d[i][j] - 0.0000001);
		}
	}
	
	pr.SetMaxtrices(d,d,dim);
}


/*
Format of vehicle routing problem instances :

Number of customers, best known solution value
Vehicle capacity
xdepot ydepot
For each customer : Customer number, x, y, demand

Few files also have one or two solution at the end.
The format of solutions is :
Number of vehicles tours, service time for each customers, tour time limit
For each tour : number of customers, 1. customer, 2. customer, ...

Sources of the best solutions known :
L. Gambardella,  É. D. Taillard, "An ant system for the VRP", in preparation.

A. Reinholz, http://www-set.gmd.de/~andy/Benchmarks.html

Y. Rochat, É. D. Taillard, "Probabilistic diversification and intensification in local search for vehicle routing". Journal of Heuristics 1, 1995 147-167. 

É. D. Taillard, "Parallel iterative search methods for vehicle routing problems", Networks 23, 1993, 661 ­ 673.
*/






