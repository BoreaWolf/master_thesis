
#include "ExactCvrpSep.h"
#include "../../../lib/mathfunc.h"


ExactCvrpSep::ExactCvrpSep(IloEnv env, ExactCvrpGraph * graph, IloNumVarArray x) : _env(env), _graph(graph), _x(x)
{
	Dim = 100; 
	CMGR_CreateCMgr(&MyCutsCMP,Dim);
	CMGR_CreateCMgr(&MyOldCutsCMP,Dim);
	Demand = (int*)calloc(_graph->GetNodeCount()+2,sizeof(int));
	EdgeTail = (int*)calloc(_graph->GetArcCount()+1, sizeof(int)); 
	EdgeHead = (int*)calloc(_graph->GetArcCount()+1, sizeof(int));	EdgeX = (double*)calloc(_graph->GetArcCount()+1, sizeof(double));
	EpsForIntegrality = 0.02;
	MaxNoOfCuts = 8;
	CAP = _graph->GetCapacity();
	NoOfCustomers = _graph->GetNodeCount();
	
	for(int i = 0 ; i < _graph->GetNodeCount();i++)
		Demand[i] = _graph->GetNode(i)->demand;
	
	for(int i = 0 ; i < _graph->GetNodeCount();i++)
	{
		Node * n = _graph->GetNode(i);
		//printf("i:%d dmd:%d no:%d dmd:%d x:%.2lf y:%.2lf\n", i,Demand[i],n->no, n->demand,n->x,n->y);
	}
	BagInitMem(&bag_node, NoOfCustomers, 0);
	BagInitMem(&bag_arc, _graph->GetArcCount(), 0);
	nbseps = 0;
}

ExactCvrpSep::~ExactCvrpSep()
{
	free(Demand);free(EdgeTail);free(EdgeHead);free(EdgeX);
	CMGR_FreeMemCMgr(&MyCutsCMP);
	CMGR_FreeMemCMgr(&MyOldCutsCMP);
}

void ExactCvrpSep::Seperate(IloConstraintArray constraints)
{
	//printf("ExactCvrpSep::Seperate:%d\n",nbseps);
	NoOfEdges = 0;
	for(int i = 0 ; i < _graph->GetArcCount();i++)
	{
		ExCvrpArc * arc = _graph->GetArc(i);
		if(arc->value > EPSILON)
		{
			NoOfEdges++;
			EdgeTail[NoOfEdges] = arc->from->no!=0?arc->from->no:NoOfCustomers;
			EdgeHead[NoOfEdges] = arc->to->no;
			EdgeX[NoOfEdges] = arc->value;
			//printf("i:%d from:%d to:%d v:%.2lf\n",NoOfEdges,arc->from->no,arc->to->no,arc->value);
		}
	}
	
	//_graph->ShowPosValueArcs();
	//_graph->PrintGraph((char*)"graph.dot");
	SeperateCap(constraints);
	
	nbseps++;
}

void ExactCvrpSep::SeperateCap(IloConstraintArray constraints)
{
	CAPSEP_SeparateCapCuts(	NoOfCustomers-1,Demand,CAP,NoOfEdges,
							EdgeTail,EdgeHead,EdgeX,MyOldCutsCMP, MaxNoOfCuts, 
							EpsForIntegrality, &IntAndFea, &MaxViolation, MyCutsCMP);
	
	//printf("SeperateCap intfea:%d nb:%d\n",(int)IntAndFea,MyCutsCMP->Size);	//CMGR_WriteCMP(MyCutsCMP,0);
	
	//if (IntegerAndFeasible) break; /* Optimal solution found */ 
	//if (MyCutsCMP->Size == 0) break; /* No cuts found */	/* Read the cuts from MyCutsCMP, and add them to the LP */ 
	/* Resolve the LP */	
	for (int i=0;i<MyCutsCMP->Size;i++)
	{		//if(MyCutsCMP->CPL[i]->IntListSize >= 18) continue;
		
		int dmd1 = 0;
		//printf("Cut:%d customers:", i);
		for (int j=1;j<=MyCutsCMP->CPL[i]->IntListSize; j++) 
		{
		//	printf("%d ", MyCutsCMP->CPL[i]->IntList[j]);
			dmd1 += _graph->GetNode( MyCutsCMP->CPL[i]->IntList[j])->demand;
		}
		//printf(" <= rhs:%d dmd1:%d ", (int)MyCutsCMP->CPL[i]->RHS,dmd1);
		//printf("nb:%d\n", MyCutsCMP->CPL[i]->IntListSize);
		/* Now List contains the customer numbers defining the cut. */
		/* in the form x(S:S) <= |S| - k(S), is RHS. */
		
		BagClear(bag_node,0);
		BagClear(bag_arc,0);
		for (int j=1;j<=MyCutsCMP->CPL[i]->IntListSize; j++) 
		{
			int no =  MyCutsCMP->CPL[i]->IntList[j];
			if(no == NoOfCustomers) no = 0;
			BagAddItem(bag_node, no);
		}
		for (int j=1;j<=MyCutsCMP->CPL[i]->IntListSize; j++) 
		{
			int k = MyCutsCMP->CPL[i]->IntList[j];
			for(int l=0;l<_graph->GetArcsOfCount(k);l++)
			{
				ExCvrpArc * arc = _graph->GetArcOf(k,l);
				if(	bag_node->index[ arc->to->no ] != -1 && 
					bag_node->index[ arc->from->no ] != -1 &&
				   	bag_arc->index[arc->index] == -1)
			   	{
			   		BagAddItem(bag_arc,arc->index);
					//printf("x%d_%d+ ", arc->from->no,arc->to->no);
			   	}
			}
		}
		//printf(" <= rhs:%d\n", (int)MyCutsCMP->CPL[i]->RHS);
		double sumv = 0;
		BagClear(bag_arc,0);
		IloExpr expr(_x.getEnv());		for (int j=1;j<=MyCutsCMP->CPL[i]->IntListSize; j++) 
		{
			int k = MyCutsCMP->CPL[i]->IntList[j];
			for(int l=0;l<_graph->GetArcsOfCount(k);l++)
			{
				ExCvrpArc * arc = _graph->GetArcOf(k,l);
				if(	bag_node->index[ arc->to->no ] != -1 && 
					bag_node->index[ arc->from->no ] != -1 &&
				   	bag_arc->index[arc->index] == -1
				   	)//&& arc->value > EPSILON)
				{
			   		BagAddItem(bag_arc,arc->index);
					expr += _x[ arc->index ];
					//printf("x%d_%d+ ", arc->from->no,arc->to->no);
					sumv += arc->value;
				}
			}
		}		//printf(" <= rhs:%d sumv:%.3lf\n", (int)MyCutsCMP->CPL[i]->RHS,sumv);		constraints.add(expr <= MyCutsCMP->CPL[i]->RHS);
		expr.end();
	}
	
	/* Move the new cuts to the list of old cuts: */ 
	for (int i=0;i<MyCutsCMP->Size;i++)		CMGR_MoveCnstr(MyCutsCMP,MyOldCutsCMP,i,0); 	MyCutsCMP->Size = 0;
	
	//if(nbseps >= 20)
	//exit(1);
}




