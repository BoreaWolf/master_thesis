/*
 * Copyright Jean-Francois Cote 2012
 * 
 * The code may be used for academic, non-commercial purposes only.
 * 
 * Please contact me at cotejean@iro.umontreal.ca for questions
 *
 * If you have improvements, please contact me!
 *
*/

#ifndef DRIVER_CVRP
#define DRIVER_CVRP

class Driver
{	
	public:
		int id;				//from 0 to nb drivers - 1
		int StartNodeID;	//
		int EndNodeID;		//
		int capacity;
		int sumDemand;		
		int maxDuration;
		double curDistance;
		double curDuration;
};

#endif


