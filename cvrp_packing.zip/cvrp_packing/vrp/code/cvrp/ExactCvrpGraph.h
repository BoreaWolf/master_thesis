


#ifndef EXACT_CVRP_GRAPH_H
#define EXACT_CVRP_GRAPH_H
#include <algorithm>
#include <vector>
#include "NodeCVRP.h"
#include "DriverCVRP.h"
#include "../ProblemDefinition.h"
#include "../Solution.h"


class ExCvrpArc
{
	public:
		Node * from;
		Node * to;
		int index;
		double cost;
		double value;
		char walked_on;
};

class ExactCvrpGraph
{
	public:
		ExactCvrpGraph(){}
		ExactCvrpGraph(Prob<Node,Driver> * prob);
		~ExactCvrpGraph();

		int GetNodeCount(){return (int)_nodes.size();}	
		Node* GetNode(int index){return _nodes[index];}
		Node* GetDepot(){return _nodes[0];}
		
		int GetArcCount(){return _nbarcs;}
		ExCvrpArc* GetArc(int index){ return &_arcs[index]; }
		ExCvrpArc* GetArc(int from, int to);
		int GetCapacity(){ return capacity; }
		int GetArcsOfCount(int index){return (int)_arcs_of[index].size();}
		ExCvrpArc* GetArcOf(int index, int j){ return _arcs_of[index][j];}
		int GetArcsOfPosCount(int i){ return (int)_pos_arcs_of[i].size();}
		ExCvrpArc* GetArcsOfPos(int i, int j){ return _pos_arcs_of[i][j];}
		
		int GetPathCount(){return (int)_paths.size();}
		std::vector<Node*>& GetPath(int i){ return _paths[i];}
		
		void AssignPositiveValues();
		void ShowPosValueArcs();
		
		void MakePaths();
		void ShowPaths();
		void PrintGraph(char * filename);
		
		
		double GetSumArcValue(int node)
		{
			double v = 0;	
			for(int i=0;i<GetArcsOfPosCount(node);i++)
				v += GetArcsOfPos(node,i)->value;
			return v;
		}
	private:
		Prob<Node,Driver> * _prob;
		std::vector<Node*> _nodes;	//nodes [0, ..., n] 0 is the depot, others are customers
		int _nbarcs;
		std::vector<ExCvrpArc> _arcs;
		std::vector< std::vector<ExCvrpArc*> > _arcs_of;
		std::vector<ExCvrpArc*> _pos_arcs; //arcs with a positive value
		std::vector< std::vector<ExCvrpArc*> > _pos_arcs_of; //arcs with a positive value
		int capacity;
		std::vector< std::vector<Node*> > _paths;
		bool _is_integer;
		double _cost;
};


#endif
