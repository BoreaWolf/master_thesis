/*
 * Copyright Jean-Francois Cote 2012
 * 
 * The code may be used for academic, non-commercial purposes only.
 * 
 * Please contact me at cotejean@iro.umontreal.ca for questions
 *
 * If you have improvements, please contact me!
 *
*/
#ifndef NODE_CVRP
#define NODE_CVRP

class Node
{
	public:
		int id;			//from 0 to n-1
		int origin_id;  //ID at the begining, it is never modified, only customers have a valid unique ID
		int demand;		
		int distID;		//indicate which line and column that contains the distance/time in the matrices
		int no;			//personnal identifier, put what you want
		char type;		//type of the node
		int serv_time;
		double x;
		double y;
};

#endif

