
#include "ExactCVRP.h"
#include "ExactCvrpGraph.h"
#include "CreateDriverCVRP.h"
#include "../../../lib/mathfunc.h"
#include "../constants.h"

void ExactCVRP::Solve(Prob<Node,Driver> * pprob, Sol<Node,Driver> & s)
{
	prob = pprob;
	printf("\n\nExactCVRP::Solve\n");
	
	graph = new ExactCvrpGraph(prob);
	
	Init(s);
	//TestSolution(s);
	
	
	SolveProblem(s);
	
	Clear();
}

void ExactCVRP::SolveProblem(Sol<Node,Driver> & s)
{
	//cplex.exportModel("cvrp.lp");
	
	bool re = cplex.solve();
	int cplex_status = (int)cplex.getCplexStatus();
	double sol = re?cplex.getObjValue():0;
	printf("sol:%lf status:%d nbnodes:%d\n", sol, cplex_status,(int)cplex.getNnodes());

	s.UnassignAllCustomers();
	if(re && cplex_status != 11)
	{			
		//build the solution
		for(int i = 0 ; i < graph->GetArcCount();i++)
			graph->GetArc(i)->value = cplex.getValue(x[i]);
		graph->AssignPositiveValues();
		graph->MakePaths();
		//graph->ShowPosValueArcs();
		//graph->ShowPaths();
		//graph->PrintGraph((char*)"sol.dot");
		
		CreateDriverCVRP create_driver;
		for(int i=s.GetDriverCount();i<graph->GetPathCount();i++)
			create_driver.Create(&s);
		
		for(int i=0;i<graph->GetPathCount();i++)
		{
			std::vector<Node*> & path = graph->GetPath(i);
			Driver * d = s.GetDriver(i);
			Node * prev = s.GetNode(d->StartNodeID);
			for(size_t j=0;j<path.size();j++)
				if(path[j]->type == NODE_TYPE_CUSTOMER)
				{
					s.RemoveFromUnassigneds( path[j] );
					s.InsertAfter(path[j], prev);
					prev = path[j];
				}
		}
		//printf("Optimal Solution\n");
		//s.Show();
	}
	graph->AssignPositiveValues();
	//graph->PrintGraph((char*)"sol.dot");
	
	//if(usercut_call->added_constraints.getSize() >= 1) cplex.addCuts(usercut_call->added_constraints);
	//cplex.add(lazy_call->added_constraints);
	//cplex.add(incum_call->added_constraints);
	//cplex.exportModel("cvrp2.lp");
}


void ExactCVRP::Init(Sol<Node,Driver> & s)
{
	env = IloEnv();
	model = IloModel(env);
	
	x = IloNumVarArray(env, graph->GetArcCount(),0,2,ILOINT);
	
	
	for(int i=0;i<graph->GetArcCount();i++)
	{
		ExCvrpArc * ar = graph->GetArc(i);
		//printf("arc:%d index:%d cost:%lf from:%d to:%d\n",i,ar->index,ar->cost,ar->from->no,ar->to->no);
		char name[40];
		sprintf(name,"x%d_%d",ar->from->no,ar->to->no);
		x[i].setName(name);	
		if(ar->from->no != 0)
			x[i].setBounds(0,1);
	}
	
	IloExpr obj1(env);
	for(int i=0;i<graph->GetArcCount();i++)
		obj1 += graph->GetArc(i)->cost * x[i];
	obj_func = IloMinimize(env, obj1);
	model.add(obj_func);
	obj1.end();
	
	//What get out of the depot = 2*#of vehicle
	//\sum_{ i \in C} x_{0i} = 2K
	{
		IloExpr expr(env);	
		printf("Out of zero:%d\n",graph->GetArcsOfCount(0));
		for(int i=0;i<graph->GetArcsOfCount(0);i++)
		{
			ExCvrpArc * ar = graph->GetArcOf(0,i);
			ExCvrpArc arr = *ar;
			int index = graph->GetArcOf(0,i)->index; 
			expr += x[ index ];
			
		}
		model.add( expr == 2*prob->GetDriverCount() );
		expr.end();
	}
	
	//what get in and out of each customer = 2
	//\sum_{i < j \in C} x_ij + \sum_{i > j \in C} x_ij = 2 \forall i \in C
	{
		for(int i=1;i<graph->GetNodeCount();i++)
		{
			IloExpr expr(env);
			for(int j=0;j<graph->GetArcsOfCount(i);j++)
				expr += x[ graph->GetArcOf(i,j)->index ];
			model.add(expr == 2);
			expr.end();
		}
	}
	
	
	cplex = IloCplex(model);
	cplex.setParam(IloCplex::Threads,1);
	cplex.setParam(IloCplex::Reduce,0);
	cplex.setParam(IloCplex::PreLinear,0);
	_sep = new ExactCvrpSep(env,graph,x);
	
	lazy_call = new ExactCvrpLazyCallBack(env, graph,x,_sep);
	usercut_call = new ExactCvrpUserCutCallBack(env, graph,x,_sep);
	
	cplex.use(lazy_call);
	cplex.use(usercut_call);
	//cplex.setParam(IloCplex::NodeLim, 3);
	cplex.setParam(IloCplex::CutUp, s.GetCost() + EPSILON);
}

void ExactCVRP::Clear()
{
	delete graph;
	delete _sep;
	//delete lazy_call; //memory leak here, I couldn't find how to free it correctly
	//delete usercut_call; //memory leak here, I couldn't find how to free it correctly
	obj_func.end();
	x.end();
	model.end();
	cplex.end();
	env.end();
}

void ExactCVRP::TestSolution(Sol<Node,Driver> & s)
{
	for(int i=0;i<s.GetDriverCount();i++)
	{
		IloExpr expr(env);
		int nb = 0;
	
		Driver * d = s.GetDriver(i);
		Node * prev = s.GetNode( d->StartNodeID );
		while(prev->type != NODE_TYPE_END_DEPOT)
		{
			Node * next = s.Next[ prev->id ];	
			ExCvrpArc* ar = graph->GetArc(prev->no, next->no);
			
			expr += x[ar->index];
			nb++;
			prev = next;
		}
		
		model.add(expr >= nb);
		expr.end();
	}
}






