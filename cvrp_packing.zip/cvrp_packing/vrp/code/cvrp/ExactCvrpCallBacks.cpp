

#include "ExactCvrpCallBacks.h"
#include "../../../lib/mathfunc.h"


ExactCvrpUserCutCallBack::ExactCvrpUserCutCallBack(IloEnv env, ExactCvrpGraph * graph, 
													IloNumVarArray x, ExactCvrpSep * sep) : 
													IloCplex::UserCutCallbackI(env), _graph(graph), _x(x),_sep(sep),
													added_constraints(env)
{
	
}
ExactCvrpUserCutCallBack::~ExactCvrpUserCutCallBack()
{
	for(int i=0;i<added_constraints.getSize();i++)
		added_constraints[i].end();
	added_constraints.end();
}
void ExactCvrpUserCutCallBack::main()
{
	if(!isAfterCutLoop()) return;
	//printf("ExactCvrpUserCutCallBack obj:%.2lf\n", (double)getObjValue());
	
	IloNumArray values(getEnv());
	getValues(values,_x);
	for(int i = 0 ; i < _graph->GetArcCount();i++)
	{
		ExCvrpArc * arc = _graph->GetArc(i);
		arc->value = (double)values[arc->index];
	}
	values.end();
	_graph->AssignPositiveValues();

	IloConstraintArray inq(getEnv());
	_sep->Seperate(inq);
	if(inq.getSize() >= 1) added_constraints.add(inq);
	for(int i=0;i<inq.getSize();i++)
		add(inq[i]);
	inq.end();
}



ExactCvrpLazyCallBack::ExactCvrpLazyCallBack(IloEnv env, ExactCvrpGraph * graph, 
											 IloNumVarArray x, ExactCvrpSep * sep) : 
											 IloCplex::LazyConstraintCallbackI(env), _graph(graph), _x(x),_sep(sep),
											 added_constraints(env)
{
	
}
ExactCvrpLazyCallBack::~ExactCvrpLazyCallBack()
{
	for(int i=0;i<added_constraints.getSize();i++)
		added_constraints[i].end();
	added_constraints.end();
}
void ExactCvrpLazyCallBack::main()
{
	//printf("ExactCvrpLazyCallBack obj:%.2lf\n", (double)getObjValue());
	IloNumArray values(getEnv());
	getValues(values,_x);
	for(int i = 0 ; i < _graph->GetArcCount();i++)
	{
		ExCvrpArc * arc = _graph->GetArc(i);
		arc->value = (double)values[arc->index];
	}
	values.end();
	_graph->AssignPositiveValues();

	IloConstraintArray inq(getEnv());
	_sep->Seperate(inq);
	if(inq.getSize() >= 1) added_constraints.add(inq);
	for(int i=0;i<inq.getSize();i++)
		add(inq[i]);
	inq.end();
}



