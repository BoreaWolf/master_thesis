

#include "CostFunctionCVRP.h"
#include "../constants.h"

double CostFunctionCVRP::GetCost(Sol<Node,Driver> & s)
{
	double cost = 0;
	for(int i = 0 ; i < s.GetDriverCount() ; i++)
	{
		Update(s, s.GetDriver(i));
		cost += s.GetDriver(i)->curDistance;
	}
	return cost + s.GetUnassignedCount()*UNASSIGNED_COST;	
}

double CostFunctionCVRP::GetCost(Sol<Node,Driver> & s,Driver * d)
{
	Update(s,d);
	return d->curDistance;	
}

void CostFunctionCVRP::Update(Sol<Node,Driver> & s)
{
	for(int i = 0 ; i < s.GetDriverCount() ; i++)
		Update(s, s.GetDriver(i));
}

void CostFunctionCVRP::Update(Sol<Node,Driver> & s, Driver * d)
{
	d->curDistance = 0;
	d->sumDemand = 0;
	d->curDuration = 0;
	Node * prev = s.GetNode( d->StartNodeID );
	
	int k = 0;
	while(prev->type != NODE_TYPE_END_DEPOT && k++ < 1000)
	{
		Node * next = s.Next[ prev->id ];
		
		if(prev->type == NODE_TYPE_CUSTOMER)
			d->curDuration += prev->serv_time;
		d->curDistance += _m[ prev->distID ][ next->distID ];
		d->sumDemand += prev->demand;
		prev = next;
	}
	
	if(k == 1000)
	{
		printf("Infinite loop in CostFunctionCVRP::Update()\n");
		exit(1);	
	}
	d->curDuration += d->curDistance;
}

void CostFunctionCVRP::Show(Sol<Node,Driver> * s, Driver * d)
{
	printf("Route:%d sum:%d cap:%d cost:%.3lf len:%d:", d->id,
			d->sumDemand,d->capacity,
			GetCost(*s,d), s->RoutesLength[d->id]);	
	Node * cur = s->GetNode( d->StartNodeID );
	while(cur != NULL)
	{
		printf("%d-", cur->no);
		cur = s->Next[ cur->id ];
	}
	printf("\n");
}





