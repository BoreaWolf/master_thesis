
#include "InsRmvMethodCVRP.h"
#include "../../../lib/mathfunc.h"
#include "../constants.h"


InsRmvMethodCVRP::InsRmvMethodCVRP(Prob<Node,Driver> & prob): _m(prob.GetDistances())
{
	_added_noise = mat_func_get_max_smaller_than(_m, prob.GetDimension(), INFINITE);
	_added_noise *= 0.025;
	SetNoise(0);
}

InsRmvMethodCVRP::~InsRmvMethodCVRP(){}

void InsRmvMethodCVRP::InsertCost(Sol<Node,Driver> & s, Node * n, Driver * d, Move<Node,Driver,MoveCVRP> & mo)
{
	mo.IsFeasible = false;
	mo.DeltaCost = INFINITE;
	mo.n = n;
	mo.to = d;
	
	if(d->sumDemand + n->demand > d->capacity) return;
	
	Node * prev = s.GetNode( d->StartNodeID );
	while(prev->type != NODE_TYPE_END_DEPOT)
	{
		Node * next = s.Next[ prev->id ];
		
		double deltaDist = _m[ prev->distID ][ n->distID ] + 
						   _m[ n->distID ][ next->distID ] -
						   _m[ prev->distID ][ next->distID ];
		
		double addedDuration = deltaDist + n->serv_time;
		double newcost = deltaDist + GetNoise() * (2 * mat_func_get_rand_double() * _added_noise - _added_noise);
		
		if(newcost < mo.DeltaCost && d->curDuration + addedDuration < d->maxDuration)
		{
			mo.DeltaDistance = deltaDist;
			mo.DeltaCost = newcost;
			mo.IsFeasible = true;	
			mo.move.prev = prev;
		}
	
		prev = next;
	}
}

void InsRmvMethodCVRP::ApplyInsertMove(Sol<Node,Driver> & s, Move<Node,Driver,MoveCVRP> & m)
{
	if(m.from != NULL)
	{
		s.Remove(m.n);
		m.from->sumDemand -=  m.n->demand;
		
	}
	else if(s.IsUnassigned(m.n))
		s.RemoveFromUnassigneds(m.n);
	
	s.InsertAfter(m.n, m.move.prev);
	//opt2.Optimize(s, m.to);
}

void InsRmvMethodCVRP::RemoveCost(Sol<Node,Driver> & s, Node * n, Move<Node,Driver,MoveCVRP> & m)
{
	m.IsFeasible = true;
	m.DeltaDistance = 0;
	m.n = n;
	m.to = NULL;
	m.move.prev = NULL;
	m.from = s.GetAssignedTo(n);
	if(m.from != NULL)
	{
		Node * prev = s.Prev[n->id];
		Node * next = s.Next[n->id];
		m.DeltaDistance = 	_m[ prev->distID ][ next->distID ] - 
							_m[ prev->distID ][ n->distID ] -
		 					_m[ n->distID ][ next->distID ];
		m.move.prev = prev;
	}
	
	m.DeltaCost = m.DeltaDistance;
}
	
