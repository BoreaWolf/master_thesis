/*
 * Copyright Jean-Francois Cote 2012
 * 
 * The code may be used for academic, non-commercial purposes only.
 * 
 * Please contact me at cotejean@iro.umontreal.ca for questions
 *
 * If you have improvements, please contact me!
 *
*/


#ifndef REMOVE_RANDOM
#define REMOVE_RANDOM

#include "Solution.h"
#include "../../lib/mathfunc.h"
#include "RemoveOperator.h"

#include <vector>
#include <algorithm>

template< class NodeT, class DriverT> 
class RemoveRandom : public RemoveOperator<NodeT,DriverT>
{
	public:
		RemoveRandom(){}
		~RemoveRandom(){}	
	
		void Remove(Sol<NodeT, DriverT> & s, int count)
		{
			//printf("RandomRemove\n");
			vect.clear();
			for(int i = 0 ; i < s.GetCustomerCount() ; i++)
				if( s.GetAssignedTo( s.GetCustomer(i) ) != NULL)
					vect.push_back( s.GetCustomer(i) );
			
			int cpt = MIN_INT(count, (int)vect.size());
			for(int i = 0 ; i < cpt ; i++)
			{
				int index = mat_func_get_rand_int(0, vect.size() - i);	
				s.RemoveAndUnassign( vect[index] );
				vect[index] = vect[ vect.size() - i - 1];
			}
			
		}
	private:
		std::vector<NodeT*> vect;
		
};


#endif
